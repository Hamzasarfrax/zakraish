<?php $__env->startSection('content'); ?>
    <?php if(session()->has('success')): ?>
        <div class="sweet_alerts_messages">
            <div class="mesg_box success">
                <div class="mesg">
                    <?php echo e(session('success')); ?>

                </div>
                <div class="close">
                    <i class="fa-solid fa-xmark toast-close"></i>
                </div>
                <div class="progress"></div>
            </div>
        </div>
    <?php endif; ?>
    <?php if(session()->has('error')): ?>
        <div class="sweet_alerts_messages">
            <div class="mesg_box error">
                <div class="mesg">
                    <?php echo e(session('error')); ?>

                </div>
                <div class="close">
                    <i class="fa-solid fa-xmark toast-close"></i>
                </div>
                <div class="progress"></div>
            </div>
        </div>
    <?php endif; ?>
    <div class="main_slider_top">
        <div class="swiper 
        hero-slide-item  mySwiper">
            <div class="swiper-wrapper">
                <?php $__currentLoopData = $MainSlide; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $MainSlide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="swiper-slide">
                        <div class="">
                            <div class="row align-items-center">
                                <div class="col-md-6">
                                    <div class="container">
                                        <div class="text_animated_content"
                                            style="    display: flex;
        justify-content: center;">
                                            <div class="hero-slide-content">
                                                <div class="hero-slide-text-img"><img
                                                        src="<?php echo e(asset('/public/Asset/Images/text-theme.webp')); ?>"
                                                        width="427" height="232" alt="Image"></div>
                                                <h2 class="hero-slide-title"><?php echo e($MainSlide->small_heading); ?></h2>
                                                <p class="hero-slide-desc">
                                                    <?php echo e($MainSlide->paragraph); ?>

                                                </p>
                                                <a class="btn btn-border-dark" href="#shop">BUY NOW</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">

                                    <div class="imgs">
                                        <div class="hero-slide-thumb">
                                            <img class="img-fluid"
                                                src="https://adminlaravell.foodbaskit.com/public/slides/<?php echo e($MainSlide->slide); ?>"
                                                class="" alt="">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
            <div class="swiper-pagination"></div>
            <div class="autoplay-progress">

                <span></span>
            </div>
        </div>
    </div>
    <main>
        <div class="container" id="discover">
            <div class="row">

            </div>
            
        </div>










        <section class="product_card mt-5 mb-5" data-aos-once="true" data-aos="fade-up" data-aos-duration="2000">
            <div class="heading_top">
                <h1>
                    Top Product's
                </h1>
            </div>
            <div class="container" id="shop">
                <div class="row">
                    <?php $__currentLoopData = $cat_prod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-6 col-md-4 col-lg-4 col-xl-4 mt-3 mb-3">


                            <div class="card_box">
                                <div class="card_body">
                                    <div class="card_img">
                                        <a href="/cart_details/<?php echo e($product->encryptedId); ?>">
                                            <img src="https://adminlaravell.foodbaskit.com/public/images/<?php echo e($product->images); ?>"
                                                class="img-fluid" alt="">
                                        </a>
                                        <?php if($product->heading): ?>
                                            <div class="card_discountbox">
                                                <?php echo e($product->percentageDifference); ?>%
                                            </div>
                                        <?php endif; ?>

                                    </div>

                                    <div class="card_bottom_details">
                                        <div class="ratings">



                                            <?php if($product->ratings > 0): ?>
                                                <?php
                                                    $maxStars = min($product->ratings, 5); // Limit maximum stars to 5
                                                ?>
                                                <?php for($i = 1; $i <= $maxStars; $i++): ?>
                                                    <i class="fa-regular fa-star"></i>
                                                <?php endfor; ?>
                                                <?php if($product->ratings > 5): ?>
                                                    <span> (<?php echo e($product->ratings); ?>)</span>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <i class="fa fa-star"></i>
                                                <span> (No ratings yet)</span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="card_title">
                                            <a href="/cart_details/<?php echo e($product->encryptedId); ?>">
                                                <div class="status">
                                                    <span>In-Stock</span> <span>
                                                        <form action="/WishList" method="post">

                                                            <?php echo csrf_field(); ?>

                                                            <?php echo method_field('post'); ?>

                                                            <input type="hidden" value="<?php echo e($product->id); ?>"
                                                                name="product_id">

                                                            <?php if(Auth::check()): ?>
                                                                <input type="hidden" value="<?php echo e(Auth::user()->email); ?>"
                                                                    name="email">
                                                            <?php endif; ?>





                                                            <button type="submit"> <i
                                                                    class="fa-regular fa-heart"></i></button>
                                                                    

                                                        </form>
                                                    </span>
                                                </div>
                                                <div class="name">
                                                    <?php echo e(Str::Limit($product->name, 50)); ?>

                                                </div>
                                            </a>
                                        </div>
                                        <div class="card_price">
                                            <div class="new">
                                                pkr: <?php echo e($product->price); ?>

                                            </div>
                                            <div class="old">
                                                <?php echo e($product->old_price); ?>

                                            </div>
                                        </div>
                                        <div class="btn_add_cart">
                                            <button id="btncart" onclick="addtocart(this)" class="btn btn_addedcart"
                                                data-id='<?php echo e($product->id); ?>' data-img='<?php echo e($product->images); ?>'
                                                data-encid='<?php echo e($product->encryptedId); ?>' data-name='<?php echo e($product->name); ?>'
                                                data-price='<?php echo e($product->price); ?>'>
                                                Add to cart</button>
                                        </div>
                                    </div>

                                </div>
                            </div>


                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="pagination">

                        <?php echo e($cat_prod->links('pagination::bootstrap-5')); ?>


                    </div>



                </div>
            </div>
        </section>




        <section class="clientreviews">
            <div class="client_only_images">
                <div class="row">

                    <div class="col-md-3"></div>
                    <div class="col-md-6">
                        <div class="client_imgs_reviews">

                            <?php $__currentLoopData = $clientimgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <div class="client_img">
                                        <img src="https://adminlaravell.foodbaskit.com/public/client_reviews/<?php echo e($item->client_image); ?>"
                                            alt="">

                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                    <div class="col-md-3"></div>

                </div>
            </div>
            <div class="client_reviewstext">
                <div class="box_of_client">
                    <div class="reviews_slider">

                        <?php $__currentLoopData = $clientimgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <div class="box_bar_reviews">
                                    <div class="details">
                                        <div class="ratings">

                                            <?php for($i = 1; $i <= 5; $i++): ?>
                                                <i class="fa-regular fa-star <?php if($i <= $item->client_reviews): ?> fas <?php else: ?> far <?php endif; ?>"
                                                    data-val="<?php echo e($i); ?>"></i>
                                            <?php endfor; ?>

                                        </div>
                                        <div class="para">
                                            <p class="more" data-id="<?php echo e($item->id); ?>" data-mesage="<?php echo e($item->client_message); ?>"  data-email="<?php echo e($item->client_email); ?>" data-name="<?php echo e($item->client_name); ?>"  data-desc="<?php echo e($item->client_description); ?>">
                                                <?php echo e(Str::limit($item->client_message, 50)); ?> <span>
                                                    <span class="anchor" data-bs-toggle="tooltip"
                                                    data-bs-placement="top"
                                                    data-bs-custom-class="custom-tooltip"
                                                    data-bs-title="Read More">
                                                        .. more
                                                    </span>
                                                </span>
                                            </p>

                                         
                                        </div>
                                        <div class="name">
                                            <strong>
                                                <?php echo e($item->client_name); ?> .
                                            </strong>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>


                </div>
            </div>
        </section>


        <section class="section-space pb-0" data-aos-once="true" data-aos="fade-up" data-aos-duration="2000">
            <div class="container">
                <div class="row  g-sm-6">
                    <div class="col-6 col-lg-4 col-lg-2 col-xl-2">
                        <!--== Start Product Category Item ==-->
                        <a href="/shop/Hair Care combos" class="product-category-item"
                            style="background-color: #4F6D7A !important;color:#fff;">
                            <img class="icon" src="<?php echo e(asset('/public/Asset/Images/1.webp')); ?>" width="70"
                                height="80" alt="Image-HasTech">
                            <h3 class="title">Hair care deals</h3>
                            <span class="flag-new">new</span>
                        </a>
                        <!--== End Product Category Item ==-->
                    </div>

                    <div class="col-6 col-lg-4 col-lg-2 col-xl-2 mt-xl-0 mt-sm-6 mt-4">
                        <!--== Start Product Category Item ==-->
                        <a href="/shop/Shampoo" class="product-category-item" data-bg-color="#FFDAE0"
                            style="background-color:#DBE9EE;">
                            <img class="icon" src="<?php echo e(asset('/public/Asset/Images/Shampoo.png')); ?>" width="80"
                                height="80" alt="Image-HasTech">
                            <h3 class="title">Hair care Remedies</h3>
                        </a>
                        <!--== End Product Category Item ==-->
                    </div>


                    <div class="col-6 col-lg-4 col-lg-2 col-xl-2 mt-lg-0 mt-sm-6 mt-4">
                        <!--== Start Product Category Item ==-->
                        <a href="/shop/Face wash" class="product-category-item" data-bg-color="#DFE4FF"
                            style="background-color:#4A6FA5; color:#fff;">
                            <img class="icon" src="<?php echo e(asset('/public/Asset/Images/facewash.png')); ?>" width="80"
                                height="80" alt="Image-HasTech">
                            <h3 class="title">Skin care deals</h3>
                        </a>
                        <!--== End Product Category Item ==-->
                    </div>


                    <div class="col-6 col-lg-4 col-lg-2 col-xl-2 mt-xl-0 mt-sm-6 mt-4">
                        <!--== Start Product Category Item ==-->
                        <a href="/shop/Serums" class="product-category-item" data-bg-color="#FFEACC"
                            style="background-color:rgb(216 216 255);">
                            <img class="icon" src="<?php echo e(asset('/public/Asset/Images/serum-svgrepo-com.svg')); ?>"
                                width="80" height="80" alt="Image-HasTech">
                            <h3 class="title">Face Serums</h3>
                            <span data-bg-color="#835BF4" class="flag-new"
                                style="background-color:#166088; color:#fff;">sale</span>
                        </a>
                        <!--== End Product Category Item ==-->
                    </div>

                    <div class="col-6 col-lg-4 col-lg-2 col-xl-2">
                        <!--== Start Product Category Item ==-->
                        <a href="/shop/Skin Care combos" class="product-category-item" data-bg-color="#FFEDB4"
                            style="background-color:#1D70A2; color:#fff;">
                            <img class="icon" src="<?php echo e(asset('/public/Asset/Images/2.webp')); ?>" width="80"
                                height="80" alt="Image-HasTech">
                            <h3 class="title">Skin care remedies</h3>
                        </a>
                        <!--== End Product Category Item ==-->
                    </div>



                    <div class="col-6 col-lg-4 col-lg-2 col-xl-2 mt-xl-0 mt-sm-6 mt-4">
                        <!--== Start Product Category Item ==-->
                        <a href="/shop/Face Charcoal masks" class="product-category-item" data-bg-color="#FFF3DA"
                            style="background-color:#1D70A2; color:#fff;">
                            <img class="icon" src="<?php echo e(asset('/public/Asset/Images/4.webp')); ?>" width="80"
                                height="80" alt="Image-HasTech">
                            <h3 class="title">Face Charcoal masks</h3>
                        </a>
                        <!--== End Product Category Item ==-->
                    </div>
                </div>
            </div>
        </section>




        <section class="products_details" id="bestsellers" data-aos-once="true" data-aos="fade-up"
            data-aos-duration="2000">
            <div class="container">
                <div class="row ">
                    <div class="heading_main">
                        <h4>Shop by Category</h4>
                        <h1>
                            Best selling deals upto 70% off
                        </h1>
                    </div>
                </div>
                <div class="bestsellers">
                    <div class="row">
                        <?php $__currentLoopData = $bestSellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Sellers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6">
                                <a href="/cart_details/<?php echo e($Sellers->encryptedId); ?>" class="">
                                    <div class="bestproducts " id="">
                                        <div class="imagesbessellers">
                                            <div class="card_img">
                                                <img src="https://adminlaravell.foodbaskit.com/public/images/<?php echo e($Sellers->images); ?>"
                                                    class="img-fluid" alt="">
                                                

                                                <div class="card_discountbox">
                                                    <?php echo e($Sellers->percentageDifference); ?>%
                                                </div>

                                                <div class="btn_overlay">
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="pagination">
                        <?php echo e($bestSellers->links('pagination::bootstrap-5')); ?>

                    </div>


                </div>

            </div>
        </section>
        <section class="how_our_policy_works">
            <div class="container">
                <div class="row">
                    <div class="col-md-3" data-aos="fade-up" data-aos-once="true" data-aos-duration="1000">
                        <div class="policy_details">
                            <div class="icons">
                                <i class="fa-solid fa-truck"></i>
                            </div>
                            <div class="parent_text">
                                <h3>Product Delivery</h3>
                                <h6>
                                    we deliver in 8-10 working day
                                </h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3" data-aos="fade-down" data-aos-once="true" data-aos-duration="1000">
                        <div class="policy_details">
                            <div class="icons">
                                <i class="fa-solid fa-dollar-sign"></i>
                            </div>
                            <div class="parent_text">
                                <h3>Return & Refund</h3>
                                <h6>
                                    Money back guarantee
                                </h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3" data-aos="fade-up" data-aos-once="true" data-aos-duration="1000">
                        <div class="policy_details">
                            <div class="icons">
                                <i class="fa-solid fa-person"></i>
                            </div>
                            <div class="parent_text">
                                <h3>Member Discount</h3>
                                <h6 class="text-capitalize">
                                    Get 10 % off on sharing before/after review images
                                </h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3" data-aos="fade-down" data-aos-once="true">
                        <div class="policy_details">
                            <div class="icons">
                                <i class="fa-solid fa-headphones"></i>
                            </div>
                            <div class="parent_text">
                                <h3>Support 24/7</h3>
                                <h6>
                                    Contact us 24 hours a day
                                </h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <section class="section-space pt-0" data-aos="fade-right" data-aos-once="true" data-aos-duration="1000">
            <div class="container p-0">
                <div class="newsletter-content-wrap" data-bg-img="assets/images/photos/bg1.webp"
                    style="background-image: url('<?php echo e(asset('/public/Assets/Images/bg1.webp')); ?>');">
                    <div class="newsletter-content">
                        <div class="section-title mb-0">
                            <h2 class="title"> Join our community</h2>
                            <p>
                                Join our community and get 10% off on next order!
                            </p>
                        </div>
                    </div>
                    <div class="newsletter-form">
                        <form>
                            <input type="email" class="form-control" placeholder="enter your email">
                            <button class="btn-submit" type="submit"><i class="fa fa-paper-plane"></i></button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <div class="boxoverlay" id="clienttextshow">
            <div class="box_details">
                <div class="top_close">
                    <i class="fa-solid fa-xmark"></i>
                </div>
               <div class="userinterfacepopup">
                <div class="name">

                </div>
                <div class="email">

                </div>
                <div class="textclient">
                 
                </div>
              
                <div class="desc">

                </div>
               </div>
            </div>
        </div>
<div class="overlayreview"></div>
    </main>
    
    
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.App', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/foodbaskit/testing.foodbaskit.com/resources/views/welcome.blade.php ENDPATH**/ ?>