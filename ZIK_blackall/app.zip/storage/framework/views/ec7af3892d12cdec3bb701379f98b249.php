<aside class="sidebar">
  <ul>
    <li><a href="/">
    home</a></li>
  </ul>
</aside><?php /**PATH /home2/foodbaskit/testing.foodbaskit.com/resources/views/Partials/Aside.blade.php ENDPATH**/ ?>