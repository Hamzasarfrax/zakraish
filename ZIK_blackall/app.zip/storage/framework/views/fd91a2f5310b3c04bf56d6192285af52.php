<script src="<?php echo e(asset('public/Asset/Js/Jquery.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
    integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script src="<?php echo e(asset('public/Asset/Js/popper.min.js')); ?>"></script>

<script src="<?php echo e(asset('public/Asset/Js/bootstrap.min.js')); ?>"></script>

<script src="<?php echo e(asset('public/Asset/Js/slick.min.js')); ?>"></script>

<script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>

<script src="<?php echo e(asset('public/Asset/Js/Main.js')); ?>"></script>

<script src="<?php echo e(asset('public/Asset/Js/Checkout.js')); ?>"></script>
<script src="<?php echo e(asset('public/Asset/Js/Slider.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
<?php /**PATH /home2/foodbaskit/testing.foodbaskit.com/resources/views/Partials/Script.blade.php ENDPATH**/ ?>