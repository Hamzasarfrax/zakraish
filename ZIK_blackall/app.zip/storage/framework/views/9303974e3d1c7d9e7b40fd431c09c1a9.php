<div class="load">
<div class="loader">
    <div class="circle"></div>
    <div class="circle"></div>
    <div class="circle"></div>
    <div class="circle"></div>
</div>
</div><?php /**PATH /home2/foodbaskit/testing.foodbaskit.com/resources/views/Partials/Loader.blade.php ENDPATH**/ ?>