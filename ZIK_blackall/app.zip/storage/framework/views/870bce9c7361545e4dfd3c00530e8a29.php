<?php $__env->startSection('content'); ?>
    <main>
        <div class="cart_details___of_sepecific___products">


       

            <?php if(session()->has('error')): ?>
                <div class="sweet_alerts_messages">
                    <div class="mesg_box error">
                        <div class="mesg">
                            <?php echo e(session('error')); ?>

                        </div>
                        <div class="close">
                            <i class="fa-solid fa-xmark toast-close"></i>
                        </div>
                        <div class="progress"></div>
                    </div>

                </div>
            <?php endif; ?>

            <div class="container">
                <div class="heading_main">
                    <h1>
                        product details
                    </h1>
                </div>

                <div class="row">
                    <div class="product______details_menu">
                        <div class="menus">
                            <li>
                                <a href="/">
                                    <div class="icon">
                                        <i class="fa-solid fa-house"></i>
                                    </div>
                                    <div class="title">
                                        home
                                    </div>
                                </a>
                            </li>

                            <li>
                                <a data-id="red">

                                    <div class="title">
                                        <?php echo e($prod->product_type); ?>

                                    </div>
                                </a>
                            </li>

                            <li>
                                <a data-id="red">
                                    <div class="title">
                                        <?php echo e($prod->category); ?>

                                    </div>
                                </a>
                            </li>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="product_all___images">
                            <div class="slider___product_img">

                                <div class="main_top___slide">
                                    <img src="https://adminlaravell.foodbaskit.com/public/images/<?php echo e($prod->images); ?>"
                                        class="img-fluid" id="main_product_img" alt="product">
                                </div>
                                <div class="small_slides">
                                    <div class="bottom_top___slider">
                                        <?php if($prod->images2): ?>
                                            <div>
                                                <div class="imgs_for_details">
                                                    <img src="https://adminlaravell.foodbaskit.com/public/images/<?php echo e($prod->images2); ?>"
                                                        class="img-fluid" alt="">
                                                </div>
                                            </div>
                                        <?php endif; ?>

                                        <?php if($prod->images3): ?>
                                            <div>
                                                <div class="imgs_for_details">
                                                    <img src="https://adminlaravell.foodbaskit.com/public/images/<?php echo e($prod->images3); ?>"
                                                        class="img-fluid" alt="">
                                                </div>
                                            </div>
                                        <?php endif; ?>

                                        <?php if($prod->images4): ?>
                                            <div>
                                                <div class="imgs_for_details">
                                                    <img src="https://adminlaravell.foodbaskit.com/public/images/<?php echo e($prod->images4); ?>"
                                                        class="img-fluid" alt="">
                                                </div>
                                            </div>
                                        <?php endif; ?>

                                        <?php if($prod->images): ?>
                                            <div>
                                                <div class="imgs_for_details">
                                                    <img src="https://adminlaravell.foodbaskit.com/public/images/<?php echo e($prod->images); ?>"
                                                        class="img-fluid" alt="">
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="product___detail___of_all__settings">
                            <div class="heading_prod">
                                <h4>
                                    <?php echo e($prod->category); ?>

                                </h4>

                                <h2>
                                    <?php echo e($prod->name); ?>

                                </h2>
                            </div>

                            <div class="stock__and__reviews">
                                <div class="stocks">
                                    in-stock
                                </div>
                                <div class="reviews">
                                    <?php if($prod->ratings > 0): ?>
                                        <?php
                                            $maxStars = min($prod->ratings, 5); // Limit maximum stars to 5
                                        ?>
                                        <?php for($i = 1; $i <= $maxStars; $i++): ?>
                                            <i class="fa fa-star"></i>
                                        <?php endfor; ?>
                                        <?php if($prod->ratings > 5): ?>
                                            <span> (<?php echo e($prod->ratings); ?>)</span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <i class="fa fa-star"></i>
                                        <span> (No ratings yet)</span>
                                    <?php endif; ?>


                                </div>

                            </div>

                            <div class="prod_desc">
                                <?php echo e($prod->description); ?>

                            </div>
                            <div class="prod_price">
                                <div class="old_price">
                                    <span>PKR:</span> <?php echo e($prod->old_price); ?>

                                </div>
                                <div class="pkr">
                                    <span>PKR:</span> <span class="new_price"><?php echo e($prod->price); ?></span>
                                </div>
                            </div>
                            <div class="prod_quantity">
                                

                                
                                

                            </div>

                            <div class="btn_for_checkout">
                                <div class="flexis_checkout">




                                    
                                    <button id="btncart" onclick="addtocart(this)" class="btn btn_checkout payment"
                                        data-id='<?php echo e($prod->id); ?>' data-img='<?php echo e($prod->images); ?>'
                                        data-encid='<?php echo e($prod->encryptedId); ?>' data-name='<?php echo e($prod->name); ?>'
                                        data-price='<?php echo e($prod->price); ?>'>add to cart</button>

                                    
                                    <button class="btn btn_cart buyitnow" id="btncart" onclick="buynow(this)"
                                        class="btn btn_checkout payment" data-id='<?php echo e($prod->id); ?>'
                                        data-img='<?php echo e($prod->images); ?>' data-encid='<?php echo e($prod->encryptedId); ?>'
                                        data-name='<?php echo e($prod->name); ?>' data-price='<?php echo e($prod->price); ?>'>Buy It
                                        Now</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="section_description_information">

                        <div class="info_tabs">
                            <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link " id="pills-home-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-home" type="button" role="tab"
                                        aria-controls="pills-home" aria-selected="true">Description</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-profile" type="button" role="tab"
                                        aria-controls="pills-profile" aria-selected="false">Additional
                                        information</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link active" id="pills-contact-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-contact" type="button" role="tab"
                                        aria-controls="pills-contact" aria-selected="false">Reviews (0)</button>
                                </li>

                            </ul>
                            <div class="tab-content" id="pills-tabContent">
                                <div class="tab-pane fade " id="pills-home" role="tabpanel"
                                    aria-labelledby="pills-home-tab" tabindex="0">
                                    <?php echo e($prod->description); ?>

                                </div>
                                <div class="tab-pane fade" id="pills-profile" role="tabpanel"
                                    aria-labelledby="pills-profile-tab" tabindex="0">

                                    <div class="table-responsive">
                                        <table class="table text-capitalize">
                                            <thead>
                                                <tr>

                                                    <th scope="col">ingredients</th>

                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>

                                                    <td> <?php echo e($prod->ingredients); ?></td>

                                                </tr>

                                            </tbody>
                                        </table>
                                        <div class="mt-5">
                                            <div class="text-left">
                                                <h1>
                                                    How To Use
                                                </h1>
                                                <hr>
                                            </div>
                                            <p class="text-capitalize">
                                                <?php echo e($prod->product_use); ?>

                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade show active" id="pills-contact" role="tabpanel"
                                    aria-labelledby="pills-contact-tab" tabindex="0">


                                    <div class="row">
                                        <div class="col-md-8">
                                            <div class="reviews_about_products">

                                                <div class="heading">
                                                    <h1>
                                                        reviews about the product
                                                    </h1>
                                                </div>

                                                <div class="form_connect_us">
                                                    <form action="/storeproduct" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('POST'); ?>
                                                        <input type="hidden" name="product_id"
                                                            value="<?php echo e($prod->id); ?>">
                                                        <div class="mb-3">
                                                            <label for="formGroupExampleInput" class="form-label">
                                                                review</label>
                                                            <div class="revies_stars">
                                                                <i class="fa-regular fa-star" data-val="1"> </i>
                                                                <i class="fa-regular fa-star" data-val="2"></i>
                                                                <i class="fa-regular fa-star" data-val="3"></i>
                                                                <i class="fa-regular fa-star" data-val="4"></i>
                                                                <i class="fa-regular fa-star" data-val="5"></i>
                                                            </div>
                                                        </div>

                                                        <div class="mb-3">

                                                            <input type="number" name="client_rating"
                                                                id="reviews_products" class="form-control" placeholder=""
                                                                value="1">
                                                            </input>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label for="formGroupExampleInput" class="form-label">enter
                                                                your review</label>

                                                            <textarea class="form-control" name="client_message" id="exampleFormControlTextarea1" rows="3"></textarea>
                                                            <?php $__errorArgs = ['client_message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="valid-feedback"> <?php echo e($message); ?></span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label for="formGroupExampleInput" class="form-label">your
                                                                name</label>
                                                            <input name="client_name" type="text" class="form-control"
                                                                id="formGroupExampleInput" placeholder="Your Name">
                                                            <?php $__errorArgs = ['client_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="valid-feedback"> <?php echo e($message); ?></span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>

                                                        <div class="mb-3">
                                                            <label for="formGroupExampleInput2" class="form-label">your
                                                                email</label>
                                                            <input name="client_email" type="email"
                                                                class="form-control" id="formGroupExampleInput2"
                                                                placeholder="Your Email">
                                                            <?php $__errorArgs = ['client_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="valid-feedback"> <?php echo e($message); ?></span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>

                                                        <button type="submit" class="btn btn_main ">submit your
                                                            reviews</button>

                                                    </form>
                                                </div>

                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="reviews_about_client_for_product">
                                                <div class="reviews_prod mt-5 mb-2">
                                                    <h1>
                                                        Product Ratings
                                                    </h1>
                                                </div>
                                                <div class="row">
                                                    <?php $__currentLoopData = $Productreviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="col-md-12 mb-2">
                                                            <div class="product_details">
                                                                <div class="img">
                                                                    <i class="fa-solid fa-user"></i>
                                                                </div>
                                                                <div class="basic_details">
                                                                    <div class="name">
                                                                        <?php echo e($item->client_name); ?>

                                                                    </div>
                                                                    <div class="rating">
                                                                        <?php if($item->client_rating > 0): ?>
                                                                            <?php for($i = 1; $i <= $item->client_rating; $i++): ?>
                                                                                <i class="fa fa-star"></i>
                                                                            <?php endfor; ?>
                                                                            <span> (<?php echo e($item->client_rating); ?>) <span
                                                                                    class="date"><?php echo e(date('D M Y', strtotime($item->created_at))); ?></span>
                                                                            </span>
                                                                        <?php else: ?>
                                                                            <i class="fa fa-star"></i>
                                                                            <span> (No ratings yet)</span>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div class="email">
                                                                        <?php echo e($item->client_email); ?>

                                                                        <p>
                                                                            <span>
                                                                                <strong>
                                                                                    <?php echo e($item->client_message); ?>

                                                                                </strong>
                                                                            </span>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>

                    
                </div>
            </div>
        </div>
    </main>
    
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.App', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/foodbaskit/testing.foodbaskit.com/resources/views/Cart_details.blade.php ENDPATH**/ ?>