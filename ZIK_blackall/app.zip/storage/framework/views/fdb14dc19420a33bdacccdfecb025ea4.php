<?php $__env->startSection('content'); ?>
    <main>
        <div class="shoop_all_____category_data">
            <div class="container">
                <div class="heading_main">
                    <h3>
                        All Product Of Shop
                    </h3>
                    <h1>
                        Shop Divided by category
                    </h1>
                </div>

                <div class="bread_crum___list">
                    <div class="detl">
                        <a href="/">
                            <div class="cion">
                                <i class="fa-solid fa-house"></i>
                            </div>
                            <div class="name">
                                home</div>
                        </a>

                        <a>
                            Shop List
                        </a>
                    </div>
                </div>

                <div class="searching_products_all_shop mt-5 mb-5">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card_wrap v2">
                                <div class="card_body">
                                    <div class="seacrh_bars">
                                        <input type="text" class="form-control"
                                            placeholder="Search Your Desired Products" name=""
                                            id="searching_shop_prod">
                                        <div class="icon" type='submit'>
                                            <i class="fa-solid fa-magnifying-glass"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-7">
                        <div class="row">
                            <?php $__currentLoopData = $prod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-12">


                                    <div class="product_of___shop">
                                        <div class="products_details_shop">
                                            <div class="product_cart_shop">
                                                <div class="card_body">
                                                    <a class="nav-link" href="/cart_details/<?php echo e($cat->encryptedId); ?>">
                                                        <div class="row">
                                                            <div class="col-lg-4">
                                                                <div class="product_details">
                                                                    <div class="product_img">
                                                                        <img src="https://adminlaravell.foodbaskit.com/public/images/<?php echo e($cat->images); ?>"
                                                                            class="img-fluid" alt="Product-Zakraish">
                                                                        <div class="PRODUCT_social">
                                                                            <div class="menu">
                                                                                <li>

                                                                                    <a href="/cart_details/<?php echo e($cat->encryptedId); ?>"
                                                                                        class="icon"
                                                                                        data-bs-toggle="tooltip"
                                                                                        data-bs-placement="left"
                                                                                        data-bs-custom-class="custom-tooltip"
                                                                                        data-bs-title="Add To Cart">
                                                                                        <i class="fa-solid fa-eye"></i>
                                                                                    </a>

                                                                                    <div class="icon"
                                                                                        data-bs-toggle="tooltip"
                                                                                        data-bs-placement="left"
                                                                                        data-bs-custom-class="custom-tooltip"
                                                                                        data-bs-title="Add To Wishlist">
                                                                                        <form action="/WishList"
                                                                                            method="post">
                                                                                            <?php echo csrf_field(); ?>
                                                                                            <?php echo method_field('post'); ?>
                                                                                            <input type="hidden"
                                                                                                value="<?php echo e($cat->id); ?>"
                                                                                                name="product_id">
                                                                                            <?php if(Auth::check()): ?>
                                                                                                <input type="hidden"
                                                                                                    value="<?php echo e(Auth::user()->email); ?>"
                                                                                                    name="email">
                                                                                            <?php endif; ?>


                                                                                            <button type="submit"> <i
                                                                                                    class="fa-regular fa-heart"></i></button>
                                                                                        </form>

                                                                                    </div>

                                                                                </li>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-8">
                                                                <div class="product_bootom___details">
                                                                    <div class="name">
                                                                        <span class="title"><?php echo e($cat->product_type); ?></span>
                                                                        <div class="value">
                                                                            <?php echo e(Str::limit($cat->name, 25, '...')); ?>

                                                                        </div>
                                                                    </div>
                                                                    <div class="reviews">
                                                                        <?php echo e($cat->ratings); ?>

                                                                        <?php for($i = 1; $i <= 5; $i++): ?>
                                                                            <?php if($i <= $cat->ratings): ?>
                                                                                <i class="fa fa-star"></i>
                                                                                <!-- Solid star -->
                                                                            <?php else: ?>
                                                                                <i class="fa fa-star-o"></i>
                                                                                <!-- Unfilled star -->
                                                                            <?php endif; ?>
                                                                        <?php endfor; ?>
                                                                        <span> (Review's)</span>
                                                                    </div>

                                                                    <div class="description">
                                                                        <?php echo e(Str::Limit($cat->description, 30)); ?>

                                                                    </div>
                                                                    <div class="price">
                                                                        <div class="old">
                                                                            <div class="val">PKR</div>
                                                                            <div class="key"><?php echo e($cat->old_price); ?>.00
                                                                            </div>
                                                                        </div>
                                                                        <div class="new">
                                                                            <div class="val">PKR</div>
                                                                            <div class="key"><?php echo e($cat->price); ?>.00
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="btn_cart">
                                                                        <button onclick="addtocart(this)"
                                                                            data-img="<?php echo e($cat->images); ?>"
                                                                            data-id="<?php echo e($cat->id); ?>"
                                                                            data-encid="<?php echo e($cat->encryptedId); ?>"
                                                                            data-name="<?php echo e($cat->name); ?>"
                                                                            data-price="<?php echo e($cat->price); ?>"
                                                                            class="btn btn_cart">
                                                                            add to cart
                                                                        </button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="shop_filtters___data__product">
                            <div class="custom_filter_cat">
                                <div class="input_tag">
                                    <div class="name">
                                        filter product's
                                    </div>
                                    <div class="icon">
                                        <i class="fas fa-angle-right dropdown rotate"></i>
                                    </div>
                                </div>
                                <div class="menu">

                                    <?php $__currentLoopData = $allprod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a href="/cart_details/<?php echo e($item->encryptedId); ?>">
                                                <?php echo e($item->name); ?>

                                            </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <div class="top___rated___prod">
                                <div class="heading_main">
                                    <h3>
                                        there is
                                    </h3>
                                    <h1>
                                        Top Rated Products
                                    </h1>
                                </div>
                                <div class="row">
                                    <?php $__currentLoopData = $toprated; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $toprated): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-12">
                                            <a href="/cart_details/<?php echo e($toprated->encryptedId); ?>">
                                                <div class="card_top___rated___prod">
                                                    <div class="card_img">
                                                        <img src="https://adminlaravell.foodbaskit.com//public/images/<?php echo e($toprated->images); ?>"
                                                            class="img-fluid" alt="<?php echo e($toprated->name); ?>">
                                                    </div>
                                                    <div class="card_details">
                                                        <div class="reviews">
                                                            <?php for($i = 1; $i <= 5; $i++): ?>
                                                                <?php if($i <= $toprated->ratings): ?>
                                                                    <i class="fa fa-star"></i> <!-- Full star -->
                                                                <?php else: ?>
                                                                    <i class="fa fa-star-o"></i> <!-- Unfilled star -->
                                                                <?php endif; ?>
                                                            <?php endfor; ?>


                                                            <span> (Review's(<?php echo e($toprated->ratings); ?>))</span>
                                                        </div>
                                                        <div class="name">
                                                            <?php echo e(Str::limit($toprated->name, 20, '...')); ?>

                                                        </div>
                                                        <div class="price">
                                                            <?php echo e($toprated->price); ?>

                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        // $(document).ready(function() {
        //    $('#searching_shop_prod').on('keyup',function(){
        //       var val=$(this).val();
        // // alert('')
        //       $.ajax({
        //         type: 'GET',
        //         url: 'shop/' + val,
        //         data: val,
        //         dataType: 'json',
        //         success: function(data) {

        // console.log(data)
        //         }
        //     });

        //    });

        // });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.App', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/foodbaskit/testing.foodbaskit.com/resources/views/Shop.blade.php ENDPATH**/ ?>