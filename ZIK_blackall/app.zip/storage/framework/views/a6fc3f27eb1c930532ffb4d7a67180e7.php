<footer>
   <div class="tp-footer-area tp-footer-style-2 tp-footer-style-primary tp-footer-style-6 " data-bg-color="footer-bg-grey">
      <div class="tp-footer-top color_scheme pt-95 pb-40">
         <div class="container ">
            <div class="row">
               <div class="col-xl-4 col-lg-3 col-md-4 col-sm-6">
                  <div class="tp-footer-widget footer-col-1 mb-50">
                     <div class="tp-footer-widget-content">
                        <div class="tp-footer-logo">
                        <a href="/">
                           
                            
                         </a>
                         </div>
                        <p class="tp-footer-desc">
                           
                    Pakistan’s first fully vegan and halal beauty brand - where nature meets science for a kinder , more sustainable future. #Bethejawdropper
                    Shop 👇🏻
                        </p>
                        <div class="tp-footer-social">
                          <?php
                          $socials = DB::select("select * from footer_links");
                          ?>
                          <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php if($social->social_name == 'facebook'): ?>
                                  <a href="<?php echo e($social->social_link); ?>" data-name='<?php echo e($social->social_name); ?>' target="_blank"><i class="fa-brands fa-facebook-f"></i></a>
                              <?php endif; ?>
                      
                              <?php if($social->social_name == 'instagram'): ?>
                                  <a href="<?php echo e($social->social_link); ?>" target="_blank">
                                   <i class="fa-brands fa-instagram"></i>
                                </a>
                              <?php endif; ?>
                      
                              <?php if($social->social_name == 'linkedin'): ?>
                                  <a href="<?php echo e($social->social_link); ?>" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a>
                              <?php endif; ?>
                      
                              <?php if($social->social_name == 'youtube'): ?>
                                  <a href="<?php echo e($social->social_link); ?>" target="_blank">
                                   <i class="fa-brands fa-youtube"></i>
                                </a>
                              <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                      
                     </div>
                  </div>
               </div>
               <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6">
                  <div class="tp-footer-widget footer-col-2 mb-50">
                     <h4 class="tp-footer-widget-title">My Account</h4>
                     <div class="tp-footer-widget-content">
                        <ul>
                           <li><a href="/trackorder">Track Orders</a></li>

                        <li><a href="/wishlists">Wishlist</a></li>

                           <li><a href="#">Order History</a></li>
                           <li><a href="/register">Signup</a></li>
                           <li><a href="/returnparoduct">Returns</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
               <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6">
                  <div class="tp-footer-widget footer-col-3 mb-50">
                     <h4 class="tp-footer-widget-title">Information</h4>
                     <div class="tp-footer-widget-content">
                        <ul>
                           <li><a href="/aboutus/#our_story">Our Story</a></li>

                           <li><a href="/terms_condition">Terms &amp; Conditions</a></li>
                           <li><a href="/aboutus/#latest_news">Latest News</a></li>
                           <li><a href="/contactus">Contact Us</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
             
               <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6">
                  <div class="tp-footer-widget footer-col-4 mb-50">
                     <h4 class="tp-footer-widget-title">Talk To Us</h4>
                     <?php
                     $footer = DB::select("select * from footers  ");
                 ?>
                 <?php $__currentLoopData = $footer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="tp-footer-widget-content">
                    <div class="tp-footer-talk mb-20">
                       <span>Got Questions? Call us</span>
                       <h4><a href="tel:<?php echo e($footer->contactno); ?>">+<?php echo e($footer->contactno); ?></a></h4>
                    </div>
                    <div class="tp-footer-contact">
                       <div class="tp-footer-contact-item d-flex align-items-start">
                          <div class="tp-footer-contact-icon">
                             <span>
                                <svg width="18" height="16" viewBox="0 0 18 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M1 5C1 2.2 2.6 1 5 1H13C15.4 1 17 2.2 17 5V10.6C17 13.4 15.4 14.6 13 14.6H5" stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                   <path d="M13 5.40039L10.496 7.40039C9.672 8.05639 8.32 8.05639 7.496 7.40039L5 5.40039" stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                   <path d="M1 11.4004H5.8" stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                   <path d="M1 8.19922H3.4" stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                </svg>
                             </span>
                          </div>
                          <div class="tp-footer-contact-content">
                             <p><a href="mailto:<?php echo e($footer->email); ?>"><?php echo e($footer->email); ?></a></p>
                          </div>
                       </div>
                       <div class="tp-footer-contact-item d-flex align-items-start">
                          <div class="tp-footer-contact-icon">
                             <span>
                                <svg width="17" height="20" viewBox="0 0 17 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M8.50001 10.9417C9.99877 10.9417 11.2138 9.72668 11.2138 8.22791C11.2138 6.72915 9.99877 5.51416 8.50001 5.51416C7.00124 5.51416 5.78625 6.72915 5.78625 8.22791C5.78625 9.72668 7.00124 10.9417 8.50001 10.9417Z" stroke="currentColor" stroke-width="1.5"></path>
                                   <path d="M1.21115 6.64496C2.92464 -0.887449 14.0841 -0.878751 15.7889 6.65366C16.7891 11.0722 14.0406 14.8123 11.6313 17.126C9.88298 18.8134 7.11704 18.8134 5.36006 17.126C2.95943 14.8123 0.210885 11.0635 1.21115 6.64496Z" stroke="currentColor" stroke-width="1.5"></path>
                                </svg>
                             </span>
                          </div>
                          <div class="tp-footer-contact-content">
                             <p><a href="" target="_blank">
                                <?php echo e($footer->address); ?>   
                             </a></p>
                          </div>
                       </div>
                    </div>
                 </div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                  </div>
               </div>
            </div>
            <div class="tp-footer-bottom">
               <div class=" ">
                  <div class="tp-footer-bottom-wrapper">
                     <div class="row align-items-center">
                        <div class="col-md-6">
                           <div class="tp-footer-copyright">
                              <p>© 2023 All Rights Reserved  | <a href="/"> Zakriaish </a>.</p>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="tp-footer-payment text-md-end">
                              <p><img alt="pay" loading="lazy" width="234" height="32" src="<?php echo e(asset('/public/Asset/Images/footer-pay.webp')); ?>"></p>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   
   </div>
</footer>

<footer id="secondary">
<div class="container">
   <div class="text-center">
      <h1>
         © 2023 All Rights Reserved | Zakriaish 
      </h1>
   </div>
</div>
</footer>

<?php /**PATH /home2/foodbaskit/testing.foodbaskit.com/resources/views/Partials/Footer.blade.php ENDPATH**/ ?>