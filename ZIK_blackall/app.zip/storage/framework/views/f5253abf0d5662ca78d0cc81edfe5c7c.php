<div class="checkout_box">

    <div class="head">
        <div class="barnaname">
            zakriaish
        </div>
        <i class="fa-solid fa-xmark"></i>
    </div>


    <div class="bottom_box">
        <h2>Cart <strong class="lenght" id="lenght"> </strong></h2>
        <ul id="cart_items" class="cart_items">


        </ul>
    </div>

    <div class="all_bottom">
        <div class="pricess">
            <div class="span">
                <span>
                    Subtotal
                </span>
                <span class="sub">
                    Rs.
                    <div class="total_price">

                    </div>
                    PKR
                </span>
            </div>
            <div class="taxes-discounts"><small class="tax-note caption-large rte">Taxes and <a
                        href="/terms_condition">shipping</a> calculated at checkout
                </small>
            </div>
        </div>

        <div class="">
            <a href="/checkout" class="btn btn_checkout_all"> checkout all</a>
            <a href="/cart" class="btn btn_checkout_all"> View cart</a>
        </div>
    </div>

</div>



<div class="succes__cart success">
    <div class="box_alert">
        <div class="child">
            <div class="check">
                <i class="fa-solid fa-check"></i>
            </div>
        </div>
        <div class="child">
            <span class="text"> Item Added To Cart</span>
        </div>

        <div class="child">
            <div class="close" id="close" onclick="closealert()">
                <i class="fa-solid fa-xmark toast-close"></i>
            </div>
        </div>

    </div>
    <div class="progress"></div>
</div>


<div class="error__cart  error">
    <div class="box_alert">
        <div class="child">
            <div class="check">
                <i class="fa-solid fa-trash"></i>
            </div>
        </div>
        <div class="child">
            <span class="text"> Item Remove From Cart</span>
        </div>

        <div class="child">
            <div class="close" id="close" onclick="closealert()">
                <i class="fa-solid fa-xmark toast-close"></i>
            </div>
        </div>

    </div>
    <div class="progress"></div>
</div>





<?php /**PATH /home2/foodbaskit/testing.foodbaskit.com/resources/views/Partials/Checkout.blade.php ENDPATH**/ ?>