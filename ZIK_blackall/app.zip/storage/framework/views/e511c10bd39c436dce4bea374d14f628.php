<?php $__env->startSection('content'); ?>
    <main>
        <div class="blogs_details_page">
            <div class="container">
                <div class="latest_blogs" id="latest_blogs">
                    <div class="heading_main">
                        <h3>
                            Blog Details
                        </h3>
                        <h1>
                            Blogs
                        </h1>
                    </div>

                    <div class="row">
                        <?php $__currentLoopData = $clientReviewLatest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blogs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6">
                                <div class="card">
                                    <img src="<?php echo e(asset('/public/client_reviews/' . $blogs->client_image)); ?>"
                                        alt="zik" />
                                    <div class="card-body">
                                        <h6> <?php echo e($blogs->client_name); ?></h6>
                                        <p>
                                           
                                            <?php echo e(Str::limit($blogs->client_message,30)); ?>...


                                        </p>
                                        <div>
                                            <a href="/blog_details/<?php echo e($blogs->encrypt_id); ?>">Read More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="pagination">

                            <?php echo e($clientReviewLatest->links('pagination::bootstrap-5')); ?>

    
                        </div>
                    </div>
                </div>



                
            </div>
        </div>



        
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.App', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/foodbaskit/testing.foodbaskit.com/resources/views/Blogs.blade.php ENDPATH**/ ?>