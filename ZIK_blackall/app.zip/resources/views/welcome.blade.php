@extends('Layout.App')
@section('content')
    @if (session()->has('success'))
        <div class="sweet_alerts_messages">
            <div class="mesg_box success">
                <div class="mesg">
                    {{ session('success') }}
                </div>
                <div class="close">
                    <i class="fa-solid fa-xmark toast-close"></i>
                </div>
                <div class="progress"></div>
            </div>
        </div>
    @endif
    @if (session()->has('error'))
        <div class="sweet_alerts_messages">
            <div class="mesg_box error">
                <div class="mesg">
                    {{ session('error') }}
                </div>
                <div class="close">
                    <i class="fa-solid fa-xmark toast-close"></i>
                </div>
                <div class="progress"></div>
            </div>
        </div>
    @endif
    <div class="main_slider_top">
        <div class="swiper 
        hero-slide-item  mySwiper">
            <div class="swiper-wrapper">
                @foreach ($MainSlide as $MainSlide)
                    <div class="swiper-slide">
                        <div class="">
                            <div class="row align-items-center">
                                <div class="col-md-6">
                                    <div class="container">
                                        <div class="text_animated_content"
                                            style="    display: flex;
        justify-content: center;">
                                            <div class="hero-slide-content">
                                                <div class="hero-slide-text-img"><img
                                                        src="{{ asset('/public/Asset/Images/text-theme.webp') }}"
                                                        width="427" height="232" alt="Image"></div>
                                                <h2 class="hero-slide-title">{{ $MainSlide->small_heading }}</h2>
                                                <p class="hero-slide-desc">
                                                    {{ $MainSlide->paragraph }}
                                                </p>
                                                <a class="btn btn-border-dark" href="#shop">BUY NOW</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">

                                    <div class="imgs">
                                        <div class="hero-slide-thumb">
                                            <img class="img-fluid"
                                                src="https://adminlaravell.foodbaskit.com/public/slides/{{ $MainSlide->slide }}"
                                                class="" alt="">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                @endforeach

            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
            <div class="swiper-pagination"></div>
            <div class="autoplay-progress">

                <span></span>
            </div>
        </div>
    </div>
    <main>
        <div class="container" id="discover">
            <div class="row">

            </div>
            {{-- end_container --}}
        </div>










        <section class="product_card mt-5 mb-5" data-aos-once="true" data-aos="fade-up" data-aos-duration="2000">
            <div class="heading_top">
                <h1>
                    Top Product's
                </h1>
            </div>
            <div class="container" id="shop">
                <div class="row">
                    @foreach ($cat_prod as $product)
                        <div class="col-6 col-md-4 col-lg-4 col-xl-4 mt-3 mb-3">


                            <div class="card_box">
                                <div class="card_body">
                                    <div class="card_img">
                                        <a href="/cart_details/{{ $product->encryptedId }}">
                                            <img src="https://adminlaravell.foodbaskit.com/public/images/{{ $product->images }}"
                                                class="img-fluid" alt="">
                                        </a>
                                        @if ($product->heading)
                                            <div class="card_discountbox">
                                                {{ $product->percentageDifference }}%
                                            </div>
                                        @endif

                                    </div>

                                    <div class="card_bottom_details">
                                        <div class="ratings">



                                            @if ($product->ratings > 0)
                                                @php
                                                    $maxStars = min($product->ratings, 5); // Limit maximum stars to 5
                                                @endphp
                                                @for ($i = 1; $i <= $maxStars; $i++)
                                                    <i class="fa-regular fa-star"></i>
                                                @endfor
                                                @if ($product->ratings > 5)
                                                    <span> ({{ $product->ratings }})</span>
                                                @endif
                                            @else
                                                <i class="fa fa-star"></i>
                                                <span> (No ratings yet)</span>
                                            @endif
                                        </div>
                                        <div class="card_title">
                                            <a href="/cart_details/{{ $product->encryptedId }}">
                                                <div class="status">
                                                    <span>In-Stock</span> <span>
                                                        <form action="/WishList" method="post">

                                                            @csrf

                                                            @method('post')

                                                            <input type="hidden" value="{{ $product->id }}"
                                                                name="product_id">

                                                            @if (Auth::check())
                                                                <input type="hidden" value="{{ Auth::user()->email }}"
                                                                    name="email">
                                                            @endif





                                                            <button type="submit"> <i
                                                                    class="fa-regular fa-heart"></i></button>
                                                                    {{-- <i class="fa-solid fa-heart"></i> --}}

                                                        </form>
                                                    </span>
                                                </div>
                                                <div class="name">
                                                    {{ Str::Limit($product->name, 50) }}
                                                </div>
                                            </a>
                                        </div>
                                        <div class="card_price">
                                            <div class="new">
                                                pkr: {{ $product->price }}
                                            </div>
                                            <div class="old">
                                                {{ $product->old_price }}
                                            </div>
                                        </div>
                                        <div class="btn_add_cart">
                                            <button id="btncart" onclick="addtocart(this)" class="btn btn_addedcart"
                                                data-id='{{ $product->id }}' data-img='{{ $product->images }}'
                                                data-encid='{{ $product->encryptedId }}' data-name='{{ $product->name }}'
                                                data-price='{{ $product->price }}'>
                                                Add to cart</button>
                                        </div>
                                    </div>

                                </div>
                            </div>


                        </div>
                    @endforeach
                    <div class="pagination">

                        {{ $cat_prod->links('pagination::bootstrap-5') }}

                    </div>



                </div>
            </div>
        </section>




        <section class="clientreviews">
            <div class="client_only_images">
                <div class="row">

                    <div class="col-md-3"></div>
                    <div class="col-md-6">
                        <div class="client_imgs_reviews">

                            @foreach ($clientimgs as $item)
                                <div>
                                    <div class="client_img">
                                        <img src="https://adminlaravell.foodbaskit.com/public/client_reviews/{{ $item->client_image }}"
                                            alt="">

                                    </div>
                                </div>
                            @endforeach

                        </div>
                    </div>
                    <div class="col-md-3"></div>

                </div>
            </div>
            <div class="client_reviewstext">
                <div class="box_of_client">
                    <div class="reviews_slider">

                        @foreach ($clientimgs as $item)
                            <div>
                                <div class="box_bar_reviews">
                                    <div class="details">
                                        <div class="ratings">

                                            @for ($i = 1; $i <= 5; $i++)
                                                <i class="fa-regular fa-star @if ($i <= $item->client_reviews) fas @else far @endif"
                                                    data-val="{{ $i }}"></i>
                                            @endfor

                                        </div>
                                        <div class="para">
                                            <p class="more" data-id="{{ $item->id }}" data-mesage="{{  $item->client_message }}"  data-email="{{  $item->client_email }}" data-name="{{ $item->client_name }}"  data-desc="{{  $item->client_description }}">
                                                {{ Str::limit($item->client_message, 50) }} <span>
                                                    <span class="anchor" data-bs-toggle="tooltip"
                                                    data-bs-placement="top"
                                                    data-bs-custom-class="custom-tooltip"
                                                    data-bs-title="Read More">
                                                        .. more
                                                    </span>
                                                </span>
                                            </p>

                                         
                                        </div>
                                        <div class="name">
                                            <strong>
                                                {{ $item->client_name }} .
                                            </strong>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endforeach

                    </div>


                </div>
            </div>
        </section>


        <section class="section-space pb-0" data-aos-once="true" data-aos="fade-up" data-aos-duration="2000">
            <div class="container">
                <div class="row  g-sm-6">
                    <div class="col-6 col-lg-4 col-lg-2 col-xl-2">
                        <!--== Start Product Category Item ==-->
                        <a href="/shop/Hair Care combos" class="product-category-item"
                            style="background-color: #4F6D7A !important;color:#fff;">
                            <img class="icon" src="{{ asset('/public/Asset/Images/1.webp') }}" width="70"
                                height="80" alt="Image-HasTech">
                            <h3 class="title">Hair care deals</h3>
                            <span class="flag-new">new</span>
                        </a>
                        <!--== End Product Category Item ==-->
                    </div>

                    <div class="col-6 col-lg-4 col-lg-2 col-xl-2 mt-xl-0 mt-sm-6 mt-4">
                        <!--== Start Product Category Item ==-->
                        <a href="/shop/Shampoo" class="product-category-item" data-bg-color="#FFDAE0"
                            style="background-color:#DBE9EE;">
                            <img class="icon" src="{{ asset('/public/Asset/Images/Shampoo.png') }}" width="80"
                                height="80" alt="Image-HasTech">
                            <h3 class="title">Hair care Remedies</h3>
                        </a>
                        <!--== End Product Category Item ==-->
                    </div>


                    <div class="col-6 col-lg-4 col-lg-2 col-xl-2 mt-lg-0 mt-sm-6 mt-4">
                        <!--== Start Product Category Item ==-->
                        <a href="/shop/Face wash" class="product-category-item" data-bg-color="#DFE4FF"
                            style="background-color:#4A6FA5; color:#fff;">
                            <img class="icon" src="{{ asset('/public/Asset/Images/facewash.png') }}" width="80"
                                height="80" alt="Image-HasTech">
                            <h3 class="title">Skin care deals</h3>
                        </a>
                        <!--== End Product Category Item ==-->
                    </div>


                    <div class="col-6 col-lg-4 col-lg-2 col-xl-2 mt-xl-0 mt-sm-6 mt-4">
                        <!--== Start Product Category Item ==-->
                        <a href="/shop/Serums" class="product-category-item" data-bg-color="#FFEACC"
                            style="background-color:rgb(216 216 255);">
                            <img class="icon" src="{{ asset('/public/Asset/Images/serum-svgrepo-com.svg') }}"
                                width="80" height="80" alt="Image-HasTech">
                            <h3 class="title">Face Serums</h3>
                            <span data-bg-color="#835BF4" class="flag-new"
                                style="background-color:#166088; color:#fff;">sale</span>
                        </a>
                        <!--== End Product Category Item ==-->
                    </div>

                    <div class="col-6 col-lg-4 col-lg-2 col-xl-2">
                        <!--== Start Product Category Item ==-->
                        <a href="/shop/Skin Care combos" class="product-category-item" data-bg-color="#FFEDB4"
                            style="background-color:#1D70A2; color:#fff;">
                            <img class="icon" src="{{ asset('/public/Asset/Images/2.webp') }}" width="80"
                                height="80" alt="Image-HasTech">
                            <h3 class="title">Skin care remedies</h3>
                        </a>
                        <!--== End Product Category Item ==-->
                    </div>



                    <div class="col-6 col-lg-4 col-lg-2 col-xl-2 mt-xl-0 mt-sm-6 mt-4">
                        <!--== Start Product Category Item ==-->
                        <a href="/shop/Face Charcoal masks" class="product-category-item" data-bg-color="#FFF3DA"
                            style="background-color:#1D70A2; color:#fff;">
                            <img class="icon" src="{{ asset('/public/Asset/Images/4.webp') }}" width="80"
                                height="80" alt="Image-HasTech">
                            <h3 class="title">Face Charcoal masks</h3>
                        </a>
                        <!--== End Product Category Item ==-->
                    </div>
                </div>
            </div>
        </section>




        <section class="products_details" id="bestsellers" data-aos-once="true" data-aos="fade-up"
            data-aos-duration="2000">
            <div class="container">
                <div class="row ">
                    <div class="heading_main">
                        <h4>Shop by Category</h4>
                        <h1>
                            Best selling deals upto 70% off
                        </h1>
                    </div>
                </div>
                <div class="bestsellers">
                    <div class="row">
                        @foreach ($bestSellers as $Sellers)
                            <div class="col-md-6">
                                <a href="/cart_details/{{ $Sellers->encryptedId }}" class="">
                                    <div class="bestproducts " id="">
                                        <div class="imagesbessellers">
                                            <div class="card_img">
                                                <img src="https://adminlaravell.foodbaskit.com/public/images/{{ $Sellers->images }}"
                                                    class="img-fluid" alt="">
                                                {{-- @if ($Sellers->heading)
                                                 
                                                @endif --}}

                                                <div class="card_discountbox">
                                                    {{ $Sellers->percentageDifference }}%
                                                </div>

                                                <div class="btn_overlay">
                                                    {{-- <a href="/cart_details/{{ $Sellers->encryptedId }}"
                                                    class="btn btn_addedcart">
                                                    <i class="fa-regular fa-eye"></i></a> --}}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        @endforeach
                    </div>
                    <div class="pagination">
                        {{ $bestSellers->links('pagination::bootstrap-5') }}
                    </div>


                </div>

            </div>
        </section>
        <section class="how_our_policy_works">
            <div class="container">
                <div class="row">
                    <div class="col-md-3" data-aos="fade-up" data-aos-once="true" data-aos-duration="1000">
                        <div class="policy_details">
                            <div class="icons">
                                <i class="fa-solid fa-truck"></i>
                            </div>
                            <div class="parent_text">
                                <h3>Product Delivery</h3>
                                <h6>
                                    we deliver in 8-10 working day
                                </h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3" data-aos="fade-down" data-aos-once="true" data-aos-duration="1000">
                        <div class="policy_details">
                            <div class="icons">
                                <i class="fa-solid fa-dollar-sign"></i>
                            </div>
                            <div class="parent_text">
                                <h3>Return & Refund</h3>
                                <h6>
                                    Money back guarantee
                                </h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3" data-aos="fade-up" data-aos-once="true" data-aos-duration="1000">
                        <div class="policy_details">
                            <div class="icons">
                                <i class="fa-solid fa-person"></i>
                            </div>
                            <div class="parent_text">
                                <h3>Member Discount</h3>
                                <h6 class="text-capitalize">
                                    Get 10 % off on sharing before/after review images
                                </h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3" data-aos="fade-down" data-aos-once="true">
                        <div class="policy_details">
                            <div class="icons">
                                <i class="fa-solid fa-headphones"></i>
                            </div>
                            <div class="parent_text">
                                <h3>Support 24/7</h3>
                                <h6>
                                    Contact us 24 hours a day
                                </h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <section class="section-space pt-0" data-aos="fade-right" data-aos-once="true" data-aos-duration="1000">
            <div class="container p-0">
                <div class="newsletter-content-wrap" data-bg-img="assets/images/photos/bg1.webp"
                    style="background-image: url('{{ asset('/public/Assets/Images/bg1.webp') }}');">
                    <div class="newsletter-content">
                        <div class="section-title mb-0">
                            <h2 class="title"> Join our community</h2>
                            <p>
                                Join our community and get 10% off on next order!
                            </p>
                        </div>
                    </div>
                    <div class="newsletter-form">
                        <form>
                            <input type="email" class="form-control" placeholder="enter your email">
                            <button class="btn-submit" type="submit"><i class="fa fa-paper-plane"></i></button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <div class="boxoverlay" id="clienttextshow">
            <div class="box_details">
                <div class="top_close">
                    <i class="fa-solid fa-xmark"></i>
                </div>
               <div class="userinterfacepopup">
                <div class="name">

                </div>
                <div class="email">

                </div>
                <div class="textclient">
                 
                </div>
              
                <div class="desc">

                </div>
               </div>
            </div>
        </div>
<div class="overlayreview"></div>
    </main>
    {{-- 
@include('Partials.Script') --}}
    {{-- 
<script>
   $(document).ready(function() {
   
   
   
       $.ajax({
   
           type: 'GET',
   
           url: '/paginate',
   
           data: {},
   
           dataType: 'json',
   
           success: function(data) {
   
               // console.log(data);
   
   
   
           }
   
       });
   
   });
</script> --}}
    {{-- <script>
   $(document).ready(function() {
   
       var dropdownItems = document.querySelectorAll('.category_products');
   
       let itemsPerPage = 12;
   
       let currentPage = 1;
   
       let totalPage = 0;
   
   
   
       $('.category_products').click(function() {
   
           $('.category_products').removeClass('active'); // Remove 'active' class from all items
   
           $(this).addClass('active'); // Add 'active' class to the clicked item
   
   
   
           let category = $(this).attr('data-val');
   
           fetchdata(category); // Pass the category parameter to fetchdata function
   
   
   
       });
   
   
   
       function fetchdata(category) {
   
           $.ajax({
   
               type: 'GET',
   
               url: '/CategoryProducts', // Update the URL to match the correct route
   
               data: {
   
                   keyword: category
   
               }, // Pass the keyword as data in the request
   
               dataType: 'json',
   
               success: function(data) {
   
                   let ProdCat = [...data];
   
   
   
                   totalPage = Math.ceil(ProdCat.length / itemsPerPage);
   
                   let startIndex = (currentPage - 1) * itemsPerPage;
   
                   let endIndex = startIndex + itemsPerPage;
   
                   let paginatedData = ProdCat.slice(startIndex, endIndex);
   
                   console.log(paginatedData);
   
                   $('#category_container').empty();
   
                   let prodContainer = $('#category_container');
   
                   prodContainer.empty();
   
   
   
                   paginatedData.forEach((item) => {
   
                       let card_html = `
   
               	  <div class="col-md-3 ">
   
   <div class="product_cart">
   
   <div class="card_body">
   
    <div class="product_details">
   
      <div class="product_img">
   
        <img src="https://adminlaravell.foodbaskit.com//public/images/${item.images}" class="img-fluid" alt="Product-Zakraish">
   
        <div class="PRODUCT_social">
   
          <div class="menu">
   
            <li>
   
              <a href="#">
   
                <div class="icon" data-bs-toggle="tooltip" data-bs-placement="left" data-bs-custom-class="custom-tooltip" data-bs-title="Add To Cart">
   
                  <i class="fa-solid fa-cart-shopping"></i>
   
                </div>
   
                <div class="icon" data-bs-toggle="tooltip" data-bs-placement="left" data-bs-custom-class="custom-tooltip" data-bs-title="Quick View">
   
                  <i class="fa-solid fa-eye"></i>
   
                </div>
   
                <div class="icon" data-bs-toggle="tooltip" data-bs-placement="left" data-bs-custom-class="custom-tooltip" data-bs-title="Add To Wishlist">
   
   
                </div>
   
              </a>
   
            </li>
   
          </div>
   
        </div>
   
        <div class="btn_cart">
   
          <a href="cart_details/${item.encryptedId}" class="btn btn_cart">add to cart</a>
   
        </div>
   
      </div>
   
    </div>
   
    <div class="product_bootom___details">
   
      <div class="name">
   
        <span class="title">${item.product_type}</span>
   
        <div class="value">
   
        ${item.name}
   
        </div>
   
      </div>
   
      <div class="price">
   
        <div class="val">$</div>
   
        <div class="key">    ${item.price},00</div>
   
      </div>
   
    </div>
   
   </div>
   
   </div>
   
   </div>
   
               `;
   
                       prodContainer.append(card_html);
   
                   });
   
   
   
                   renderPaginationButtons();
   
   
   
                   // Perform further operations with the data
   
               },
   
               error: function(xhr) {
   
                   console.log(xhr.responseText);
   
               }
   
           });
   
       }
   
   
   
       function renderPaginationButtons() {
   
           let paginationContainer = $('.pagination');
   
           paginationContainer.empty();
   
   
   
           for (let i = 1; i <= totalPage; i++) {
   
               let button_html = `
   
           <button class="page-button ${i === currentPage ? 'active' : ''}" data-page="${i}">${i}</button>
   
       `;
   
               paginationContainer.append(button_html);
   
           }
   
   
   
           // Attach click event handler to pagination buttons
   
           $('.page-button').click(function() {
   
               currentPage = parseInt($(this).attr('data-page'));
   
               let category = $('.category_products.active').attr('data-val');
   
               fetchdata(category); // Pass the category parameter to fetchdata function
   
           });
   
       }
   
   });
   
   
   
   fetch('https://zakriaish.com/products')
       .then((res) => {
           return res.json();
       })
       .then((result) => {
           // console.log(result);
   
           // Store the data in local storage
           var userDataString = JSON.stringify(result);
           localStorage.setItem('data', userDataString);
   
           // Retrieve and log the data from local storage
           var retrievedDataString = localStorage.getItem('data');
           if (retrievedDataString) {
               var retrievedData = JSON.parse(retrievedDataString);
               // console.log("Data retrieved from local storage:", retrievedData);
               $('#category_container').empty();
   
               let prodContainer = $('#category_container');
   
               prodContainer.empty();
               retrievedData.forEach(item => {
                   let card_html = `
   
   <div class="col-md-3 ">
   
   <div class="product_cart">
   
   <div class="card_body">
   
   <div class="product_details">
   
   <div class="product_img">
   
   <img src="https://adminlaravell.foodbaskit.com//public/images/${item.images}" class="img-fluid" alt="Product-Zakraish">
   
   <div class="PRODUCT_social">
   
   <div class="menu">
   
   <li>
   
   <a href="#">
   
   <div class="icon" data-bs-toggle="tooltip" data-bs-placement="left" data-bs-custom-class="custom-tooltip" data-bs-title="Add To Cart">
   
   <i class="fa-solid fa-cart-shopping"></i>
   
   </div>
   
   <div class="icon" data-bs-toggle="tooltip" data-bs-placement="left" data-bs-custom-class="custom-tooltip" data-bs-title="Quick View">
   
   <i class="fa-solid fa-eye"></i>
   
   </div>
   
   <div class="icon" data-bs-toggle="tooltip" data-bs-placement="left" data-bs-custom-class="custom-tooltip" data-bs-title="Add To Wishlist">
   
   <form action="/WishList" method="post">
   
   @csrf
   
   @method('post')
   
   <input type="hidden" value="${item.id}" name="product_id">
   
   @if (Auth::check())
   
   <input type="hidden" value="{{ Auth::user()->email }}" name="email">
   
   @endif
   
   
   
   
   
   <button type="submit">  <i class="fa-regular fa-heart"></i></button>
   
   </form>
   
   
   </div>
   
   </a>
   
   </li>
   
   </div>
   
   </div>
   
   <div class="btn_cart">
   
   <button   class="btn btn_cart add-to-cart-btn text-capitalize" data-id='${item.id}' data-img='${item.images}' data-encid='${item.encryptedId}'  data-name='${item.name}' data-price='${item.price}'>add to cart</button>
   
   </div>
   
   </div>
   
   </div>
   
   <div class="product_bootom___details">
   
   <div class="name">
   
   <span class="title">${item.product_type}</span>
   
   <div class="value">
   
   ${item.name}
   
   </div>
   
   </div>
   
   <div class="price">
   
   <div class="val">Pkr</div>
   
   <div class="key">    ${item.price},00</div>
   
   </div>
   
   </div>
   
   </div>
   
   </div>
   
   </div>
   
   `;
   
                   prodContainer.append(card_html);
               });
   
           }
       });
   
</script> --}}
@endsection
