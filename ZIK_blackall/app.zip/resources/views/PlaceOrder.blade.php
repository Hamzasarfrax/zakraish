@extends('Layout.App')
@section('content')
    <main>

        <section class="checkoutpage">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form_submitting">
                            <form action="/checkoutallproducts" method="POST">

                                @csrf
                         
                                <input type="hidden" name="total_price" id="total_price" class="sub_total" value="">
                                <textarea name="products" value="" type="hidden" class="d-none" cols="30" rows="10"
                                    id="insert_product"></textarea>
                                <div class="row">

                                    <div class="col-md-12">
                                        <div class="mb-3">
                                            <label for="contact" class="form-label">Email</label>
                                            <input type="email" class="form-control" id="" placeholder="email"
                                                name="email" aria-describedby="emailHelp">
                                            @error('email')
                                                <span class="invalid-feedback"> {{ $message }} </span>
                                            @enderror
                                            <div class="mb-3 mt-3 form-check">
                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                <label class="form-check-label" for="exampleCheck1">Email me with news and
                                                    offers</label>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="col-md-12">

                                        <div class="mb-3">
                                            <label for="contact" class="form-label">Delivery</label>
                                            <select class="form-select" aria-label="Default select example">
                                                <option selected>Pakistan</option>

                                            </select>
                                            <div id="emailHelp" class="form-text">We'll never share your Deatils with anyone
                                                else.</div>
                                        </div>
                                    </div>

                                    <div class="col-md-12">

                                        <div class="mb-3">
                                            <label for="contact" class="form-label">Your City </label>
                                            <input type="text"  placeholder="Your City" class="form-control"
                                                name="city" id="">
                                            @error('city')
                                                <span class="invalid-feedback"> {{ $message }} </span>
                                            @enderror

                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="mb-3">

                                            <input type="text" class="form-control" id="" placeholder="Username"
                                                 name="username">
                                            @error('username')
                                                <span class="invalid-feedback"> {{ $message }} </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <input type="number"  placeholder="Contact No" class="form-control"
                                                name="contactno" id="exampleInputPassword1">
                                            @error('contactno')
                                                <span class="invalid-feedback"> {{ $message }} </span>
                                            @enderror


                                        </div>
                                    </div>


                                    <div class="col-md-12">
                                        <div class="mb-3">


                                            <textarea class="form-control" placeholder="Enter Your Address" name="address" id="" cols="30"
                                                rows="10"></textarea>
                                            @error('address')
                                                <span class="invalid-feedback"> {{ $message }} </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>



                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label for="contact" class="form-label">Shipping method</label>
                                        <div class="box_forstandard_rupee">
                                            <div class="flex">
                                                <div class="child">
                                                    Standard
                                                </div>
                                                <div class="child">
                                                    RS 200.00
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                        </div>






                        <button type="submit" class="btn w-100 btn_main">Place Order</button>
                        </form>
                    </div>

                    <div class="col-md-6">
                        <div class="card_product_details">
                            <div class="w-400">
                                <ul id="cart_items" class="cart_items">



                                </ul>
                            </div>

                            <div class="all_bottom">
                                <div class="pricess">
                                    <div class="span">
                                        <span>
                                            Subtotal
                                        </span>
                                        <span class="sub">
                                            Rs.
                                            <div class="total_price"></div>
                                            PKR
                                        </span>
                                    </div>
                                    <div class="taxes-discounts"><small class="tax-note caption-large rte">Taxes and <a
                                                href="/">shipping</a> calculated
                                        </small>
                                    </div>
                                </div>


                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </section>
    </main>
@endsection
