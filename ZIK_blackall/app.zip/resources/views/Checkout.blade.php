@extends('Layout.App')
@section('content')
    <main>
        <div class="cart_details___of_sepecific___products">


            @if (session()->has('success'))
                <div class="sweet_alerts_messages">
                    <div class="mesg_box success">
                        <div class="mesg">
                            {{ session('success') }}
                        </div>
                        <div class="close">
                            <i class="fa-solid fa-xmark toast-close"></i>
                        </div>
                        <div class="progress"></div>
                    </div>

                </div>
            @endif

            @if (session()->has('error'))
                <div class="sweet_alerts_messages">
                    <div class="mesg_box error">
                        <div class="mesg">
                            {{ session('error') }}
                        </div>
                        <div class="close">
                            <i class="fa-solid fa-xmark toast-close"></i>
                        </div>
                        <div class="progress"></div>
                    </div>

                </div>
            @endif
            <section class="checkout_section">
                <div class="container">
                    <div class="shoop_all_____category_data">

                        <div class="breadcrumb__list">
                            <div class="detl">
                                <a href="/">
                                    <div class="cion">
                                        <i class="fa-solid fa-house"></i>
                                    </div>
                                    <div class="name">
                                        home</div>
                                </a>

                                <a>
                                    CheckOut
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-8">
                            <ul class="product_mapping cart_items" id="cart_items">

                            </ul>
                        </div>
                        <div class="col-md-4">
                            <div class="card" style="margin-top:25px">
                                <div class="card-body">
                                    <div class="product_details">
                                        <div class="pricess">
                                            <span>
                                                Sub total prices Pkr ::
                                            </span>
                                            <div class="total_price">

                                            </div>
                                        </div>
                                    </div>
                                    <div class="product_details">
                                        <div class="pricess">
                                            <span>
                                                total items ::
                                            </span>
                                            <div class="counter">

                                            </div>
                                        </div>
                                    </div>

                                    <div class="product_details">
                                        <div class="pricess">
                                            <span>
                                                Delivery Charges Pkr::
                                            </span>
                                            <div class="">
                                                200
                                            </div>
                                        </div>
                                    </div>


                                    <div class="product_details">
                                        <div class="pricess">
                                            <span>
                                                Total Price Pkr::
                                            </span>
                                            <div class="sub_total">

                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>

                            <div class="btns_modal mt-5">
                                <a href="/checkout" type="button" class="btn btn_main" >
                              Checkout
                                </a>

                                <!-- <button type="button"  class="btn btn_main mt-1 mb-2" >
                       Payment By Card
                            </button> -->
                            </div>
                        </div>
                    </div>
                </div>

              
        </div>
        </div>
        </section>
    </main>
@endsection
