<aside class="sidebar">
  <ul>
    <li><a href="/">
    home</a></li>
  </ul>
</aside>