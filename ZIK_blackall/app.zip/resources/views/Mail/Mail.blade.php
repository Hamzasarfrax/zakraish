 <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Zak</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f5f5f5;
      margin: 0;
      padding: 0;
    }

    .container {
      max-width: 100%;
      margin: 20px 0px;
      background: rgb( 246,248,250 );
      padding: 20px;
      border-radius: 10px;
      box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px;
      border-radius: 15px;
      text-transform: capitalize;
    }

    h1 {
      color: #333;
      text-align: center;
      margin-top: 0;
    }

    .greeting {
      text-align: left;
      margin-bottom: 20px;
      font-size: 18px;
      color: #15161d !important;
      ont-family: monospace;
      font-family: 'cursive';
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
      ont-family: monospace;
      overflow-x: auto !important;
    }

    th, td {
      border: 1px solid transparent;
      padding: 10px;
      text-align: left;
      font-family: 'Roboto';
      font-size: 25px;
    }

    th {
      background-color: transparent;
      padding: 10px !important;
      border-radius: 10px;
      margin: 0px 10px;
      min-width: 180px ;
      font-family: monospace;
    font-weight: 500;
    font-size: 25px;
    }

    .success-message {
      background-color: #15161d;
      color: #fff;
      border: 1px solid transparent;
      padding: 10px;
      margin-bottom: 20px;
      border-radius: 20px;
      text-transform: capitalize;
      margin-top: 20px ;
    }
    .container img.img{
      width: 250px;
      border-radius: 15px;
      margin: 20px 0px;
      mix-blend-mode: darken;
    }
    .container h1{
      margin: 20px 0px
    }
    .container .text-center img{
      margin: 20px 0px;
      width: 200px;
      height: 200px;
      object-fit: cover
    }
    .container .tables {
      background-color: #ffff;
      border-radius: 15px;
      padding: 10px;
      text-transform: capitalize;
    }
    .container .order_id{
      color: #333;
      font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
      font-size: 25px;
      font-weight: bolder
    }
    .container .brand {
      font-family: cursive;
color: #000 !important
    }
    .container p{
      font-family: monospace;
      text-transform: capitalize;
    }
    /* Bootstrap CSS for .col-md-2 */
@media (min-width: 768px) {
  .col-md-2 {
    flex: 0 0 auto;
    width: 16.66667%;
  }
}

/* Bootstrap CSS for .col-md-3 */
@media (min-width: 768px) {
  .col-md-3 {
    flex: 0 0 auto;
    width: 25%;
  }
}
/* Basic CSS for .row */
.row {
  display: flex;
  flex-wrap: wrap;
  margin-right: -15px; /* Adjust this value according to your gutter width */
  margin-left: -15px; /* Adjust this value according to your gutter width */
}

  </style>
</head>
<body>

  <div class="container" style="box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px;">

    <div class="text-center">
      <img src="https://laravel.foodbaskit.com/public/Asset/Images/zik.png" alt="zakriaish" alt="">
    </div>
    <h1 style="text-transform: capitalize;color:#222;" > thank you for shopping </h1>
<p>
  Welcome To <span class="brand">Zakriaish</span>
</p>
<img src="{{ $data['imgs'] ?? '' }}" class="img" alt="zakriaish" alt="">
    
  
    <p class="greeting">Dear {{ $data['user_name'] ?? '' }},</p>

    <p>
      Thank you for your order! We know you’re going to love it.
    </p>
   
    <p>
      You should receive a shipping email within a few days.
      <div>
<p>
  We usually take 7-10 working days but due to weather conditions or any political issues or any other issue, it might take 10-15 days in delivery 📦
</p>
      </div>
    </p>

    <div class="row">
      <div class="col-md-2">
        Name
      </div>
      <div class="col-md-2">
        Email
      </div>
      <div class="col-md-3">
        Product Name
      </div>
     <div class="col-md-2">
        Product Price
      </div> 
      <div class="col-md-3">
        Order I
      </div>
    </div>
    <table class="tables">
      <thead>
        <tr>
          <th>Name</th>
          <th>Email</th>
          <th>Product Name</th>
          <th>Product Price</th>
          <th>Order ID</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>{{ $data['user_name'] ?? '' }}</td>
          <td>{{ $data['user_email'] ?? '' }}</td>
          <td>{{ $data['product_name'] ?? '' }}</td>
          <td>{{ $data['product_price'] ?? '' }}</td>
          <td class="order_id">{{ $data['order_id'] ?? '' }}</td>
        </tr>
      </tbody>
    </table>
    <p class="success-message">Important note( kindly read our return/refund policies if you do not fulfill our criteria so we will unable to provide any refund or redelivery )</p>
  </div>
</body>
</html> 



