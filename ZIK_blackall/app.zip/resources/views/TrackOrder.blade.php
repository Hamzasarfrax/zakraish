@extends('Layout.App')
@section('content')
<main>
   @if (session()->has('success'))
     <div class="sweet_alerts_messages">
         <div class="mesg_box success">
             <div class="mesg">
                 {{ session('success') }}
             </div>
             <div class="close">
                 <i class="fa-solid fa-xmark toast-close"></i>
             </div>
             <div class="progress"></div>
         </div>
       
     </div>
    @endif
    
    @if (session()->has('error'))
     <div class="sweet_alerts_messages">
         <div class="mesg_box error">
             <div class="mesg">
                 {{ session('error') }}
             </div>
             <div class="close">
                 <i class="fa-solid fa-xmark toast-close"></i>
             </div>
             <div class="progress"></div>
         </div>
       
     </div>
    @endif
   <div class="track_your___orders mt-5">
      <div class="shoop_all_____category_data">
         <div class="container">
            <div class="heading_main">
               <h4>
                  we are providing service
               </h4>
               <h1>
                  to Track your order
               </h1>
            </div>
            <div class="bread_crum___list">
               <div class="detl">
                  <a href="/">
                     <div class="cion">
                        <i class="fa-solid fa-house"></i>
                     </div>
                     <div class="name">
                        home
                     </div>
                  </a>
                  <a>
                  Order List
                  </a>
               </div>
            </div>
            <div class="track_crd___order">
               <div class="card_wrap v2">
                  <div class="card_body">
                     <form action="TrackOrder" method="POST" class="row">
                        @method('POST')
                        @csrf
                        <div class="col-md-8">
                           <div class="forms">
                              <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Enter Your Order Id" name="order_id">
                           </div>
                        </div>
                        <div class="col-md-4">
                           <button class="btn btn_track" type="submit"> Track Your Order</button>
                        </div>
                     </form>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-md-7">
                @if (isset($Trackorder))
                <div class="track_order__detail___cart">
      <p>
         <h3>            {{ Auth::user()->name }} your order is here</h3>
      </p>
                    <div class="track___order_card">
                       <div class="card_img">
                          <img src="https://adminlaravell.foodbaskit.com/public/images/{{$Trackorder->images}}" class="img-fluid"  alt="">
                       </div>
                       <div class="card____all_info">
                          <div class="section_description_information">
                             <div class="info_tabs">
                                <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                                   <li class="nav-item" role="presentation">
                                      <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">Basic Information</button>
                                   </li>
                                   <li class="nav-item" role="presentation">
                                      <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false" tabindex="-1">Personal Details</button>
                                   </li>
                                   <li class="nav-item" role="presentation">
                                      <button class="nav-link" id="pills-contact-tab" data-bs-toggle="pill" data-bs-target="#pills-contact" type="button" role="tab" aria-controls="pills-contact" aria-selected="false" tabindex="-1">Reviews (0)</button>
                                   </li>
                                </ul>
                                <div class="tab-content" id="pills-tabContent">
                                   <div class="tab-pane fade active show" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab" tabindex="0">
                                      <div class="menuss">
                                         <li>
                                            the name of the product is {{$Trackorder->name}}
                                         </li>
                                         <li>
                                            the price of the product is {{$Trackorder->price}}
                                         </li>
                                         <li>
                                            the ingredients of the product is {{$Trackorder->ingredients}}
                                         </li>
                                         <li>
                                            the product is created at {{ date('M d, Y', strtotime($Trackorder->ingredients)) }}
                                         </li>
                                         <li>
                                             {{$Trackorder->description}}
                                         </li>
                                       
                                      </div>
                                   </div>
                                   <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab" tabindex="0">
                                      <div class="table-responsive">
                                         <table class="table">
                                            <thead>
                                               <tr>
                                                <th scope="col">order id</th>
                                                  <th scope="col">user name</th>
                                                  <th scope="col">user  email</th>
                                                  <th scope="col">user address</th>
                                                  <th scope="col">order city</th>
                                                
                                                  <th scope="col">user contact</th>
                                                  
                                               </tr>
                                            </thead>
                                            <tbody>
                                               <tr>
                                                  <th scope="row">{{$Trackorder->order_id}}
                                                  </th>
                                                  <td>{{$Trackorder->user_name}}</td>
                                                  <td>{{$Trackorder->user_email}}</td>
                                                  <td>{{$Trackorder->user_address}}</td>
                                                  <td>{{$Trackorder->order_city}}</td>
                                                  <td>{{$hiddenContact = str_repeat('*', strlen($Trackorder->user_contact) - 4) . substr($Trackorder->user_contact, -4)}}

                                                </td>
                                               </tr>
                                            </tbody>
                                         </table>
                                      </div>
                                   </div>
                                   <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab" tabindex="0">
                                      <div class="reviews_about_products">
                                         <div class="heading">
                                            <h1>
                                               reviews about the product
                                            </h1>
                                         </div>
                                         <div class="form_connect_us">
                                            <div class="revies__stars">
                                               @if ($Trackorder->ratings > 0)
                                               @php
                                               $maxStars = min($Trackorder->ratings, 5); // Limit maximum stars to 5
                                               @endphp
                                               @for ($i = 1; $i <= $maxStars; $i++)
                                               <div class="icon">
                                                  <i class="fa-regular fa-star"></i>
                                               </div>
                                               @endfor
                                               @if ($Trackorder->ratings > 5)
                                               <span> ({{ $Trackorder->ratings }})</span>
                                               @endif
                                               @else
                                               <i class="fa fa-star"></i>
                                               <span> (No ratings yet)</span>
                                               @endif
                                            </div>
                                         </div>
                                      </div>
                                   </div>
                                </div>
                             </div>
                          </div>
                       </div>
                    </div>
                 </div> 

                 @else
                 <div class="show show_empty show_box">
                    <div class="h3">
                        there is nothing for you please track order with your order id
                    </div>
                 </div>
                @endif
               </div>
               <div class="col-md-5">
                  <div class="shop_filtters___data__product">
                     <div class="custom_filter_cat">
                        <div class="input_tag">
                           <input type="text" class="seaching" id="search_prod" class="name" name="" placeholder="Search Product's"/>
                        
                           <div class="icon">
                              <i class="fas fa-angle-right dropdown rotate"></i>
                           </div>
                        </div>
                        <div class="menu" id="searching_products">
                        
                    
                        </div>
                     </div>
                     <div class="top___rated___prod">
                        <div class="heading_main">
                           <h3>
                              there is
                           </h3>
                           <h1>
                              Top Rated Products
                           </h1>
                        </div>
                        <div class="row">
                            @foreach ($toprated as $item)
                            <div class="col-md-12">
                                <a href="/cart_details/{{$item->encryptedId}}">
                                   <div class="card_top___rated___prod">
                                      <div class="card_img">
                                         <img src="https://adminlaravell.foodbaskit.com/public/images/{{$item->images}}"
                                            class="img-fluid" alt="">
                                      </div>
                                      <div class="card_details">
                                         <div class="reviews">
                                            @if ($item->ratings > 0)
                                            @php
                                            $maxStars = min($item->ratings, 5); // Limit maximum stars to 5
                                            @endphp
                                            @for ($i = 1; $i <= $maxStars; $i++)
                                            <i class="fa-regular fa-star"></i>
                                            @endfor
                                            {{-- @if ($item->ratings > 5)
                                            <span> ({{ $item->ratings }})</span>
                                            @endif --}}
                                          
                                       
                                            @endif
                                    
                                         </div>
                                         <div class="name">
                                         {{Str::limit($item->name,20)}}...
                                         </div>
                                         <div class="price">
                                            PKR {{$item->price}}
                                         </div>
                                      </div>
                                   </div>
                                </a>
                             </div>
                            @endforeach
                       
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</main>
<script src="https://code.jquery.com/jquery-3.7.0.min.js"
integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
<script>
$(document).ready(function() {
    $('#search_prod').on('keyup', function() {
      $('#searching_products').addClass('active');
    let namesearch = $(this).val();
    $.ajax({
        type: 'GET',
        url: '/productfilter',
        data: {
            keyword: namesearch,
        },
        dataType: 'json',
        success: function(data) {
            console.log(data);
            let container = $('#searching_products').empty();
            data.forEach(product => {
                let html = `<li>
                                <a href="/cart_details/${product.encryptedId}">
                                    <div class="product_search">
                                        <div class="img">
                                            <img src="https://adminlaravell.foodbaskit.com/public/images/${product.images}" class="img-fluid" alt="">
                                        </div>
                                        <div class="card_details">
                                            <div class="reviews">`;
                for (let i = 0; i < product.ratings; i++) {
                    html += `<i class="fa fa-star"></i>`;
                }
                html += `<span> (Review's(${product.ratings}))</span>
                                            </div>
                                            <div class="name">
                                                ${product.name}
                                            </div>
                                            <div class="price">
                                                PKR ${product.price}
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </li>`;
                container.append(html);
            });
        }
    });
});


 
});
</script>
@endsection