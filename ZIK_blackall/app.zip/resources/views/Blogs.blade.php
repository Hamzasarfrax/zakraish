@extends('Layout.App')
@section('content')
    <main>
        <div class="blogs_details_page">
            <div class="container">
                <div class="latest_blogs" id="latest_blogs">
                    <div class="heading_main">
                        <h3>
                            Blog Details
                        </h3>
                        <h1>
                            Blogs
                        </h1>
                    </div>

                    <div class="row">
                        @foreach ($clientReviewLatest as $blogs)
                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6">
                                <div class="card">
                                    <img src="{{ asset('/public/client_reviews/' . $blogs->client_image) }}"
                                        alt="zik" />
                                    <div class="card-body">
                                        <h6> {{ $blogs->client_name }}</h6>
                                        <p>
                                           
                                            {{Str::limit($blogs->client_message,30)}}...


                                        </p>
                                        <div>
                                            <a href="/blog_details/{{ $blogs->encrypt_id }}">Read More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endforeach

                        <div class="pagination">

                            {{ $clientReviewLatest->links('pagination::bootstrap-5') }}
    
                        </div>
                    </div>
                </div>



                {{-- end_comtainer --}}
            </div>
        </div>



        {{-- <div class="col-md-3">
                                <a href="/blog_details/{{ $clientReviewLatest->encrypt_id }}">
                                    <div class="card_blogs">
                                        <div class="card_body">
                                            <div class="card_details">
                                                <div class="card_img">
                                                    <img src="{{ asset('/public/client_reviews/' . $clientReviewLatest->client_image) }}"
                                                        class="img-fluid" alt="">

                                                </div>
                                                <div class="card_bottom_details">
                                                    <div class="flex">
                                                        <div class="post">
                                                            Posted <span class="">::</span>
                                                        </div>
                                                        <div class="date">
                                                      


                                                            {{ date('M d Y', strtotime($clientReviewLatest->created_at)) }}
                                                        </div>
                                                    </div>
                                                    <div class="title_blog">
                                                        {{ $clientReviewLatest->client_name }}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div> --}}
    </main>
@endsection
