@extends('Layout.App')
@section('content')
<main>
   <div class="whish_list__tabs">

      <div class="shoop_all_____category_data" >
         <div class="container">
            <div class="heading_main">
               <h3>
                  All Product Of Shop
               </h3>
               <h1>
                  Shop Divided by category
               </h1>
            </div>
   
            <div class="bread_crum___list">
             <div class="detl">
                  <a href="/"> 
                       <div class="cion">
                            <i class="fa-solid fa-house"></i>
                  </div> 
             <div class="name">
                  home</div></a>
   
                  <a >
                       wish List
                  </a>
             </div>
            </div>
   
          
            <div class="row">
               <div class="col-md-7">
                  <div class="row">
                     @foreach ($wishlist as $cat)
                     <div class="col-md-12">
                        <div class="product_of___shop">
                             <div class="products_details_shop">
                                <div class="product_cart_shop">
                                   <div class="card_body">
                                    <div class="row">
                                         <div class="col-lg-4">
                                            <div class="product_details">
                                               <div class="product_img">
                                                  <img src="https://adminlaravell.foodbaskit.com/public/images/{{ $cat->images }}"
                                                     class="img-fluid" alt="Product-Zakraish">
                                                  <div class="PRODUCT_social">
                                                     <div class="menu">
                                                        <li>
                                                       
                                                              <a href="/cart_details/{{ $cat->encryptedId }}"  class="icon" data-bs-toggle="tooltip"
                                                                 data-bs-placement="left"
                                                                 data-bs-custom-class="custom-tooltip"
                                                                 data-bs-title="Add To Cart">
                                                                 <i class="fa-solid fa-cart-shopping"></i>
                                                              </a>
                                                              <div class="icon" data-bs-toggle="tooltip"
                                                                 data-bs-placement="left"
                                                                 data-bs-custom-class="custom-tooltip"
                                                                 data-bs-title="Quick View">
                                                                 <i class="fa-solid fa-eye"></i>
                                                              </div>
                                                              <div class="icon" data-bs-toggle="tooltip"
                                                                 data-bs-placement="left"
                                                                 data-bs-custom-class="custom-tooltip"
                                                                 data-bs-title="Add To Wishlist">
                                                                 <form action="/WishList" method="post">
                                                                  @csrf
                                                                  @method('post')
                                                                  <input type="hidden" value="{{ $cat->id}}" name="product_id">
                                                                  @if (Auth::check())
                                                                  <input type="hidden" value="{{Auth::user()->email}}" name="email">
                                                                  @endif
                                                       
                                                                
                                                                  <button type="submit">  <i class="fa-regular fa-heart"></i></button>
                                                              </form>
                                                 
                                                              </div>
                                                         
                                                        </li>
                                                     </div>
                                                  </div>
                                               </div>
                                            </div>
                                         </div>
                                         <div class="col-lg-8">
                                            <div class="product_bootom___details">
                                               <div class="name">
                                                  <span class="title">{{ $cat->product_type }}</span>
                                                  <div class="value">
                                                   {{ Str::limit($cat->name, 25, '...') }}
                                                  </div>
                                               </div>
                                               <div class="reviews">
                                                {{ $cat->ratings }}
                                                @for ($i = 1; $i <= 5; $i++)
                                                    @if ($i <= $cat->ratings)
                                                        <i class="fa fa-star"></i> <!-- Solid star -->
                                                    @else
                                                        <i class="fa fa-star-o"></i> <!-- Unfilled star -->
                                                    @endif
                                                @endfor
                                                <span> (Review's)</span>
                                            </div>
                                            
                                               <div class="description">
                                                {{Str::Limit( $cat->description ,30) }}
                                               </div>
                                               <div class="price">
                                                  <div class="old">
                                                     <div class="val"> PKR</div>
                                                     <div class="key">{{ $cat->old_price }}.00</div>
                                                  </div>
                                                  <div class="new">
                                                     <div class="val"> PKR</div>
                                                     <div class="key">{{ $cat->price }}.00</div>
                                                  </div>
                                               </div>
                                               <div class="btn_cart">
                                          
                                                    
     <button onclick="addtocart(this)" class="btn btn_cart add-to-cart-btn text-capitalize" data-id='{{  $cat->id }}' data-img='{{  $cat->images }}' data-encid='{{  $cat->encryptedId }}' data-name='{{  $cat->name }}' data-price='{{  $cat->price }}'>add to cart</button>
                                               </div>
                                            </div>
                                         </div>
                                      </div>
                                   </div>
                                </div>
                             </div>
                          </div>
                   </div>
                     @endforeach
                      
   
                     
                  </div>
               </div>
               <div class="col-md-5">
                  <div class="shop_filtters___data__product">
                 
                     <div class="top___rated___prod">
                        <div class="heading_main">
                           <h3>
                              there is
                           </h3>
                           <h1>
                              Top Rated Products
                           </h1>
                        </div>
                        <div class="row">
                           @foreach ($toprated as $toprated)
                           <div class="col-md-12">
                              <a href="/cart_details/{{$toprated->encryptedId  }}">
                                 <div class="card_top___rated___prod">
                                    <div class="card_img">
                                       <img src="https://adminlaravell.foodbaskit.com//public/images/{{$toprated->images  }}"
                                          class="img-fluid" alt="{{$toprated->name  }}">
                                    </div>
                                    <div class="card_details">
                                       <div class="reviews">
                                          @for ($i = 1; $i <= 5; $i++)
                                          @if ($i <= $toprated->ratings)
                                              <i class="fa fa-star"></i> <!-- Full star -->
                                          @else
                                              <i class="fa fa-star-o"></i> <!-- Unfilled star -->
                                          @endif
                                      @endfor
                                      
                                      
                                          <span> (Review's({{$toprated->ratings  }}))</span>
                                       </div>
                                       <div class="name">
                                          {{Str::limit($toprated->name, 20, '...')  }}
                                       </div>
                                       <div class="price">
                                          PKR {{$toprated->price}}
                                       </div>
                                    </div>
                                 </div>
                              </a>
                           </div>
                           @endforeach
                        
   
                          
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</main>
@endsection