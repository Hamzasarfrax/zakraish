@extends('Layout.App')
@section('content')
    <main>
        <div class="container">
            <div class="cash___pay__checkout ">
         

                <div class="heading_main">
                    <h3>
                        ready for
                    </h3>
                    <h1>
                        Check Out Cash On delivery
                    </h1>
                </div>


                <div class="row">
                    <div class="col-md-8">
                        <div class="card_booking">

                            <div class="booking_forms">
                                <form action="/orderondelivery" method="Post">
                                    @method('POST')
                                    @csrf
                                    <input class="form-control" type="hidden" value="{{ $getProd->id }}" name="product_id">
                                    <input class="form-control" type="hidden" value="{{ $getProd->name }}" name="product_name">
                                    <input class="form-control" type="hidden" id="product_price" value="{{ $totalPrice+200 }}"
                                        name="product_price">
                                        <input class="form-control" type="hidden" id="product_price" value=" {{ $quantity }} "
                                        name="product_quantity">
                                        
                                        <input type="hidden" name='imgs' value="https://adminlaravell.foodbaskit.com/public/images/{{ $getProd->images }}">
                                        
                                    <div class="personal_info card_bookin_hotels">
                                        <div class="card_head">
                                            Personal Information
                                        </div>
                                        <div class="row">

                                            <div class="col-md-4">
                                                <div class="mb-3">
                                                    <label for="exampleInputPassword1" class="form-label">User Name</label>
                                                    <input class="form-control" type="text" placeholder="User Name" name="user_name">
                                                        @error('user_name')
                                                        <span class="valid-feedback">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                            </div>
                                            <div class="col-md-8">
                                                <div class="mb-3">
                                                    <label for="exampleInputPassword1" class="form-label">Email</label>
                                                    <input type="email" placeholder="Enter Your Email" name="user_email" class="form-control"
                                                        id="exampleInputPassword1">
                                                      
<div id="emailHelp" class="form-text">Please enter the email that has been verified. We have sent you an email.</div>
                                                        @error('user_email')
                                                        <span class="valid-feedback">{{ $message }}</span>
                                                    @enderror
                                                      
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="mb-3">
                                                    <label for="exampleInputPassword1" class="form-label">Contact No</label>
                                                    <input type="number" placeholder="Enter Contact No" name="user_contact" class="form-control"
                                                        id="exampleInputPassword1">
                                                        @error('user_contact')
                                                        <span class="valid-feedback">{{ $message }}</span>
                                                    @enderror
                                                      
                                                </div>
                                            </div>
                                        
                                           

                                           
                                        </div>

                                    </div>
                                    <div class="travel_info card_bookin_hotels">
                                        <div class="card_head">
                                            Address Information
                                        </div>
                                        <div class="row">
                                            <div class="card_travels row">
                                                <div class="col-md-12">
                                                    <div class="mb-3">
                                                        <label for="exampleInputPassword1" class="form-label">Select Your Country</label>
                                                        <select name="order_country" class="form-control">
                                                            <option value="select">Select a country...</option>
                                                            <option value="AFG">Afghanistan</option>
                                                            <option value="ALA">Åland Islands</option>
                                                            <option value="ALB">Albania</option>
                                                            <option value="DZA">Algeria</option>
                                                            <option value="ASM">American Samoa</option>
                                                            <option value="AND">Andorra</option>
                                                            <option value="AGO">Angola</option>
                                                            <option value="AIA">Anguilla</option>
                                                            <option value="ATA">Antarctica</option>
                                                            <option value="ATG">Antigua and Barbuda</option>
                                                            <option value="ARG">Argentina</option>
                                                            <option value="ARM">Armenia</option>
                                                            <option value="ABW">Aruba</option>
                                                            <option value="AUS">Australia</option>
                                                            <option value="AUT">Austria</option>
                                                            <option value="AZE">Azerbaijan</option>
                                                            <option value="BHS">Bahamas</option>
                                                            <option value="BHR">Bahrain</option>
                                                            <option value="BGD">Bangladesh</option>
                                                            <option value="BRB">Barbados</option>
                                                            <option value="BLR">Belarus</option>
                                                            <option value="BEL">Belgium</option>
                                                            <option value="BLZ">Belize</option>
                                                            <option value="BEN">Benin</option>
                                                            <option value="BMU">Bermuda</option>
                                                            <option value="BTN">Bhutan</option>
                                                            <option value="BOL">Bolivia, Plurinational State of</option>
                                                            <option value="BES">Bonaire, Sint Eustatius and Saba</option>
                                                            <option value="BIH">Bosnia and Herzegovina</option>
                                                            <option value="BWA">Botswana</option>
                                                            <option value="BVT">Bouvet Island</option>
                                                            <option value="BRA">Brazil</option>
                                                            <option value="IOT">British Indian Ocean Territory</option>
                                                            <option value="BRN">Brunei Darussalam</option>
                                                            <option value="BGR">Bulgaria</option>
                                                            <option value="BFA">Burkina Faso</option>
                                                            <option value="BDI">Burundi</option>
                                                            <option value="KHM">Cambodia</option>
                                                            <option value="CMR">Cameroon</option>
                                                            <option value="CAN">Canada</option>
                                                            <option value="CPV">Cape Verde</option>
                                                            <option value="CYM">Cayman Islands</option>
                                                            <option value="CAF">Central African Republic</option>
                                                            <option value="TCD">Chad</option>
                                                            <option value="CHL">Chile</option>
                                                            <option value="CHN">China</option>
                                                            <option value="CXR">Christmas Island</option>
                                                            <option value="CCK">Cocos (Keeling) Islands</option>
                                                            <option value="COL">Colombia</option>
                                                            <option value="COM">Comoros</option>
                                                            <option value="COG">Congo</option>
                                                            <option value="COD">Congo, the Democratic Republic of the</option>
                                                            <option value="COK">Cook Islands</option>
                                                            <option value="CRI">Costa Rica</option>
                                                            <option value="CIV">Côte d'Ivoire</option>
                                                            <option value="HRV">Croatia</option>
                                                            <option value="CUB">Cuba</option>
                                                            <option value="CUW">Curaçao</option>
                                                            <option value="CYP">Cyprus</option>
                                                            <option value="CZE">Czech Republic</option>
                                                            <option value="DNK">Denmark</option>
                                                            <option value="DJI">Djibouti</option>
                                                            <option value="DMA">Dominica</option>
                                                            <option value="DOM">Dominican Republic</option>
                                                            <option value="ECU">Ecuador</option>
                                                            <option value="EGY">Egypt</option>
                                                            <option value="SLV">El Salvador</option>
                                                            <option value="GNQ">Equatorial Guinea</option>
                                                            <option value="ERI">Eritrea</option>
                                                            <option value="EST">Estonia</option>
                                                            <option value="ETH">Ethiopia</option>
                                                            <option value="FLK">Falkland Islands (Malvinas)</option>
                                                            <option value="FRO">Faroe Islands</option>
                                                            <option value="FJI">Fiji</option>
                                                            <option value="FIN">Finland</option>
                                                            <option value="FRA">France</option>
                                                            <option value="GUF">French Guiana</option>
                                                            <option value="PYF">French Polynesia</option>
                                                            <option value="ATF">French Southern Territories</option>
                                                            <option value="GAB">Gabon</option>
                                                            <option value="GMB">Gambia</option>
                                                            <option value="GEO">Georgia</option>
                                                            <option value="DEU">Germany</option>
                                                            <option value="GHA">Ghana</option>
                                                            <option value="GIB">Gibraltar</option>
                                                            <option value="GRC">Greece</option>
                                                            <option value="GRL">Greenland</option>
                                                            <option value="GRD">Grenada</option>
                                                            <option value="GLP">Guadeloupe</option>
                                                            <option value="GUM">Guam</option>
                                                            <option value="GTM">Guatemala</option>
                                                            <option value="GGY">Guernsey</option>
                                                            <option value="GIN">Guinea</option>
                                                            <option value="GNB">Guinea-Bissau</option>
                                                            <option value="GUY">Guyana</option>
                                                            <option value="HTI">Haiti</option>
                                                            <option value="HMD">Heard Island and McDonald Islands</option>
                                                            <option value="VAT">Holy See (Vatican City State)</option>
                                                            <option value="HND">Honduras</option>
                                                            <option value="HKG">Hong Kong</option>
                                                            <option value="HUN">Hungary</option>
                                                            <option value="ISL">Iceland</option>
                                                            <option value="IND">India</option>
                                                            <option value="IDN">Indonesia</option>
                                                            <option value="IRN">Iran, Islamic Republic of</option>
                                                            <option value="IRQ">Iraq</option>
                                                            <option value="IRL">Ireland</option>
                                                            <option value="IMN">Isle of Man</option>
                                                            <option value="ISR">Israel</option>
                                                            <option value="ITA">Italy</option>
                                                            <option value="JAM">Jamaica</option>
                                                            <option value="JPN">Japan</option>
                                                            <option value="JEY">Jersey</option>
                                                            <option value="JOR">Jordan</option>
                                                            <option value="KAZ">Kazakhstan</option>
                                                            <option value="KEN">Kenya</option>
                                                            <option value="KIR">Kiribati</option>
                                                            <option value="PRK">Korea, Democratic People's Republic of</option>
                                                            <option value="KOR">Korea, Republic of</option>
                                                            <option value="KWT">Kuwait</option>
                                                            <option value="KGZ">Kyrgyzstan</option>
                                                            <option value="LAO">Lao People's Democratic Republic</option>
                                                            <option value="LVA">Latvia</option>
                                                            <option value="LBN">Lebanon</option>
                                                            <option value="LSO">Lesotho</option>
                                                            <option value="LBR">Liberia</option>
                                                            <option value="LBY">Libya</option>
                                                            <option value="LIE">Liechtenstein</option>
                                                            <option value="LTU">Lithuania</option>
                                                            <option value="LUX">Luxembourg</option>
                                                            <option value="MAC">Macao</option>
                                                            <option value="MKD">Macedonia, the former Yugoslav Republic of</option>
                                                            <option value="MDG">Madagascar</option>
                                                            <option value="MWI">Malawi</option>
                                                            <option value="MYS">Malaysia</option>
                                                            <option value="MDV">Maldives</option>
                                                            <option value="MLI">Mali</option>
                                                            <option value="MLT">Malta</option>
                                                            <option value="MHL">Marshall Islands</option>
                                                            <option value="MTQ">Martinique</option>
                                                            <option value="MRT">Mauritania</option>
                                                            <option value="MUS">Mauritius</option>
                                                            <option value="MYT">Mayotte</option>
                                                            <option value="MEX">Mexico</option>
                                                            <option value="FSM">Micronesia, Federated States of</option>
                                                            <option value="MDA">Moldova, Republic of</option>
                                                            <option value="MCO">Monaco</option>
                                                            <option value="MNG">Mongolia</option>
                                                            <option value="MNE">Montenegro</option>
                                                            <option value="MSR">Montserrat</option>
                                                            <option value="MAR">Morocco</option>
                                                            <option value="MOZ">Mozambique</option>
                                                            <option value="MMR">Myanmar</option>
                                                            <option value="NAM">Namibia</option>
                                                            <option value="NRU">Nauru</option>
                                                            <option value="NPL">Nepal</option>
                                                            <option value="NLD">Netherlands</option>
                                                            <option value="NCL">New Caledonia</option>
                                                            <option value="NZL">New Zealand</option>
                                                            <option value="NIC">Nicaragua</option>
                                                            <option value="NER">Niger</option>
                                                            <option value="NGA">Nigeria</option>
                                                            <option value="NIU">Niue</option>
                                                            <option value="NFK">Norfolk Island</option>
                                                            <option value="MNP">Northern Mariana Islands</option>
                                                            <option value="NOR">Norway</option>
                                                            <option value="OMN">Oman</option>
                                                            <option value="PAK">Pakistan</option>
                                                            <option value="PLW">Palau</option>
                                                            <option value="PSE">Palestinian Territory, Occupied</option>
                                                            <option value="PAN">Panama</option>
                                                            <option value="PNG">Papua New Guinea</option>
                                                            <option value="PRY">Paraguay</option>
                                                            <option value="PER">Peru</option>
                                                            <option value="PHL">Philippines</option>
                                                            <option value="PCN">Pitcairn</option>
                                                            <option value="POL">Poland</option>
                                                            <option value="PRT">Portugal</option>
                                                            <option value="PRI">Puerto Rico</option>
                                                            <option value="QAT">Qatar</option>
                                                            <option value="REU">Réunion</option>
                                                            <option value="ROU">Romania</option>
                                                            <option value="RUS">Russian Federation</option>
                                                            <option value="RWA">Rwanda</option>
                                                            <option value="BLM">Saint Barthélemy</option>
                                                            <option value="SHN">Saint Helena, Ascension and Tristan da Cunha</option>
                                                            <option value="KNA">Saint Kitts and Nevis</option>
                                                            <option value="LCA">Saint Lucia</option>
                                                            <option value="MAF">Saint Martin (French part)</option>
                                                            <option value="SPM">Saint Pierre and Miquelon</option>
                                                            <option value="VCT">Saint Vincent and the Grenadines</option>
                                                            <option value="WSM">Samoa</option>
                                                            <option value="SMR">San Marino</option>
                                                            <option value="STP">Sao Tome and Principe</option>
                                                            <option value="SAU">Saudi Arabia</option>
                                                            <option value="SEN">Senegal</option>
                                                            <option value="SRB">Serbia</option>
                                                            <option value="SYC">Seychelles</option>
                                                            <option value="SLE">Sierra Leone</option>
                                                            <option value="SGP">Singapore</option>
                                                            <option value="SXM">Sint Maarten (Dutch part)</option>
                                                            <option value="SVK">Slovakia</option>
                                                            <option value="SVN">Slovenia</option>
                                                            <option value="SLB">Solomon Islands</option>
                                                            <option value="SOM">Somalia</option>
                                                            <option value="ZAF">South Africa</option>
                                                            <option value="SGS">South Georgia and the South Sandwich Islands</option>
                                                            <option value="SSD">South Sudan</option>
                                                            <option value="ESP">Spain</option>
                                                            <option value="LKA">Sri Lanka</option>
                                                            <option value="SDN">Sudan</option>
                                                            <option value="SUR">Suriname</option>
                                                            <option value="SJM">Svalbard and Jan Mayen</option>
                                                            <option value="SWZ">Swaziland</option>
                                                            <option value="SWE">Sweden</option>
                                                            <option value="CHE">Switzerland</option>
                                                            <option value="SYR">Syrian Arab Republic</option>
                                                            <option value="TWN">Taiwan, Province of China</option>
                                                            <option value="TJK">Tajikistan</option>
                                                            <option value="TZA">Tanzania, United Republic of</option>
                                                            <option value="THA">Thailand</option>
                                                            <option value="TLS">Timor-Leste</option>
                                                            <option value="TGO">Togo</option>
                                                            <option value="TKL">Tokelau</option>
                                                            <option value="TON">Tonga</option>
                                                            <option value="TTO">Trinidad and Tobago</option>
                                                            <option value="TUN">Tunisia</option>
                                                            <option value="TUR">Turkey</option>
                                                            <option value="TKM">Turkmenistan</option>
                                                            <option value="TCA">Turks and Caicos Islands</option>
                                                            <option value="TUV">Tuvalu</option>
                                                            <option value="UGA">Uganda</option>
                                                            <option value="UKR">Ukraine</option>
                                                            <option value="ARE">United Arab Emirates</option>
                                                            <option value="GBR">United Kingdom</option>
                                                            <option value="USA">United States</option>
                                                            <option value="UMI">United States Minor Outlying Islands</option>
                                                            <option value="URY">Uruguay</option>
                                                            <option value="UZB">Uzbekistan</option>
                                                            <option value="VUT">Vanuatu</option>
                                                            <option value="VEN">Venezuela, Bolivarian Republic of</option>
                                                            <option value="VNM">Viet Nam</option>
                                                            <option value="VGB">Virgin Islands, British</option>
                                                            <option value="VIR">Virgin Islands, U.S.</option>
                                                            <option value="WLF">Wallis and Futuna</option>
                                                            <option value="ESH">Western Sahara</option>
                                                            <option value="YEM">Yemen</option>
                                                            <option value="ZMB">Zambia</option>
                                                            <option value="ZWE">Zimbabwe</option>
                                                        </select>
                                                   
                                                    </div>
                                                    @error('order_country')
                                                    <span class="valid-feedback">{{ $message }}</span>
                                                @enderror
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="mb-3">
                                                        <label for="exampleInputPassword1" class="form-label">Address</label>
                                                        <input class="form-control" type="text" name="user_address"
                                                        placeholder="Apartment, suite, unit etc. (optional)">
                                                    @error('user_address')
                                                        <span class="valid-feedback">{{ $message }}</span>
                                                    @enderror
                                                    </div>
                                                </div>

                                                <div class="col-md-4">
                                                    <div class="mb-3">
                                                        <label for="exampleInputPassword1" class="form-label">City *
                                                </label>
                                                        {{-- <input type="text" placeholder="Enter City" name="order_city"
                                                            class="form-control" id="exampleInputPassword1"> --}}
                                                    
                                                            <select    class="form-control" name="order_city"  id="Location" required>
                                                                <option value="" disabled selected>Select The City</option>
                                                                <option value="Islamabad">Islamabad</option>
                                                                <option value="" disabled>Punjab Cities</option>
                                                                <option value="Ahmed Nager Chatha">Ahmed Nager Chatha</option>
                                                                <option value="Ahmadpur East">Ahmadpur East</option>
                                                                <option value="Ali Khan Abad">Ali Khan Abad</option>
                                                                <option value="Alipur">Alipur</option>
                                                                <option value="Arifwala">Arifwala</option>
                                                                <option value="Attock">Attock</option>
                                                                <option value="Bhera">Bhera</option>
                                                                <option value="Bhalwal">Bhalwal</option>
                                                                <option value="Bahawalnagar">Bahawalnagar</option>
                                                                <option value="Bahawalpur">Bahawalpur</option>
                                                                <option value="Bhakkar">Bhakkar</option>
                                                                <option value="Burewala">Burewala</option>
                                                                <option value="Chillianwala">Chillianwala</option>
                                                                <option value="Chakwal">Chakwal</option>
                                                                <option value="Chichawatni">Chichawatni</option>
                                                                <option value="Chiniot">Chiniot</option>
                                                                <option value="Chishtian">Chishtian</option>
                                                                <option value="Daska">Daska</option>
                                                                <option value="Darya Khan">Darya Khan</option>
                                                                <option value="Dera Ghazi Khan">Dera Ghazi Khan</option>
                                                                <option value="Dhaular">Dhaular</option>
                                                                <option value="Dina">Dina</option>
                                                                <option value="Dinga">Dinga</option>
                                                                <option value="Dipalpur">Dipalpur</option>
                                                                <option value="Faisalabad">Faisalabad</option>
                                                                <option value="Ferozewala">Ferozewala</option>
                                                                <option value="Fateh Jhang">Fateh Jang</option>
                                                                <option value="Ghakhar Mandi">Ghakhar Mandi</option>
                                                                <option value="Gojra">Gojra</option>
                                                                <option value="Gujranwala">Gujranwala</option>
                                                                <option value="Gujrat">Gujrat</option>
                                                                <option value="Gujar Khan">Gujar Khan</option>
                                                                <option value="Hafizabad">Hafizabad</option>
                                                                <option value="Haroonabad">Haroonabad</option>
                                                                <option value="Hasilpur">Hasilpur</option>
                                                                <option value="Haveli Lakha">Haveli Lakha</option>
                                                                <option value="Jatoi">Jatoi</option>
                                                                <option value="Jalalpur">Jalalpur</option>
                                                                <option value="Jattan">Jattan</option>
                                                                <option value="Jampur">Jampur</option>
                                                                <option value="Jaranwala">Jaranwala</option>
                                                                <option value="Jhang">Jhang</option>
                                                                <option value="Jhelum">Jhelum</option>
                                                                <option value="Kalabagh">Kalabagh</option>
                                                                <option value="Karor Lal Esan">Karor Lal Esan</option>
                                                                <option value="Kasur">Kasur</option>
                                                                <option value="Kamalia">Kamalia</option>
                                                                <option value="Kamoke">Kamoke</option>
                                                                <option value="Khanewal">Khanewal</option>
                                                                <option value="Khanpur">Khanpur</option>
                                                                <option value="Kharian">Kharian</option>
                                                                <option value="Khushab">Khushab</option>
                                                                <option value="Kot Addu">Kot Addu</option>
                                                                <option value="Jauharabad">Jauharabad</option>
                                                                <option value="Lahore">Lahore</option>
                                                                <option value="Lalamusa">Lalamusa</option>
                                                                <option value="Layyah">Layyah</option>
                                                                <option value="Liaquat Pur">Liaquat Pur</option>
                                                                <option value="Lodhran">Lodhran</option>
                                                                <option value="Malakwal">Malakwal</option>
                                                                <option value="Mamoori">Mamoori</option>
                                                                <option value="Mailsi">Mailsi</option>
                                                                <option value="Mandi Bahauddin">Mandi Bahauddin</option>
                                                                <option value="Mian Channu">Mian Channu</option>
                                                                <option value="Mianwali">Mianwali</option>
                                                                <option value="Multan">Multan</option>
                                                                <option value="Murree">Murree</option>
                                                                <option value="Muridke">Muridke</option>
                                                                <option value="Mianwali Bangla">Mianwali Bangla</option>
                                                                <option value="Muzaffargarh">Muzaffargarh</option>
                                                                <option value="Narowal">Narowal</option>
                                                                <option value="Nankana Sahib">Nankana Sahib</option>
                                                                <option value="Okara">Okara</option>
                                                                <option value="Renala Khurd">Renala Khurd</option>
                                                                <option value="Pakpattan">Pakpattan</option>
                                                                <option value="Pattoki">Pattoki</option>
                                                                <option value="Pir Mahal">Pir Mahal</option>
                                                                <option value="Qaimpur">Qaimpur</option>
                                                                <option value="Qila Didar Singh">Qila Didar Singh</option>
                                                                <option value="Rabwah">Rabwah</option>
                                                                <option value="Raiwind">Raiwind</option>
                                                                <option value="Rajanpur">Rajanpur</option>
                                                                <option value="Rahim Yar Khan">Rahim Yar Khan</option>
                                                                <option value="Rawalpindi">Rawalpindi</option>
                                                                <option value="Sadiqabad">Sadiqabad</option>
                                                                <option value="Safdarabad">Safdarabad</option>
                                                                <option value="Sahiwal">Sahiwal</option>
                                                                <option value="Sangla Hill">Sangla Hill</option>
                                                                <option value="Sarai Alamgir">Sarai Alamgir</option>
                                                                <option value="Sargodha">Sargodha</option>
                                                                <option value="Shakargarh">Shakargarh</option>
                                                                <option value="Sheikhupura">Sheikhupura</option>
                                                                <option value="Sialkot">Sialkot</option>
                                                                <option value="Sohawa">Sohawa</option>
                                                                <option value="Soianwala">Soianwala</option>
                                                                <option value="Siranwali">Siranwali</option>
                                                                <option value="Talagang">Talagang</option>
                                                                <option value="Taxila">Taxila</option>
                                                                <option value="Toba Tek Singh">Toba Tek Singh</option>
                                                                <option value="Vehari">Vehari</option>
                                                                <option value="Wah Cantonment">Wah Cantonment</option>
                                                                <option value="Wazirabad">Wazirabad</option>
                                                                <option value="" disabled>Sindh Cities</option>
                                                                <option value="Badin">Badin</option>
                                                                <option value="Bhirkan">Bhirkan</option>
                                                                <option value="Rajo Khanani">Rajo Khanani</option>
                                                                <option value="Chak">Chak</option>
                                                                <option value="Dadu">Dadu</option>
                                                                <option value="Digri">Digri</option>
                                                                <option value="Diplo">Diplo</option>
                                                                <option value="Dokri">Dokri</option>
                                                                <option value="Ghotki">Ghotki</option>
                                                                <option value="Haala">Haala</option>
                                                                <option value="Hyderabad">Hyderabad</option>
                                                                <option value="Islamkot">Islamkot</option>
                                                                <option value="Jacobabad">Jacobabad</option>
                                                                <option value="Jamshoro">Jamshoro</option>
                                                                <option value="Jungshahi">Jungshahi</option>
                                                                <option value="Kandhkot">Kandhkot</option>
                                                                <option value="Kandiaro">Kandiaro</option>
                                                                <option value="Karachi">Karachi</option>
                                                                <option value="Kashmore">Kashmore</option>
                                                                <option value="Keti Bandar">Keti Bandar</option>
                                                                <option value="Khairpur">Khairpur</option>
                                                                <option value="Kotri">Kotri</option>
                                                                <option value="Larkana">Larkana</option>
                                                                <option value="Matiari">Matiari</option>
                                                                <option value="Mehar">Mehar</option>
                                                                <option value="Mirpur Khas">Mirpur Khas</option>
                                                                <option value="Mithani">Mithani</option>
                                                                <option value="Mithi">Mithi</option>
                                                                <option value="Mehrabpur">Mehrabpur</option>
                                                                <option value="Moro">Moro</option>
                                                                <option value="Nagarparkar">Nagarparkar</option>
                                                                <option value="Naudero">Naudero</option>
                                                                <option value="Naushahro Feroze">Naushahro Feroze</option>
                                                                <option value="Naushara">Naushara</option>
                                                                <option value="Nawabshah">Nawabshah</option>
                                                                <option value="Nazimabad">Nazimabad</option>
                                                                <option value="Qambar">Qambar</option>
                                                                <option value="Qasimabad">Qasimabad</option>
                                                                <option value="Ranipur">Ranipur</option>
                                                                <option value="Ratodero">Ratodero</option>
                                                                <option value="Rohri">Rohri</option>
                                                                <option value="Sakrand">Sakrand</option>
                                                                <option value="Sanghar">Sanghar</option>
                                                                <option value="Shahbandar">Shahbandar</option>
                                                                <option value="Shahdadkot">Shahdadkot</option>
                                                                <option value="Shahdadpur">Shahdadpur</option>
                                                                <option value="Shahpur Chakar">Shahpur Chakar</option>
                                                                <option value="Shikarpaur">Shikarpaur</option>
                                                                <option value="Sukkur">Sukkur</option>
                                                                <option value="Tangwani">Tangwani</option>
                                                                <option value="Tando Adam Khan">Tando Adam Khan</option>
                                                                <option value="Tando Allahyar">Tando Allahyar</option>
                                                                <option value="Tando Muhammad Khan">Tando Muhammad Khan</option>
                                                                <option value="Thatta">Thatta</option>
                                                                <option value="Umerkot">Umerkot</option>
                                                                <option value="Warah">Warah</option>
                                                                <option value="" disabled>Khyber Cities</option>
                                                                <option value="Abbottabad">Abbottabad</option>
                                                                <option value="Adezai">Adezai</option>
                                                                <option value="Alpuri">Alpuri</option>
                                                                <option value="Akora Khattak">Akora Khattak</option>
                                                                <option value="Ayubia">Ayubia</option>
                                                                <option value="Banda Daud Shah">Banda Daud Shah</option>
                                                                <option value="Bannu">Bannu</option>
                                                                <option value="Batkhela">Batkhela</option>
                                                                <option value="Battagram">Battagram</option>
                                                                <option value="Birote">Birote</option>
                                                                <option value="Chakdara">Chakdara</option>
                                                                <option value="Charsadda">Charsadda</option>
                                                                <option value="Chitral">Chitral</option>
                                                                <option value="Daggar">Daggar</option>
                                                                <option value="Dargai">Dargai</option>
                                                                <option value="Darya Khan">Darya Khan</option>
                                                                <option value="Dera Ismail Khan">Dera Ismail Khan</option>
                                                                <option value="Doaba">Doaba</option>
                                                                <option value="Dir">Dir</option>
                                                                <option value="Drosh">Drosh</option>
                                                                <option value="Hangu">Hangu</option>
                                                                <option value="Haripur">Haripur</option>
                                                                <option value="Karak">Karak</option>
                                                                <option value="Kohat">Kohat</option>
                                                                <option value="Kulachi">Kulachi</option>
                                                                <option value="Lakki Marwat">Lakki Marwat</option>
                                                                <option value="Latamber">Latamber</option>
                                                                <option value="Madyan">Madyan</option>
                                                                <option value="Mansehra">Mansehra</option>
                                                                <option value="Mardan">Mardan</option>
                                                                <option value="Mastuj">Mastuj</option>
                                                                <option value="Mingora">Mingora</option>
                                                                <option value="Nowshera">Nowshera</option>
                                                                <option value="Paharpur">Paharpur</option>
                                                                <option value="Pabbi">Pabbi</option>
                                                                <option value="Peshawar">Peshawar</option>
                                                                <option value="Saidu Sharif">Saidu Sharif</option>
                                                                <option value="Shorkot">Shorkot</option>
                                                                <option value="Shewa Adda">Shewa Adda</option>
                                                                <option value="Swabi">Swabi</option>
                                                                <option value="Swat">Swat</option>
                                                                <option value="Tangi">Tangi</option>
                                                                <option value="Tank">Tank</option>
                                                                <option value="Thall">Thall</option>
                                                                <option value="Timergara">Timergara</option>
                                                                <option value="Tordher">Tordher</option>
                                                                <option value="" disabled>Balochistan Cities</option>
                                                                <option value="Awaran">Awaran</option>
                                                                <option value="Barkhan">Barkhan</option>
                                                                <option value="Chagai">Chagai</option>
                                                                <option value="Dera Bugti">Dera Bugti</option>
                                                                <option value="Gwadar">Gwadar</option>
                                                                <option value="Harnai">Harnai</option>
                                                                <option value="Jafarabad">Jafarabad</option>
                                                                <option value="Jhal Magsi">Jhal Magsi</option>
                                                                <option value="Kacchi">Kacchi</option>
                                                                <option value="Kalat">Kalat</option>
                                                                <option value="Kech">Kech</option>
                                                                <option value="Kharan">Kharan</option>
                                                                <option value="Khuzdar">Khuzdar</option>
                                                                <option value="Killa Abdullah">Killa Abdullah</option>
                                                                <option value="Killa Saifullah">Killa Saifullah</option>
                                                                <option value="Kohlu">Kohlu</option>
                                                                <option value="Lasbela">Lasbela</option>
                                                                <option value="Lehri">Lehri</option>
                                                                <option value="Loralai">Loralai</option>
                                                                <option value="Mastung">Mastung</option>
                                                                <option value="Musakhel">Musakhel</option>
                                                                <option value="Nasirabad">Nasirabad</option>
                                                                <option value="Nushki">Nushki</option>
                                                                <option value="Panjgur">Panjgur</option>
                                                                <option value="Pishin Valley">Pishin Valley</option>
                                                                <option value="Quetta">Quetta</option>
                                                                <option value="Sherani">Sherani</option>
                                                                <option value="Sibi">Sibi</option>
                                                                <option value="Sohbatpur">Sohbatpur</option>
                                                                <option value="Washuk">Washuk</option>
                                                                <option value="Zhob">Zhob</option>
                                                                <option value="Ziarat">Ziarat</option>
                                                              </select>

                                                            @error('order_city')
                                                            <span class="valid-feedback">{{ $message }}</span>
                                                        @enderror
                                                    </div>
                                                </div>
                                                <div class="col-md-8">
                                                    <div class="mb-3">
                                                        <label for="exampleInputPassword1" class="form-label">
                                                            State</label>
                                                        <input type="text" placeholder="Enter State"
                                                            class="form-control" id="exampleInputPassword1" name="order_state">
                                                      
                                                            @error('order_state')
                                                            <span class="valid-feedback">{{ $message }}</span>
                                                        @enderror
                                                    </div>
                                                </div>
                                                <div class="col-md-8">
                                                    <div class="mb-3">
                                                        <label for="exampleInputPassword1" class="form-label">
                                                            Street Address</label>
                                                        <input type="text" placeholder="Enter State"
                                                            class="form-control" id="exampleInputPassword1" name="street_address">
                                                      
                                                            @error('street_address')
                                                            <span class="valid-feedback">{{ $message }}</span>
                                                        @enderror
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="mb-3">
                                                        <label for="exampleInputPassword1" class="form-label">
                                                            Postcode / ZIP</label>
                                                        <input type="text" placeholder="Enter State"
                                                            class="form-control" id="exampleInputPassword1" name="Postcode">
                                                      
                                                            @error('Postcode')
                                                            <span class="valid-feedback">{{ $message }}</span>
                                                        @enderror
                                                    </div>
                                                  
                                                </div>


                                                
                                            </div>

                                        


                                        </div>

                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            
                                            <input class="form-check-input" type="checkbox" value=""
                                                id="invalidCheck" required="">
                                            <label class="form-check-label" for="invalidCheck">
                                                Agree to terms and conditions
                                            </label>

                                        </div>
                                    </div>
                                    <button class="btn btn_book">Confirm Booking</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card_booking_box">
                            <div class="rooms_details">
                                <div class="card_head">
                                    Product Details
                                </div>
                                <div class="heading_hotel">


                                    <div class="roo_imge">
                                        <img src="https://adminlaravell.foodbaskit.com/public/images/{{ $getProd->images }}"
                                            class="img-fluid" alt="" srcset="">
                                    </div>

                                    <div class="detail_box">
                                        {{-- <div class="ratings">
                                            {{ $getProd->ratings }}
                                            <div class="icon">
                                                <i class="fa-solid fa-star"></i>
                                            </div>
                                            <div class="icon">
                                                <i class="fa-solid fa-star"></i>
                                            </div>
                                            <div class="icon">
                                                <i class="fa-solid fa-star"></i>
                                            </div>
                                            <div class="icon">
                                                <i class="fa-solid fa-star"></i>
                                            </div>
                                            <div class="icon">
                                                <i class="far fa-star"></i>
                                            </div>

                                        </div> --}}
                                        <div class="ratings">
                                           
                                            @if ($getProd->ratings > 0)
                                            @php
                                                $maxStars = min($getProd->ratings, 5); // Limit maximum stars to 5
                                            @endphp
                                            @for ($i = 1; $i <= $maxStars; $i++)
                                            <div class="icon">
                                                <i class="far fa-star"></i>
                                            </div>
                                            @endfor
                                            @if ($getProd->ratings > 5)
                                                <span> ({{ $getProd->ratings }})</span>
                                            @endif
                                        @else
                                            <i class="fa fa-star"></i>
                                            <span> (No ratings yet)</span>
                                        @endif
                                        

                                        </div>
                                        <div class="name">
                                            {{ $getProd->name }}
                                        </div>
                                     <div class="city">
                                    ({{ $getProd->category }})
                                     </div>
                                    </div>
                                    <hr>
                                    <div class="check_in_out">
                                        <ul class="list-items list-items-2 py-2">
                                            <li><span>Price:</span>{{ $getProd->price }}</li>
                                            <li><span>Old Price:</span>{{ $getProd->old_price }}</li>
                                        </ul>
                                    </div>
                                    <hr>
                                    <div class="mt-1 mb-1 text-white">
                                        Product Type
                                    </div>
                                    <hr>
                                    <div class="room_details">
                                        <ul class="list-items list-items-2 py-3">
                                            <li><span>Product Quantity:</span>  {{ $quantity }} </li>
                                            <li><span>Product Price:</span>PKR {{ $getProd->price }}.00</li>
                                            <li><span>Delivery Charges:</span>PKR  200 </li>
                                        


                                         

                                        </ul>
                                    </div>
                                    <hr>
                                    <div class="other_room_dtails">
                                     
                                        <ul class="list-items list-items-2 pt-3">
                                            <li><span>Sub Total:</span>PKR {{ $totalPrice+200 }} </li>
                                           
                                            <hr>
                                            <li style="font-size:22px"><span>Price:</span><strong>PKR <span>{{ $totalPrice+200 }}</span></strong>
                                            </li>
                                            <hr>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
            {{-- end-contaimer --}}
        </div>
    </main>
@endsection
