@extends('Layout.App')
@section('content')
    <main>
        <section class="terms_condition">
            <div class="container">
                <div class="card_wrap v2">
                    <div class="card_body">
                        <div class="main_heading">ourt terms <span class="and">&amp;</span> conditions</div>
                        <div class="headings_bar">
                            <h2>Return/ refund policy</h2>
                            <div class="paragraph">Always record video while opening the parcel if during this any product is
                                missing or found break we will send you the product in next 5-7 working days.
                                We don’t give any refund policy if you don’t like the product or the product doesn’t suit
                                you.</div>
                            <div class="paragraph">
                                We will not take any claims if the product will not suit you or cause any allergic reactions
                                . To avoid such inconveniences do read the ingredients their concentration in the
                                description to avoid any reaction on your skin . Always do a patch test before starting any
                                new product.
                            </div>
                        </div>
                        <div class="headings_bar">
                            <h2>Delivery time</h2>
                            <div class="paragraph">We usually take 7-10 working days but due to weather conditions or any
                                political issues or any other issue it might take 10-15 days in delivery 📦 </div>
                        </div>
                        <div class="headings_bar">
                            <h2>products</h2>
                            <div class="paragraph">Our products are formulated and tested by a third company having
                                certified people and they are totally halal and cruelty free.</div>
                        </div>
                        <div class="headings_bar">
                            <h2><strong>
                                    FBR
                                </strong> </h2>
                            <div class="paragraph">Our company is a registered company in FBR .</div>
                        </div>

                    </div>
                </div>
            </div>
        </section>
    </main>
@endsection
