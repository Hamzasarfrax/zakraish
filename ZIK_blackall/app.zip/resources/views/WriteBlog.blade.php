@extends('Layout.App')
@section('content')
    <main>
        <div class="write_blogs___page">
            <div class="container">
                @if (Session::has('success'))
                    <div class="toast" id="toast_container">
                        <div class="toast-content">
                            <i class="fa-solid fa-check toast-check"></i>
                            <div class="message">
                                <span class="message-text text-1">Success</span>
                                <span class="message-text text-2"> {{ Session::get('success') }}</span>
                            </div>
                        </div>
                        <i class="fa-solid fa-xmark toast-close"></i>
                        <div class="progress"></div>
                    </div>
                @elseif(Session::has('error'))
                    <div class="toast" id="toast_container">
                        <div class="toast-content">
                            <i class="fa-solid fa-check toast-check"></i>
                            <div class="message">
                                <span class="message-text text-1">Error</span>
                                <span class="message-text text-2"> {{ Session::get('error') }}</span>
                            </div>
                        </div>

                        <i class="fa-solid fa-xmark toast-close"></i>
                        <div class="progress"></div>
                    </div>
                @endif
                <div class="shoop_all_____category_data">

                    <div class="breadcrumb__list">
                        <div class="detl">
                            <a href="/">
                                <div class="cion">
                                    <i class="fa-solid fa-house"></i>
                                </div>
                                <div class="name">
                                    home</div>
                            </a>

                            <a>
                                Write Blogs
                            </a>
                        </div>
                    </div>
                </div>
                <div class="heading_main">
                    Write Blog About us
                </div>

                <div class="row">
                    <div class="col-md-7">
                        <div class="form_add_for_blogs">
                            <form action="/storeclientreviews" method="POST" enctype="multipart/form-data">

                                @csrf
                                @method('POST')

                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Give Rating's</label>
                                    <div class="revies_stars">
                                        <i class="fa-regular fa-star" data-val="1"> </i>
                                        <i class="fa-regular fa-star" data-val="2"></i>
                                        <i class="fa-regular fa-star" data-val="3"></i>
                                        <i class="fa-regular fa-star" data-val="4"></i>
                                        <i class="fa-regular fa-star" data-val="5"></i>
                                    </div>
                                    <input type="hidden" name="client_reviews" id="reviews_products" class="form-control"
                                        placeholder="" value="1">
                                </div>
                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Your Name</label>
                                    <input type="text" class="form-control" name="client_name" id="exampleInputEmail1"
                                        aria-describedby="emailHelp">

                                </div>
                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label"> Your Email </label>
                                    <input type="email" class="form-control" name="client_email" id="exampleInputEmail1"
                                        aria-describedby="emailHelp">
                                    <div id="emailHelp" class="form-text">We'll never share your email with anyone else.
                                    </div>
                                </div>

                                <div class="mb-3" id="hiden">
                                    <div class="form_select">
                                        <label for="exampleInputEmail1" class="form-label">
                                            <i class="fa-solid fa-upload"></i>
                                            Drag&Drop
                                            <input type="file" name="client_image" class="form-control" id="files"
                                                aria-describedby="emailHelp">
                                        </label>
                                        <div id="emailHelp" class="form-text">We'll never share your Image with anyone else.
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label"> Your Message</label>
                                 
                                    <textarea class="form-control" name="client_message" placeholder="Leave a comment here" id="floatingTextarea"></textarea>

                                </div>
                                <div class="mb-3">
                                    <label for="exampleInputPassword1" class="form-label">Your description</label>
                                    <textarea class="form-control" name="client_description" placeholder="Leave a comment here" id="floatingTextarea"></textarea>
                                </div>

                             
                                <button type="submit" class="btn w-100  btn_main">Submit</button>
                            </form>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="card_write_blogs">
                            <div class="card_img">
                                <img class="img-fluid" src="" id="uploadedImagesContainer"></img>
                            </div>
                            <div class="card_next_details">
                                <div class="card_blog_reviews">
                                    <div class="revies_stars">
                                        <i class="fa-regular fa-star" data-val="1"> </i>
                                        <i class="fa-regular fa-star" data-val="2"></i>
                                        <i class="fa-regular fa-star" data-val="3"></i>
                                        <i class="fa-regular fa-star" data-val="4"></i>
                                        <i class="fa-regular fa-star" data-val="5"></i>
                                    </div>
                                </div>
                                <div class="blog_name">
                                    name
                                </div>
                                <div class="blog_email">
                                    email
                                </div>
                                <div class="desciption_blog">
                                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, totam?...
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script>
            let files = document.getElementById('files');
            let img = document.getElementById('uploadedImagesContainer');

            files.addEventListener('change', function(e) {
                if (e.target.files.length > 0) {
                    img.style.display = 'block';
        files.style.display = 'none';
        
                    document.getElementById('hiden').style.display = 'none';;
                    let file = e.target.files[0];
                    let url = URL.createObjectURL(file);
                    img.src = url;
                }
            });
        </script>
    </main>
@endsection
