@extends('Layout.App')
@section('content')
<main>
     <div class="blog_details___listing">
<div class="container">
     <div class="heading_main">
          <h3>
               Details Of
          </h3>
          <h1>
               Blog {{$blogdetails->client_name}}
          </h1>
     </div>

     <div class="row">
          <div class="col-md-6">
             <div class="blog_attract_details___us">
                <div class="blog_icon_with_text">
                   <div class="flexis">
                      <div class="ico">
                         <i class="fa-solid fa-calendar-days"></i>
                      </div>
                      <div class="title">
                    
               {{ date('M d Y', strtotime($blogdetails->created_at)) }}
                      </div>
                   </div>
                   <div class="flexis">
                      <div class="ico">
                         <i class="fa-solid fa-briefcase"></i>
                      </div>
                      <div class="title">
                         Announcements 
                      </div>
                   </div>
                </div>
             </div>
             <div class="blog_images">
                <img src="{{ asset('/public/client_reviews/' . $blogdetails->client_image) }}" class="img-fluid rounded" alt="details_images_____bog">
                     
             </div>
             <div class="blog_majoor_____details">
                <div class="heading">
                   <h3>
                      blog Information
                   </h3>
                </div>
               

              <p>
<p>
{{$blogdetails->client_message}}
</p>
<br>
<hr>
<p>
{{$blogdetails->client_description}}
</p>
              </p>
             </div>
          </div>
          <div class="col-md-6">
             <div class="search_bard_for____blog">
                <div class="mb-3">
                   <label for=""> search blog</label>
                   <div class="search_bloging_adds">
                     <div class="search_tag">
                      <input type="search" class="form-control" id="search_blogs" aria-describedby="blogs">
                   <div class="icons">
                      <i class="fa-solid fa-magnifying-glass"></i>
                   </div>
                     </div>

                     <div class="dropdown_searching">

<ul id="blog_search_listing">

</ul>

                     </div>
                   </div>
                </div>
             </div>
             <div class="blog_details_all_____small">
                <div class="flexis_blogs">
                   <div class="title">
                      blog name
                   </div>
                   <div class="value">
                      {{$blogdetails->client_name}}
                   </div>
                </div>
            
                <div class="flexis_blogs">
                   <div class="title">
                      blog created at
                   </div>
                   <div class="value">
                  {{ date('M d Y', strtotime($blogdetails->created_at)) }}
                   </div>
                </div>
             </div>
             <div class="latest_trends____blogs">
                <div class="main_text">
                   <h1>
                      Latest Blogs
                   </h1>
                </div>
                <div class="row">
                @foreach ($recentlyCreatedBlogs as $blog)
                                           <div class="col-md-12">
                <a href="/blog_details/{{$blog->encrypt_id}}">
                <div class="blog_lates_card">
                   <div class="body_card_latest">
                      <div class="blog_img">
                         <img src="{{ asset('/public/client_reviews/' . $blog->client_image) }}" class="img-fluid rounded" alt="details_images_____bog">
                      </div>
                      <div class="blog_small_deatils">
                         <div class="date">
                       {{ date('M d Y', strtotime($blog->created_at)) }}
                         </div>
                         <div class="name">
                            {{$blog->client_name}}
                         </div>
                         <div class="temp">
                            Active
                         </div>
                      </div>
                   </div>
                </div>
                 </a>
             </div>
                @endforeach
            
                                 
                                    
                </div>
             </div>
          </div>
       </div>
</div>

     </div>
</main>

@endsection