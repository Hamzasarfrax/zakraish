@extends('Layout.App')
@section('content')
    <div class="about____us__page">
        <div class="main_img">
            <div class="img">
                <img src="{{ asset('/public/Asset/Images/aboutus.jpg') }}"
                    class="img-fluid" alt="">
            </div>
            <div class="text_content_center">
                <div class="details__fer">
                    <h1>
                        About Us
                    </h1>

                    <div class="text">
                        A leader in prestige omni-retail, our mission at ZAKRIAISH is to create a welcoming beauty
                        shopping experience for all and inspire fearlessness in our community.
                    </div>
                </div>
            </div>
        </div>
        <main>
            <div class="all_details__about__us__page">
                <div class="container">
                    <div class="our_story" id="our_story">
                        <div class="heading_main">
                            <h1>
                                Our story
                            </h1>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="our_story_img">
                                    <img src="{{ asset('/public/Asset/Images/story.png') }}" class="img-fluid"
                                        alt="our_story_img">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="our_story__text">
                                    <h1>
                                        All Your confidence need is Zakriaish

                                    </h1>
                                    <div class="all_text">
                                        <p class="title"> “Be The jaw-dropper , Be the Bold You”</p>
                                        <p>
                                            Never be afraid to be yourself , our aim
                                            is to make you confident and beautiful by providing best products for your hair
                                            and skin .
                                            Zakriaish is the first and only halal vegan brand that is cruelty free and
                                            provides best quality products .

                                        </p>
                                        <p>
                                            Let us help you make the most beautiful version of yourself bt bringing you
                                            Celestial yet sinful look .
                                            Halal products made and rebrand in pakistan 🇵🇰.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="latest__news mt-5 mb-5" id="latest_news">
                        <div class="heading_main mb-5">
                            <h1>
                                Latest New's
                            </h1>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="latest_text">
                                    <div class="our_story__text">
                                        <h1>
                                            ALL YOUR BEAUTY NEEDS
                                        </h1>
                                        <div class="all_text">
                                            <p class="title"> “Be the Jaw-dropper, be the BOLD u”</p>
                                            <p>
                                                Get upto 50% off on your next purchase by sharing your haircare and skincare
                                                journey of zakriaish.
                                            </p>
                                            <p>
                                                Click 3-4 picture of before and after and send us with a review to get
                                                discount
                                            </p>
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="latest_img">
                                    <img src="{{ asset('/public/Asset/Images/latest.avif') }}" class="img-fluid"
                                        alt="">
                                </div>
                            </div>
                        </div>




                    </div>
                </div>
            </div>

    </div>
    </main>
@endsection
