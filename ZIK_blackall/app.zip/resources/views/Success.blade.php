@extends('Layout.App') 
@section('content')
<main>
   <div class="container mt-sm-5">
     @if (session()->has('success'))
     <div class="sweet_alerts_messages">
         <div class="mesg_box success">
             <div class="mesg">
                 {{ session('success') }}
             </div>
             <div class="close">
                 <i class="fa-solid fa-xmark toast-close"></i>
             </div>
             <div class="progress"></div>
         </div>
       
     </div>
    @endif
    
    @if (session()->has('error'))
     <div class="sweet_alerts_messages">
         <div class="mesg_box error">
             <div class="mesg">
                 {{ session('error') }}
             </div>
             <div class="close">
                 <i class="fa-solid fa-xmark toast-close"></i>
             </div>
             <div class="progress"></div>
         </div>
       
     </div>
    @endif
<div class="succes_page">
    <div class="row">
        <div class="col-md-12">
             <div class="card_message">
        <div class="cardbody">
<h1>
    Thanks For visiting zakriaish
</h1>
<div class="btn_goo">
   <a href="/" > Go Back For Shoping</a>
</div>
<div class="check_icons">
    <i class="fas fa-check-circle"></i>
</div>
        </div>
             </div>
        </div>
   </div>
</div>
   </div>
</main>
@endsection