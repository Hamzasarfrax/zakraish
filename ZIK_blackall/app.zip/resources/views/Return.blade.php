@extends('Layout.App')
@section('content')
    <main>
        <div class="
     return_and___refund">
     @if (session()->has('success'))
     <div class="sweet_alerts_messages">
         <div class="mesg_box success">
             <div class="mesg">
                 {{ session('success') }}
             </div>
             <div class="close">
                 <i class="fa-solid fa-xmark toast-close"></i>
             </div>
             <div class="progress"></div>
         </div>
       
     </div>
    @endif
    
    @if (session()->has('error'))
     <div class="sweet_alerts_messages">
         <div class="mesg_box error">
             <div class="mesg">
                 {{ session('error') }}
             </div>
             <div class="close">
                 <i class="fa-solid fa-xmark toast-close"></i>
             </div>
             <div class="progress"></div>
         </div>
       
     </div>
    @endif

            <div class="container">
                <div class="heading_main">
                    <h4>
                        We are providing you
                    </h4>
                    <h1>
                        Return&Refund
                    </h1>
                </div>

                <div class="track_refund">
                    <div class="card_wrap v2">
                        <div class="card_body">
                            <form action="/Returnrefund" method="POST">
                                @csrf
                                @method('post')
                                <div class="row">
                                    <div class="col-md-5">
                                        <div class="forms">
                                            <input type="text" class="form-control" name="order_id" id="formGroupExampleInput"
                                                placeholder="Enter Your Order Id">
                                        </div>
                                    </div>
                                    <div class="col-md-5">
                                        <div class="forms">
                                            <input type="number" class="form-control" name="contact_no" id="formGroupExampleInput"
                                                placeholder="Enter Your Contact No">
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <button type="submit" class="btn btn_fund_return">
                                            Return&Refund
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>


                <div class="how__its_work">
<div class="text-center mt-5 mb-5">
     <h1>
          How It's Work
     </h1>
</div>


<div class="work_steps">
<div class="parent_box">

     <div class="details">
          <div class="icon">
               <i class="fa-solid fa-hand-point-up"></i>
          </div>
          <div class="name">
               Select items to return
          </div>
     </div>

     <div class="details">
          <div class="icon">
               <i class="fa-solid fa-dollar-sign"></i>
          </div>
          <div class="name">
               Get a refund confirmation
          </div>
     </div>
     <div class="details">
          <div class="icon">
               <i class="fa-solid fa-truck"></i>
          </div>
          <div class="name">
               Send the return back to us
          </div>
     </div>
</div>

</div>

<div class="row">
    <div class="mt-5 mb-5">
<div class="text-left text-capitalize">
<p>
    Return/ refund policy:
    Always record video while opening the parcel if during this any product is missing or found broken we will send you the product in the next 5-7 working days. 
    <br>
    <div>
    <b>
        note( if you dont provide us vedio so we are unable to provide you a refund)
    </b>
    </div>

</p>


<p>
    We don’t give any refund policy if you don’t like the product or the product doesn’t suit you.
    We will not take any claims if the product will not suit you or cause any allergic reactions. To avoid such inconveniences do read the ingredients and their concentration in the description to avoid any reaction on your skin. Always do a patch test before starting any new product.
</p>

<p>
    Delivery time :
    We usually take 7-10 working days but due to weather conditions or any political issues or any other issue, it might take 10-15 days in delivery 📦 
</p>

<p>
    Our products are formulated and tested by a third company having certified people and they are totally halal and cruelty free.
</p>

<p>

    Our company is a registered company in <strong>FBR</strong> .
</p>
</div>
    </div>
</div>
                </div>
            </div>


        </div>



    </main>
@endsection
