@extends('Layout.App')
@section('content')
    <main>
        <div class="cart_details___of_sepecific___products">


       

            @if (session()->has('error'))
                <div class="sweet_alerts_messages">
                    <div class="mesg_box error">
                        <div class="mesg">
                            {{ session('error') }}
                        </div>
                        <div class="close">
                            <i class="fa-solid fa-xmark toast-close"></i>
                        </div>
                        <div class="progress"></div>
                    </div>

                </div>
            @endif

            <div class="container">
                <div class="heading_main">
                    <h1>
                        product details
                    </h1>
                </div>

                <div class="row">
                    <div class="product______details_menu">
                        <div class="menus">
                            <li>
                                <a href="/">
                                    <div class="icon">
                                        <i class="fa-solid fa-house"></i>
                                    </div>
                                    <div class="title">
                                        home
                                    </div>
                                </a>
                            </li>

                            <li>
                                <a data-id="red">

                                    <div class="title">
                                        {{ $prod->product_type }}
                                    </div>
                                </a>
                            </li>

                            <li>
                                <a data-id="red">
                                    <div class="title">
                                        {{ $prod->category }}
                                    </div>
                                </a>
                            </li>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="product_all___images">
                            <div class="slider___product_img">

                                <div class="main_top___slide">
                                    <img src="https://adminlaravell.foodbaskit.com/public/images/{{ $prod->images }}"
                                        class="img-fluid" id="main_product_img" alt="product">
                                </div>
                                <div class="small_slides">
                                    <div class="bottom_top___slider">
                                        @if ($prod->images2)
                                            <div>
                                                <div class="imgs_for_details">
                                                    <img src="https://adminlaravell.foodbaskit.com/public/images/{{ $prod->images2 }}"
                                                        class="img-fluid" alt="">
                                                </div>
                                            </div>
                                        @endif

                                        @if ($prod->images3)
                                            <div>
                                                <div class="imgs_for_details">
                                                    <img src="https://adminlaravell.foodbaskit.com/public/images/{{ $prod->images3 }}"
                                                        class="img-fluid" alt="">
                                                </div>
                                            </div>
                                        @endif

                                        @if ($prod->images4)
                                            <div>
                                                <div class="imgs_for_details">
                                                    <img src="https://adminlaravell.foodbaskit.com/public/images/{{ $prod->images4 }}"
                                                        class="img-fluid" alt="">
                                                </div>
                                            </div>
                                        @endif

                                        @if ($prod->images)
                                            <div>
                                                <div class="imgs_for_details">
                                                    <img src="https://adminlaravell.foodbaskit.com/public/images/{{ $prod->images }}"
                                                        class="img-fluid" alt="">
                                                </div>
                                            </div>
                                        @endif
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="product___detail___of_all__settings">
                            <div class="heading_prod">
                                <h4>
                                    {{ $prod->category }}
                                </h4>

                                <h2>
                                    {{ $prod->name }}
                                </h2>
                            </div>

                            <div class="stock__and__reviews">
                                <div class="stocks">
                                    in-stock
                                </div>
                                <div class="reviews">
                                    @if ($prod->ratings > 0)
                                        @php
                                            $maxStars = min($prod->ratings, 5); // Limit maximum stars to 5
                                        @endphp
                                        @for ($i = 1; $i <= $maxStars; $i++)
                                            <i class="fa fa-star"></i>
                                        @endfor
                                        @if ($prod->ratings > 5)
                                            <span> ({{ $prod->ratings }})</span>
                                        @endif
                                    @else
                                        <i class="fa fa-star"></i>
                                        <span> (No ratings yet)</span>
                                    @endif


                                </div>

                            </div>

                            <div class="prod_desc">
                                {{ $prod->description }}
                            </div>
                            <div class="prod_price">
                                <div class="old_price">
                                    <span>PKR:</span> {{ $prod->old_price }}
                                </div>
                                <div class="pkr">
                                    <span>PKR:</span> <span class="new_price">{{ $prod->price }}</span>
                                </div>
                            </div>
                            <div class="prod_quantity">
                                {{-- <h3>
                                    Discount : <span class="text-capitalize "><strong>{{ $prod->heading }} %</strong></span>
                                </h3> --}}

                                {{-- <div class="quantity_inc">
                                   <div class="box">
                                       <div class="btn plus" data-item="{{ $prod->id }}">+</div>
                                       <input type="number" value="1" readonly="">
                                       <div class="btn minus" data-item="{{ $prod->id }}">-</div>
                                   </div>
                               </div> --}}
                                {{-- <div class="prod_flexis">
          <div class="icon minus">
            <i class="fa-solid fa-minus"></i>
          </div>
        
          <div class="input">
            <input type="hidden" class="form_counter" id="quantity_counter" value="1">
            <div class="text">1</div>
          </div>
          
          <div class="icon plus">
            <i class="fa-solid fa-plus"></i>
          </div>
        </div> --}}

                            </div>

                            <div class="btn_for_checkout">
                                <div class="flexis_checkout">




                                    {{-- <button class="btn btn_checkout payment" > Add To Cart</button> --}}
                                    <button id="btncart" onclick="addtocart(this)" class="btn btn_checkout payment"
                                        data-id='{{ $prod->id }}' data-img='{{ $prod->images }}'
                                        data-encid='{{ $prod->encryptedId }}' data-name='{{ $prod->name }}'
                                        data-price='{{ $prod->price }}'>add to cart</button>

                                    {{-- 
          <a class="btn mt-2 btn_checkout cash" href="/cashondelivery/{{$prod->encryptedId}}?quantity=1&price={{ $prod->price }}">Buy It Now</a> --}}
                                    <button class="btn btn_cart buyitnow" id="btncart" onclick="buynow(this)"
                                        class="btn btn_checkout payment" data-id='{{ $prod->id }}'
                                        data-img='{{ $prod->images }}' data-encid='{{ $prod->encryptedId }}'
                                        data-name='{{ $prod->name }}' data-price='{{ $prod->price }}'>Buy It
                                        Now</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="section_description_information">

                        <div class="info_tabs">
                            <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link " id="pills-home-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-home" type="button" role="tab"
                                        aria-controls="pills-home" aria-selected="true">Description</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-profile" type="button" role="tab"
                                        aria-controls="pills-profile" aria-selected="false">Additional
                                        information</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link active" id="pills-contact-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-contact" type="button" role="tab"
                                        aria-controls="pills-contact" aria-selected="false">Reviews (0)</button>
                                </li>

                            </ul>
                            <div class="tab-content" id="pills-tabContent">
                                <div class="tab-pane fade " id="pills-home" role="tabpanel"
                                    aria-labelledby="pills-home-tab" tabindex="0">
                                    {{ $prod->description }}
                                </div>
                                <div class="tab-pane fade" id="pills-profile" role="tabpanel"
                                    aria-labelledby="pills-profile-tab" tabindex="0">

                                    <div class="table-responsive">
                                        <table class="table text-capitalize">
                                            <thead>
                                                <tr>

                                                    <th scope="col">ingredients</th>

                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>

                                                    <td> {{ $prod->ingredients }}</td>

                                                </tr>

                                            </tbody>
                                        </table>
                                        <div class="mt-5">
                                            <div class="text-left">
                                                <h1>
                                                    How To Use
                                                </h1>
                                                <hr>
                                            </div>
                                            <p class="text-capitalize">
                                                {{ $prod->product_use }}
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade show active" id="pills-contact" role="tabpanel"
                                    aria-labelledby="pills-contact-tab" tabindex="0">


                                    <div class="row">
                                        <div class="col-md-8">
                                            <div class="reviews_about_products">

                                                <div class="heading">
                                                    <h1>
                                                        reviews about the product
                                                    </h1>
                                                </div>

                                                <div class="form_connect_us">
                                                    <form action="/storeproduct" method="POST">
                                                        @csrf
                                                        @method('POST')
                                                        <input type="hidden" name="product_id"
                                                            value="{{ $prod->id }}">
                                                        <div class="mb-3">
                                                            <label for="formGroupExampleInput" class="form-label">
                                                                review</label>
                                                            <div class="revies_stars">
                                                                <i class="fa-regular fa-star" data-val="1"> </i>
                                                                <i class="fa-regular fa-star" data-val="2"></i>
                                                                <i class="fa-regular fa-star" data-val="3"></i>
                                                                <i class="fa-regular fa-star" data-val="4"></i>
                                                                <i class="fa-regular fa-star" data-val="5"></i>
                                                            </div>
                                                        </div>

                                                        <div class="mb-3">

                                                            <input type="number" name="client_rating"
                                                                id="reviews_products" class="form-control" placeholder=""
                                                                value="1">
                                                            </input>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label for="formGroupExampleInput" class="form-label">enter
                                                                your review</label>

                                                            <textarea class="form-control" name="client_message" id="exampleFormControlTextarea1" rows="3"></textarea>
                                                            @error('client_message')
                                                                <span class="valid-feedback"> {{ $message }}</span>
                                                            @enderror
                                                        </div>
                                                        <div class="mb-3">
                                                            <label for="formGroupExampleInput" class="form-label">your
                                                                name</label>
                                                            <input name="client_name" type="text" class="form-control"
                                                                id="formGroupExampleInput" placeholder="Your Name">
                                                            @error('client_name')
                                                                <span class="valid-feedback"> {{ $message }}</span>
                                                            @enderror
                                                        </div>

                                                        <div class="mb-3">
                                                            <label for="formGroupExampleInput2" class="form-label">your
                                                                email</label>
                                                            <input name="client_email" type="email"
                                                                class="form-control" id="formGroupExampleInput2"
                                                                placeholder="Your Email">
                                                            @error('client_email')
                                                                <span class="valid-feedback"> {{ $message }}</span>
                                                            @enderror
                                                        </div>

                                                        <button type="submit" class="btn btn_main ">submit your
                                                            reviews</button>

                                                    </form>
                                                </div>

                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="reviews_about_client_for_product">
                                                <div class="reviews_prod mt-5 mb-2">
                                                    <h1>
                                                        Product Ratings
                                                    </h1>
                                                </div>
                                                <div class="row">
                                                    @foreach ($Productreviews as $item)
                                                        <div class="col-md-12 mb-2">
                                                            <div class="product_details">
                                                                <div class="img">
                                                                    <i class="fa-solid fa-user"></i>
                                                                </div>
                                                                <div class="basic_details">
                                                                    <div class="name">
                                                                        {{ $item->client_name }}
                                                                    </div>
                                                                    <div class="rating">
                                                                        @if ($item->client_rating > 0)
                                                                            @for ($i = 1; $i <= $item->client_rating; $i++)
                                                                                <i class="fa fa-star"></i>
                                                                            @endfor
                                                                            <span> ({{ $item->client_rating }}) <span
                                                                                    class="date">{{ date('D M Y', strtotime($item->created_at)) }}</span>
                                                                            </span>
                                                                        @else
                                                                            <i class="fa fa-star"></i>
                                                                            <span> (No ratings yet)</span>
                                                                        @endif
                                                                    </div>
                                                                    <div class="email">
                                                                        {{ $item->client_email }}
                                                                        <p>
                                                                            <span>
                                                                                <strong>
                                                                                    {{ $item->client_message }}
                                                                                </strong>
                                                                            </span>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    @endforeach

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>

                    {{-- row_end --}}
                </div>
            </div>
        </div>
    </main>
    {{-- <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> --}}
    {{-- <script>
     $(document).ready(function() {
       var quantity = parseInt($('#quantity_counter').val());
       var price_val = parseFloat($('.new_price').text());
   
       $('.icon.plus').click(function() {
         quantity += 1;
         let totalprice = price_val * quantity;
         $('.new_price').text(totalprice.toFixed(2));
         $('#quantity_counter').val(quantity);
         $('.input .text').text(quantity);
       });
   
       $('.icon.minus').click(function() {
         if (quantity > 1) {
           quantity -= 1;
           let totalprice = price_val * quantity;
           $('.new_price').text(totalprice.toFixed(2));
           $('#quantity_counter').val(quantity);
           $('.input .text').text(quantity);
         }
       });
   
       // Update the URL with quantity and price when the "Cash on Delivery" button is clicked
       $('.btn_checkout.cash').click(function(e) {
         e.preventDefault();
         let url = $(this).attr('href');
         let updatedUrl = url + '&quantity=' + quantity + '&price=' + price_val.toFixed(2);
         window.location.href = updatedUrl;
       });
     });
   </script> --}}
@endsection
