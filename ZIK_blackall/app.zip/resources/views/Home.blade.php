@extends('Layout.App')

@section('content')



@if (session()->has('success'))

     <div class="sweet_alerts_messages">

         <div class="mesg_box success">

             <div class="mesg">

                 {{ session('success') }}

             </div>

             <div class="close">

                 <i class="fa-solid fa-xmark toast-close"></i>

             </div>

             <div class="progress"></div>

         </div>

       

     </div>

    @endif

    

    @if (session()->has('error'))

     <div class="sweet_alerts_messages">

         <div class="mesg_box error">

             <div class="mesg">

                 {{ session('error') }}

             </div>

             <div class="close">

                 <i class="fa-solid fa-xmark toast-close"></i>

             </div>

             <div class="progress"></div>

         </div>

       

     </div>

    @endif

 <div class="main_slider_top">

            <div class="main_slides">

                @foreach ($MainSlide as $MainSlide)

                    <div>

                        <div class="slide_images">

                            <img src="https://adminlaravell.foodbaskit.com/public/slides/{{ $MainSlide->slide }}"

                                alt="Zakraish" class="img-fluid" />

                            <div class="container">

                                <div class="top_content">

                                    <div class="row">

                                        <div class="col-md-6">

                                            <div class="text_area">

                                                <h3>{{ $MainSlide->small_heading }}</h3>

                                                <h1 class="tp-slider-title-3">{{ $MainSlide->large_heading }}</h1>

                                                <div class="paragraph">

                                                    <p>{{ $MainSlide->paragraph }}</p>

                                                </div>

                                                {{--

										<div class="content_flexis">

											<div class="play_cards">

												<div class="detailing">

													<div class="icon">

														<img src="{{ asset('Asset/Images/beauty1.png') }}" class="img-fluid" alt="" />

													</div>

													<div class="name">

														<h3 class="tp-slider-feature-title-3">

															High-end <br />

															Cosmetics

														</h3>

													</div>

												</div>

												<div class="detailing">

													<div class="icon">

														<img src="{{ asset('Asset/Images/beauty2.png') }}" class="img-fluid" alt="" />

													</div>

													<div class="name">

														<h3 class="tp-slider-feature-title-3">

															Vegan <br />

															Product

														</h3>

													</div>

												</div>

												<div class="detailing">

													<div class="icon">

														<img src="{{ asset('Asset/Images/beauty3.svg') }}" class="img-fluid" alt="" />

													</div>

													<div class="name">

														<h3 class="tp-slider-feature-title-3">

															Express <br />

															make-up

														</h3>

													</div>

												</div>

											</div>

										</div>

										--}}

                                                <button class="btn_shop btn"> Shop Now </button>

                                            </div>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                @endforeach {{-- main_slides --}}

            </div>

        </div>

    <main>

       

        <div class="container" id="discover">

            <div class="row">

                <div class="dicoverd_products_section">

                    <div class="heading_main">

                        <h1>

                            Discover our products

                        </h1>

                    </div>

                    <div class="row">

                        <div class="discover_products">

                            @foreach ($Discover as $discover)

                                <div>

                                    <div class="row">

                                        <div class="col-md-12">

                                            <div class="card_wrap">

                                                <div class="card_body">

                                                    <div class="card_hovered">

                                                        <div class="card_img">

                                                            <img src="https://adminlaravell.foodbaskit.com/public/images/{{ $discover->images }}"

                                                                class="img-fluid" alt=" {{ $discover->name }}" />

                                                        </div>

                                                        <div class="tp-category-content-3 transition-3">

                                                            <h3 class="tp-category-title-3">

                                                                <a class="cursor-pointer">

                                                                    {{ $discover->name }}

                                                                </a>

                                                            </h3>

                                                            <span class="tp-categroy-ammount-3">

                                                                {{ $discover->product_type }}</span>

                                                            <div class="tp-category-btn-3">

                                                                <a class="cursor-pointer tp-link-btn tp-link-btn-2"

                                                                    href="/cart_details/{{ $discover->encryptedId }}">

                                                                    View Now

                                                                    <svg width="7" height="12" viewBox="0 0 7 12"

                                                                        fill="none" xmlns="http://www.w3.org/2000/svg">

                                                                        <path d="M1 1L6.02116 5.99958L1 11"

                                                                            stroke="currentColor" stroke-width="1.5"

                                                                            stroke-linecap="round" stroke-linejoin="round">

                                                                        </path>

                                                                    </svg>

                                                                </a>

                                                            </div>

                                                        </div>

                                                    </div>

                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                </div>

                            @endforeach

                        </div>

                    </div>

                </div>

                <section class="our_desired_products">

                    <div class="row">



                        <div class="swiper desired_swiper">

                            <div class="swiper-wrapper">





                                @foreach ($Favourite as $fav)

                                    <div class="swiper-slide">

                                        <a href="/cart_details/{{ $fav->encryptedId }}">

                                            <img

                                                src="https://adminlaravell.foodbaskit.com/public/images/{{ $fav->images }}" />

                                        </a>



                                    </div>

                                    <div class="swiper-slide">

                                        <a href="/cart_details/{{ $fav->encryptedId }}">

                                            <img

                                                src="https://adminlaravell.foodbaskit.com/public/images/{{ $fav->images }}" />

                                        </a>



                                    </div>



                                    {{-- <div class="col-md-4">

						<div class="card_wrap">

							<div class="card_body">

								<div class="card_details">

									<div class="card_img">

										<img src="https://adminlaravell.foodbaskit.com/public/images/{{ $fav->images }}" class="img-fluid" alt="Rated" />

									</div>

									<div class="navigate">

										<a href="/cart_details/{{ $fav->encryptedId }}">{{ $fav->name }}</a>

										<div class="desc">

											<p>

												{{ Str::Limit($fav->description, 50) }}..

											</p>

										</div>

									</div>

									<div class="price">

										{{ $fav->price }}

									</div>

								</div>

							</div>

						</div>

					</div> --}}

                                @endforeach

                            </div>



                        </div>





                    </div>

                </section>

                {{-- end_row --}}

            </div>

            {{-- end_container --}}

        </div>

        <section class="products_details">

            <div class="container">

                <div class="row">

                    <div class="heading_main">

                        <h4>Shop by Category</h4>

                        <h1>

                            Best sellers in beauty

                        </h1>

                    </div>



                    @foreach ($BestSellers as $prod)

                        <div class="col-md-3">

                            <div class="product_cart">

                                <div class="card_body">

                                    <div class="product_details">

                                        <div class="product_img">

                                            <img src="https://adminlaravell.foodbaskit.com/public/images/{{ $prod->images }}"

                                                class="img-fluid" alt="Product-Zakraish" />

                                            <div class="PRODUCT_social">

                                                <div class="menu">

                                                    <li>

                                                        <a href="cart_details/{{ $prod->encryptedId }}">

                                                            <div class="icon" data-bs-toggle="tooltip"

                                                                data-bs-placement="left"

                                                                data-bs-custom-class="custom-tooltip"

                                                                data-bs-title="Add To Cart">

                                                                <i class="fa-solid fa-cart-shopping"></i>

                                                            </div>

                                                        </a>

                                                            <div class="icon" data-bs-toggle="tooltip"

                                                                data-bs-placement="left"

                                                                data-bs-custom-class="custom-tooltip"

                                                                data-bs-title="Quick View">

                                                                <i class="fa-solid fa-eye"></i>

                                                            </div>

                                                            <div class="icon" data-bs-toggle="tooltip"

                                                                data-bs-placement="left"

                                                                data-bs-custom-class="custom-tooltip"

                                                                data-bs-title="Add To Wishlist">

                                                                <form action="/WishList" method="post">

                                                                    @csrf

                                                                    @method('post')

                                                                    <input type="hidden" value="{{ $prod->id}}" name="product_id">

                                                                    @if (Auth::check())

                                                                    <input type="hidden" value="{{Auth::user()->email}}" name="email">

                                                                    @endif

                                                         

                                                                  

                                                                    <button type="submit">  <i class="fa-regular fa-heart"></i></button>

                                                                </form>

                                                   

                                                            </div>

                                                        

                                                    </li>

                                                </div>

                                            </div>

                                            <div class="btn_cart">

                                                <a href="cart_details/{{ $prod->encryptedId }}" class="btn btn_cart">

                                                    add to cart

                                                </a>

                                            </div>

                                        </div>

                                    </div>

                                    <div class="product_bootom___details">

                                        <div class="name">

                                            <span class="title">{{ $prod->category }}</span>

                                            <div class="value">

                                                {{-- {{ $prod->name }} --}} {{ Str::Limit($prod->name, 45) }}..

                                            </div>

                                        </div>

                                        <div class="price">

                                            <div class="val">PKR :</div>

                                            <div class="key">{{ $prod->price }}</div>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                    @endforeach

                </div>

            </div>

        </section>

        <section class="trending_____products" id="trending">

            <div class="container">

                <div class="heading_main">

                    <h2>shopy now</h2>

                    <h1>

                        our trending products

                    </h1>

                </div>

                <div class="row">

                    {{-- <div class="col-md-5">

					<div class="trending_project_img">

						<img src="https://shofy-client.vercel.app/_next/image?url=%2F_next%2Fstatic%2Fmedia%2Fspecial-big-1.0e10703d.jpg&w=1080&q=75" class="img-fluid" alt="zakarish" />

					</div>

				</div>

				<div class="col-md-7">

					<div class="trendin_items_now">

						<div class="heading_main">

							<h6>

								best seller's of this year

							</h6>

							<h3>

								Trending products

							</h3>

						</div>

						<div class="trend_all_slider products_details">

							<div class="slider_trending__products">

								@foreach ($trendings as $trendings)

								<div>

									<div class="product_cart">

										<div class="card_body">

											<div class="product_details">

												<div class="product_img">

													<img src="https://adminlaravell.foodbaskit.com/public/images/{{ $trendings->images }}" class="img-fluid trending_imgs" alt="Product-Zakraish" />

													<div class="PRODUCT_social">

														<div class="menu">

															<li>

																<a href="cart_details/{{ $prod->encryptedId }}">

																	<div class="icon" data-bs-toggle="tooltip" data-bs-placement="left" data-bs-custom-class="custom-tooltip" data-bs-title="Add To Cart">

																		<i class="fa-solid fa-cart-shopping"></i>

																	</div>

																	<div class="icon" data-bs-toggle="tooltip" data-bs-placement="left" data-bs-custom-class="custom-tooltip" data-bs-title="Quick View">

																		<i class="fa-solid fa-eye"></i>

																	</div>

																	<div class="icon" data-bs-toggle="tooltip" data-bs-placement="left" data-bs-custom-class="custom-tooltip" data-bs-title="Add To Wishlist">

																		<i class="fa-regular fa-heart"></i>

																	</div>

																</a>

															</li>

														</div>

													</div>

													<div class="btn_cart">

														<a href="cart_details/{{ $prod->encryptedId }}" class="btn btn_cart">

															add to cart

														</a>

													</div>

												</div>

											</div>

											<div class="product_bootom___details">

												<div class="name">

													<span class="title"> {{ $trendings->product_type }}</span>

													<div class="value">

														{{ $trendings->name }}

													</div>

												</div>

												<div class="price">

													<div class="val">$</div>

													<div class="key">{{ $trendings->price }}</div>

												</div>

											</div>

										</div>

									</div>

								</div>

								@endforeach

							</div>

						</div>

					</div>

				</div> --}}



                    <div style="--swiper-navigation-color: #fff; --swiper-pagination-color: #fff"

                        class="swiper mySwiper2">

                        <div class="swiper-wrapper trending_main">

                            @foreach ($trendings as $trendings)

                                <div class="swiper-slide">

                                    <div class="trendings___section trendin_items_now">

                                        <div class="row">

                                            <div class="col-md-4">

                                                <div class="img">

                                                    <div class="flex_img">

                                                        <img src="https://adminlaravell.foodbaskit.com/public/images/{{ $trendings->images2 }}"

                                                            class="img-fluid trending_imgs" alt="Product-Zakraish" />

                                                    </div>

                                                </div>

                                            </div>

                                            <div class="col-md-8">

                                                <div class="trending_slides_details">

                                                    <div class="arrow_circle_img">

                                                        <img src="https://adminlaravell.foodbaskit.com/public/images/{{ $trendings->images2 }}"

                                                            class="w-50 rounded" alt="Product-Zakraish" />

                                                    </div>

                                                    <div class="detailing_trends">

                                                        <div class="review">

                                                            <i class="fa fa-star"></i>

                                                            <i class="fa fa-star"></i>

                                                            <i class="fa fa-star"></i>

                                                            <i class="fa fa-star"></i>

                                                        </div>

                                                        <div class="name">

                                                            <div class="key" class="text-capitalize"> {{ $trendings->name }}</div>

                                                        </div>

                                                        <div class="price">

                                                            <div class="old">{{ $trendings->old_price }}PKR</div>

                                                            <div class="new">PKR : {{ $trendings->price }}</div>

                                                        </div>

                                                        <div class="descp">

                                                            {{ $trendings->description }}

                                                        </div>

                                                        <div class="btn_view">

                                                            <a href="cart_details/{{ $prod->encryptedId }}"

                                                                class="btn btn_cart"> Add to Cart</a>

                                                        </div>

                                                    </div>

                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                </div>

                            @endforeach



                        </div>

                        <div class="swiper-button-next"></div>

                        <div class="swiper-button-prev"></div>

                    </div>

                    <div thumbsSlider="" class="swiper mySwiper trend_bottom">

                        <div class="swiper-wrapper">



                            @foreach ($trend as $trend)

                                <div class="swiper-slide">

                                 <div class="slides_bottom">

							<img src="https://adminlaravell.foodbaskit.com/public/images/{{ $trend->images2 }}"

							class="img-fluid trending_imgs slides" alt="Product-Zakraish" />

						   </div>



                                </div>

                            @endforeach



                        </div>

                    </div>



                </div>

            </div>

        </section>

        <section class="products_details" id="best_quality">

            <div class="container">

                <div class="row">

                    <div class="heading_main">

                        <h4>Shop by Category</h4>

                        <h1>

                            Enjoy the best quality

                        </h1>

                    </div>

                    <div class="col-md-12">

                        <div class="filter_data___by_category">

                            <div class="menu" id="filter_products">

                                <div class="row">

                                    @foreach ($cat as $cat)

                                    <li class="col-md-2 mt-3 mb-3">

                                        <a data-val="{{ $cat->category_name }}" class="category_products"

                                            data-bs-toggle="tooltip" data-bs-placement="top"

                                            data-bs-title="{{ $cat->category_name }}" aria-describedby="tooltip811994">

                                            {{ $cat->category_name }}

                                        </a>

                                    </li>

                                @endforeach

                                </div>

                         

                            </div>

                        </div>

                    </div>

                    <div class="all_products_cat row" id="category_container">

                        @foreach ($cat_prod as $cat_prod)

                            <div class="col-md-3">

                                <div class="product_cart">

                                    <div class="card_body">

                                        <div class="product_details">

                                            <div class="product_img">

                                                <img src="https://adminlaravell.foodbaskit.com//public/images/{{ $cat_prod->images }}"

                                                    class="img-fluid" alt="Product-Zakraish" />

                                                <div class="PRODUCT_social">

                                                    <div class="menu">

                                                        <li>

                                                            <a href="#">

                                                                <div class="icon" data-bs-toggle="tooltip"

                                                                    data-bs-placement="left"

                                                                    data-bs-custom-class="custom-tooltip"

                                                                    data-bs-title="Add To Cart">

                                                                    <i class="fa-solid fa-cart-shopping"></i>

                                                                </div>

                                                                <div class="icon" data-bs-toggle="tooltip"

                                                                    data-bs-placement="left"

                                                                    data-bs-custom-class="custom-tooltip"

                                                                    data-bs-title="Quick View">

                                                                    <i class="fa-solid fa-eye"></i>

                                                                </div>

                                                                <div class="icon" data-bs-toggle="tooltip"

                                                                    data-bs-placement="left"

                                                                    data-bs-custom-class="custom-tooltip"

                                                                    data-bs-title="Add To Wishlist">

                                                                    <form action="/WishList" method="post">

                                                                        @csrf

                                                                        @method('post')

                                                                        <input type="hidden" value="{{ $prod->id}}" name="product_id">

                                                                        @if (Auth::check())

                                                                        <input type="hidden" value="{{Auth::user()->email}}" name="email">

                                                                        @endif

                                                             

                                                                      

                                                                        <button type="submit">  <i class="fa-regular fa-heart"></i></button>

                                                                    </form>

                                                                </div>

                                                            </a>

                                                        </li>

                                                    </div>

                                                </div>

                                                <div class="btn_cart">

                                                    <a href="cart_details/{{ $cat_prod->encryptedId }}"

                                                        class="btn btn_cart">add to cart</a>

                                                </div>

                                            </div>

                                        </div>

                                        <div class="product_bootom___details">

                                            <div class="name">

                                                <span class="title">{{ $cat_prod->product_type }}</span>

                                                <div class="value">

                                                    {{ Str::Limit($cat_prod->name, 45) }}..

                                                </div>

                                            </div>

                                            <div class="price">

                                                <div class="val">PKR :</div>

                                                <div class="key">{{ $cat_prod->price }}.00</div>

                                            </div>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        @endforeach

                    </div>

                    <div class="pagination"></div>

                </div>

            </div>

        </section>

        <section class="how_our_policy_works">

            <div class="container">

                <div class="row">

                    <div class="col-md-3">

                        <div class="policy_details">

                            <div class="icons">

                                <i class="fa-solid fa-truck"></i>

                            </div>

                            <div class="parent_text">

                                <h3>Product Delivery</h3>

                                <h6>

                                    we deliver in 8-10 working day

                                </h6>

                            </div>

                        </div>

                    </div>

                    <div class="col-md-3">

                        <div class="policy_details">

                            <div class="icons">

                                <i class="fa-solid fa-dollar-sign"></i>

                            </div>

                            <div class="parent_text">

                                <h3>Return & Refund</h3>

                                <h6>

                                    Money back guarantee

                                </h6>

                            </div>

                        </div>

                    </div>

                    <div class="col-md-3">

                        <div class="policy_details">

                            <div class="icons">

                                <i class="fa-solid fa-person"></i>

                            </div>

                            <div class="parent_text">

                                <h3>Member Discount</h3>

                                <h6 class="text-capitalize">

                                    Get 10 % off on sharing before/after review images

                                </h6>

                            </div>

                        </div>

                    </div>

                    <div class="col-md-3">

                        <div class="policy_details">

                            <div class="icons">

                                <i class="fa-solid fa-headphones"></i>

                            </div>

                            <div class="parent_text">

                                <h3>Support 24/7</h3>

                                <h6>

                                    Contact us 24 hours a day

                                </h6>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </section>



        {{-- <section class="client_reviews">

            <div class="slider_for_testonomials">

                <div class="container">

                    <div class="heading_main">

                        <h3>Customers Review</h3>

                        <h1>

                            What our Clients say

                        </h1>

                    </div>

                </div>

                <div class="row">

                    <div class="client_slider">

                        @foreach ($Clientreview as $item)

                        <div>

                            <div class="card_client_reviews">

                                <div class="card_img">

                                    <img src="public/client_reviews/{{$item->client_image}}"

                                        class="img-fluid" alt="" />

                                </div>

                                <div class="card_navigate_icon">

                                    <div class="icons">

                                       <a href="/cart_details/{{$item->encryptedId}}">

                                        <i class="fa-solid fa-eye text-light"></i>

                                    </a>

                                    </div>

                                </div>

                            </div>

                        </div>

                        @endforeach

                       

                

                    </div>

                </div>

            </div>

        </section> --}}



    </main>



    <script src="https://code.jquery.com/jquery-3.7.0.min.js"

        integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>

    <script>

        $(document).ready(function() {



            $.ajax({

                type: 'GET',

                url: '/paginate',

                data: {},

                dataType: 'json',

                success: function(data) {

                    // console.log(data);



                }

            });

        });

    </script>



    <script>

        $(document).ready(function() {

            var dropdownItems = document.querySelectorAll('.category_products');

            let itemsPerPage = 12;

            let currentPage = 1;

            let totalPage = 0;



            $('.category_products').click(function() {

                $('.category_products').removeClass('active'); // Remove 'active' class from all items

                $(this).addClass('active'); // Add 'active' class to the clicked item



                let category = $(this).attr('data-val');

                fetchdata(category); // Pass the category parameter to fetchdata function

          

            });



            function fetchdata(category) {

                $.ajax({

                    type: 'GET',

                    url: '/CategoryProducts', // Update the URL to match the correct route

                    data: {

                        keyword: category

                    }, // Pass the keyword as data in the request

                    dataType: 'json',

                    success: function(data) {

                        let ProdCat = [...data];



                        totalPage = Math.ceil(ProdCat.length / itemsPerPage);

                        let startIndex = (currentPage - 1) * itemsPerPage;

                        let endIndex = startIndex + itemsPerPage;

                        let paginatedData = ProdCat.slice(startIndex, endIndex);

                        console.log(paginatedData);

                        $('#category_container').empty();

                        let prodContainer = $('#category_container');

                        prodContainer.empty();



                        paginatedData.forEach((item) => {

                            let card_html = `

                    	  <div class="col-md-3 ">

	    <div class="product_cart">

	      <div class="card_body">

	        <div class="product_details">

	          <div class="product_img">

	            <img src="https://adminlaravell.foodbaskit.com//public/images/${item.images}" class="img-fluid" alt="Product-Zakraish">

	            <div class="PRODUCT_social">

	              <div class="menu">

	                <li>

	                  <a href="#">

	                    <div class="icon" data-bs-toggle="tooltip" data-bs-placement="left" data-bs-custom-class="custom-tooltip" data-bs-title="Add To Cart">

	                      <i class="fa-solid fa-cart-shopping"></i>

	                    </div>

	                    <div class="icon" data-bs-toggle="tooltip" data-bs-placement="left" data-bs-custom-class="custom-tooltip" data-bs-title="Quick View">

	                      <i class="fa-solid fa-eye"></i>

	                    </div>

	                    <div class="icon" data-bs-toggle="tooltip" data-bs-placement="left" data-bs-custom-class="custom-tooltip" data-bs-title="Add To Wishlist">

	                      <i class="fa-regular fa-heart"></i>

	                    </div>

	                  </a>

	                </li>

	              </div>

	            </div>

	            <div class="btn_cart">

	              <a href="cart_details/${item.encryptedId}" class="btn btn_cart">add to cart</a>

	            </div>

	          </div>

	        </div>

	        <div class="product_bootom___details">

	          <div class="name">

	            <span class="title">${item.product_type}</span>

	            <div class="value">

	            ${item.name}

	            </div>

	          </div>

	          <div class="price">

	            <div class="val">$</div>

	            <div class="key">    ${item.price},00</div>

	          </div>

	        </div>

	      </div>

	    </div>

	  </div>

                    `;

                            prodContainer.append(card_html);

                        });



                        renderPaginationButtons();



                        // Perform further operations with the data

                    },

                    error: function(xhr) {

                        console.log(xhr.responseText);

                    }

                });

            }



            function renderPaginationButtons() {

                let paginationContainer = $('.pagination');

                paginationContainer.empty();



                for (let i = 1; i <= totalPage; i++) {

                    let button_html = `

                <button class="page-button ${i === currentPage ? 'active' : ''}" data-page="${i}">${i}</button>

            `;

                    paginationContainer.append(button_html);

                }



                // Attach click event handler to pagination buttons

                $('.page-button').click(function() {

                    currentPage = parseInt($(this).attr('data-page'));

                    let category = $('.category_products.active').attr('data-val');

                    fetchdata(category); // Pass the category parameter to fetchdata function

                });

            }

        });

    </script>

@endsection

