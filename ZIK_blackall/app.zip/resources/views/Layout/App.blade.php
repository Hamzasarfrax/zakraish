<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate, max-age=0">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <link rel="shortcut icon" href="{{ asset('public/Asset/Images/zik.png') }}" type="image/x-icon">
    @include('Partials.TopNav')
    <title>Zakriaish</title>
</head>

<body>
    @include('Partials.Header')
    @include('Partials.Aside')
    @include('Partials.Loader')
    @yield('content')
    @include('Partials.Overlay')
    @include('Partials.Checkout')
    @include('Partials.Footer')
    <div class="offcanvas offcanvas-top" tabindex="-1" id="offcanvasTop" aria-labelledby="offcanvasTopLabel">
        <div class="offcanvas-header">
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <div class="searching_products">
                <form>
                    <div class="mb-3">
                        <input type="text" class="form-control w-100" placeholder="Search Here"
                            id="searchliveproducts">
                    </div>
                </form>
                <div class="shoop_all_____category_data">
                    <div class="top___rated___prod">
                        <div class="heading_main">
                            <h3>
                                there is
                            </h3>
                            <h1>
                                Top Rated Products
                            </h1>
                        </div>
                        <div class="row" id="searchproducts">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
@include('Partials.Script')
<script>
    fetch("https://testing.foodbaskit.com/products")
        .then((res) => {
            return res.json();
        })
        .then((result) => {
            // console.log(result);

            // Store the data in local storage
            var userDataString = JSON.stringify(result);
            localStorage.setItem("data", userDataString);

            // Retrieve and log the data from local storage
            var retrievedDataString = localStorage.getItem("data");
            if (retrievedDataString) {
                var retrievedData = JSON.parse(retrievedDataString);
                // console.log("Data retrieved from local storage:", retrievedData);
                $("#category_container").empty();

                let prodContainer = $("#category_container");

                prodContainer.empty();
                retrievedData.forEach((item) => {
                    let card_html = `
      
      <div class="col-md-3 col-xl-3 col-lg-3 col-6">
      
         <div class="product_cart">
             <div class="card_body">
                 <div class="product_details">
                     <div class="product_img">
                         <img src="https://adminlaravell.foodbaskit.com/public/images/${item.images}" class="img-fluid" alt="Product-Zakraish">
                         <div class="PRODUCT_social">
                             <div class="menu">
                                 <ul>
                                     <li>
                                         <a href="#">
                                             <a href="/cart_details/${item.encryptedId}" class="icon cart_shop" data-bs-toggle="tooltip" data-bs-placement="left" data-bs-custom-class="custom-tooltip" data-bs-title="Add To Cart">
                                                 <i class="fa-solid fa-eye"></i>
                                             </a>
                                             <div class="icon whitlist" data-bs-toggle="tooltip" data-bs-placement="left" data-bs-custom-class="custom-tooltip" data-bs-title="Add To Wishlist">
                                                 <form action="/WishList" method="post">
                                                     @csrf
                                                     @method('post')
                                                     <input type="hidden" value="${item.id}" name="product_id">
                                                     @if (Auth::check())
                                                         <input type="hidden" value="{{ Auth::user()->email }}" name="email">
                                                     @endif
                                                     <button type="submit"><i class="fa-regular fa-heart"></i></button>
                                                 </form>
                                             </div>
                                         </a>
                                     </li>
                                 </ul>
                             </div>
                         </div>
                     </div>
                     <div class="btn_cart">
                         <button id="btncart" onclick="addtocart(this)" class="btn btn_cart add-to-cart-btn text-capitalize" data-id='${item.id}' data-img='${item.images}' data-encid='${item.encryptedId}' data-name='${item.name}' data-price='${item.price}'>add to cart</button>
                     </div>
                 </div>
                 <a href="/cart_details/${item.encryptedId}">
                 <div class="product_bootom___details">
                     <div class="name">
                         <span class="title">${item.product_type}</span>
                         <div class="value">
                             ${item.name}
                         </div>
                     </div>
                     <div class="price">
                         <div class="val">Pkr</div>
                         <div class="key">${item.price}</div>
                     </div>
                 </div>
               </a>
             </div>
         </div>
      
      </div>
      
      
      `;

                    prodContainer.append(card_html);
                });
            }
        });

    let cart = [];

    let itemlenght = JSON.parse(localStorage.getItem("cart")) || [];
    let lenghtcart = itemlenght.length;
    $("body #counter").text(lenghtcart);
    $("body #lenght").text(lenghtcart);

    displayCartItems();

    function addtocart(button) {



        let id = button.getAttribute("data-id");
        let name = button.getAttribute("data-name");
        let price = button.getAttribute("data-price");
        let encid = button.getAttribute("data-encid");
        let img = button.getAttribute("data-img");

        let cartItem = {
            id,
            name,
            price,
            encid,
            img,
            quantity: 1,
        };



        //  setTimeout(() => {
        //     $("#messages .sweet_alerts_messages").addClass('active');
        //  }, 4000);
        let existingCart = JSON.parse(localStorage.getItem("cart")) || [];

        if (existingCart) {
            let addButton = button; // Replace 'yourButtonId' with the actual ID of your button
            addButton.disabled = true;
            addButton.innerHTML = `<div class="spinner-border" role="status">
                             <span class="visually-hidden">Loading...</span>
                           </div>`;

            setTimeout(() => {
                // Enable the button and update the text after 4000 milliseconds (4 seconds)
                addButton.disabled = false;
                addButton.setAttribute("disabled", "true");
                addButton.textContent = 'Item added';
            }, 600);
        } else {
            let addButton = button; // Replace 'yourButtonId' with the actual ID of your button

            setTimeout(() => {
                // Enable the button and update the text after 4000 milliseconds (4 seconds)
                addButton.disabled = false;
                addButton.setAttribute("disabled", "false");
                addButton.textContent = 'Add To Cart';
            }, 400);
        }
        $(".succes__cart ").toggleClass("active");

        $("#buyitnow").attr("disabled", "false");
        let existingItemIndex = existingCart.findIndex((item) => item.id == id);

        if (existingItemIndex !== -1) {
            alert("Already Exist Item");
            existingCart[existingItemIndex].quantity += 1;
        } else {
            existingCart.push(cartItem);
        }

        localStorage.setItem("cart", JSON.stringify(existingCart));

        displayCartItems(existingCart);

        let totalItems = existingCart.length;
        $("html body #counter").text(totalItems);
        $("html body #lenght").text(totalItems);

        console.log(existingCart);
    };







    function displayCartItems() {
        let cartItems = $(".cart_items");
        cartItems.empty();

        let productcart = JSON.parse(localStorage.getItem("cart"));
        let totalPrice = 0;
        if (productcart) {
            productcart.forEach((item) => {
                let cartItemHTML = `
          <li>
              <a href=''>
                  <div class="cart_details" data-id='${item.id}'>
                      <div class="cart_img">
                          <img src="https://adminlaravell.foodbaskit.com//public/images/${item.img}" class="img-fluid" alt="">
                      </div>
                      <div class="cart_title">
                          <a href="cart_details/${item.encid}" class="name">
                              ${item.name}
                          </a>
                          <div class="price">
                              Pkr <span class="amount">${item.price}</span>
                          </div>
                          <div class="quantity_inc">
                          <div class="box">
                              <div class="btn plus"  data-item="${item.id}">+</div>
                              <input type="number" value="${item.quantity}" readonly>
                              <div class="btn minus" data-item="${item.id}">-</div>
                          </div>
                      </div>
                      </div>
                      <div class="cart_remove" onclick="removecart(${item.id})" data-id='${item.id}'>
                          <i class="fa-solid fa-trash"></i>
                      </div>
                   
                  </div>
              </a>
          </li>
      `;
                totalPrice += parseFloat(item.price * item.quantity);

                $("#insert_product").val(JSON.stringify(productcart));
                cartItems.append(cartItemHTML);
                incrementQuantity(item.quantity);
                decrementQuantity(item.quantity);
            });



            totalprice(totalPrice.toFixed(2));
            sub_total(totalPrice.toFixed(2));

        }
        let countitems = productcart.length;
        if (countitems > 0) {
            showitems(countitems);
        }



        function totalprice(price) {
            $(".total_price").text(price);

        }

        function sub_total(price) {
            let totalPriceWithCharge = (parseFloat(price) + 200).toFixed(2);
            $(".sub_total").text(totalPriceWithCharge);
            $('#total_price').val(totalPriceWithCharge);
        }

    }

    // Increment quantity for a specific product
    // Increment quantity for a specific product
    function incrementQuantity(itemId) {
        try {
            let existingCart = JSON.parse(localStorage.getItem("cart"));

            // Find the item in the cart by ID
            const itemToUpdate = existingCart.find((item) => item.id == itemId);

            if (itemToUpdate) {
                // Increment the quantity by 1
                itemToUpdate.quantity += 1;

                // Update the cart in local storage with the modified existingCart
                localStorage.setItem("cart", JSON.stringify(existingCart));

                // Call a function to display updated cart items
                displayCartItems();

                // Update the counter and length display based on the modified cart
                let lengthCart = existingCart.length;
                $(".bottom_box #counter").text(lengthCart);
                $("#lenght").text(lengthCart);
                $('#cart_check #counter').text(lengthCart);
                showitems(lengthCart);

                console.log("Updated cart:", existingCart);
            }
        } catch (error) {
            console.error("Error parsing or accessing local storage:", error);
        }
    }

    // Decrement quantity for a specific product
    function decrementQuantity(itemId) {
        try {
            let existingCart = JSON.parse(localStorage.getItem("cart"));

            // Find the item in the cart by ID
            const itemToUpdate = existingCart.find((item) => item.id == itemId);

            if (itemToUpdate && itemToUpdate.quantity > 1) {
                // Decrement the quantity by 1 if it's greater than 1
                itemToUpdate.quantity -= 1;

                // Update the cart in local storage with the modified existingCart
                localStorage.setItem("cart", JSON.stringify(existingCart));

                // Call a function to display updated cart items
                displayCartItems();

                // Update the counter and length display based on the modified cart
                let lengthCart = existingCart.length;
                $(".bottom_box #counter").text(lengthCart);
                $("#lenght").text(lengthCart);
                $('#cart_check #counter').text(lengthCart);
                showitems(lengthCart);

                console.log("Updated cart:", existingCart);
            }
        } catch (error) {
            console.error("Error parsing or accessing local storage:", error);
        }
    }

    // Increment quantity for a specific product
    $(document).on("click", ".btn.plus", function(event) {
        event.stopPropagation(); // Prevent event propagation
        let itemId = $(this).data("item");
        incrementQuantity(itemId);
    });

    // Decrement quantity for a specific product using jQuery
    $(document).on("click", ".btn.minus", function(event) {
        event.stopPropagation(); // Prevent event propagation
        let itemId = $(this).data("item");
        decrementQuantity(itemId);
    });


    function showitems(item) {
        $('#cart_check #counter').text(item);
        $('.counter').text(item);

    }

    window.removecart = function(dataid) {
        try {

            $('#btncart[data-id="' + dataid + '"]').prop('disabled', false);
            $('#btncart[data-id="' + dataid + '"]').text('Add To Cart');
            let existingCart = JSON.parse(localStorage.getItem("cart"));


            // Find the index of the item to remove based on the matching dataid
            const indexToRemove = existingCart.findIndex((item) => item.id == dataid);

            if (indexToRemove !== -1) {
                // Remove the item from the existingCart array
                existingCart.splice(indexToRemove, 1);

                // Update the cart in local storage with the modified existingCart
                localStorage.setItem("cart", JSON.stringify(existingCart));

                // Call a function to display updated cart items
                displayCartItems();
                $("#insert_product").val(JSON.stringify(existingCart));
                // Refresh the displayed products
                // displayproduct(existingCart);

                $(".error__cart.error").toggleClass("active");

                // Update the counter and length display based on the modified cart
                let lengthCart = existingCart.length;
                $(".bottom_box #counter").text(lengthCart);
                $("#lenght").text(lengthCart);
                $('#cart_check #counter').text(lengthCart);
                showitems(lengthCart);

                console.log("Updated cart:", existingCart);
            } else {
                console.log("Item with ID not found in cart:", dataid);
            }
        } catch (error) {
            console.error("Error parsing or accessing local storage:", error);
        }
    };

    function buynow(button) {
        addtocart(button);
        setTimeout(() => {
            window.location.href = '/checkout';
        }, 5000)
    }


    function closealert() {
        $(".succes__cart").removeClass("active");
        $(".error__cart").removeClass("active");
    }

    setTimeout(() => {
        $(".succes__cart").removeClass("active");
    }, 5000);
</script>
<script>
    $("#searchliveproducts").keyup(function() {
        var query = $(this).val();
        // alert(query);

        $.ajax({
            url: '/search',
            method: 'GET',
            data: {
                query: query
            },
            dataType: 'json',
            success: function(response) {
                let searchproducts = $("#searchproducts").empty();
                response.forEach((item) => {
                    // Generate star icons based on item.ratings
                    let starRating = '';
                    for (let i = 1; i <= 5; i++) {
                        if (i <= item.ratings) {
                            starRating += '<i class="fa fa-star"></i>';
                        } else {
                            starRating += '<i class="fa fa-star-o"></i>';
                        }
                    }

                    let prod = `
                          <div class="col-sm-12 col-md-4 col-xl-3">
                              <a href="/cart_details/${item.encryptedId}">
                                  <div class="card_top___rated___prod">
                                      <div class="card_img">
                                          <img src="https://adminlaravell.foodbaskit.com//public/images/${item.images}" class="img-fluid" alt="Zakriaish Complete Skincare Kit">
                                      </div>
                                      <div class="card_details">
                                          <div class="reviews">
                                              ${starRating}
                                              <span> (Review's(${item.ratings}))</span>
                                          </div>
                                          <div class="name">
                                              ${item.name}
                                          </div>
                                          <div class="price">
                                              ${item.price}
                                          </div>
                                      </div>
                                  </div>
                              </a>
                          </div>`;
                    searchproducts.append(prod);
                });

                console.log(response); // For debugging purposes
            }
        });
    });
</script>
<script>
    const progressCircle = document.querySelector(".autoplay-progress svg");
    const progressContent = document.querySelector(".autoplay-progress span");
    var swiper = new Swiper(".hero-slide-item", {
        spaceBetween: 30,
        centeredSlides: true,
        autoplay: {
            delay: 4500,
            disableOnInteraction: false
        },
        pagination: {
            el: ".swiper-pagination",
            clickable: true
        },
        navigation: {
            nextEl: "",
            prevEl: ""
        },
        on: {
            autoplayTimeLeft(s, time, progress) {
                // progressCircle.style.setProperty("--progress", 1 - progress);
                // progressContent.textContent = `${Math.ceil(time / 1000)}s`;
            }
        }
    });
</script>
<script>
    $('.tes').slick({
        dots: true,
        infinite: false,
        speed: 300,
        slidesToShow: 1,
        slidesToScroll: 1,
        responsive: [{
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,
                    infinite: true,
                    dots: true
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
            // You can unslick at a given breakpoint now by adding:
            // settings: "unslick"
            // instead of a settings object
        ]
    });
</script>
<script>
    AOS.init();
</script>


<script>
    const locPath = window.location.pathname;
    const cartData = localStorage.getItem('cart');
    let cartitem = JSON.parse(cartData);

    // Define the cart HTML
    const cartHTML = `
    <div class="succes__cart success active">
        <div class="box_alert">
            <div class="child">
                <div class="check">
                    <i class="fa-solid fa-check"></i>
                </div>
            </div>
            <div class="child">
                <span class="text"> Cart is Empty</span>
            </div>
            <div class="child">
                <div class="close" id="close" onclick="closealert()">
                    <i class="fa-solid fa-xmark toast-close"></i>
                </div>
            </div>
        </div>
        <div class="progress"></div>
    </div>
`;

    if (locPath.includes('/checkout')) {
        if (cartitem && cartitem.length > 0) {
            console.log(cartitem);
            $('#gfg').append("");
        } else {
            // Append the cart HTML to the element with ID 'gfg'
            $('#gfg').append(cartHTML);
            window.location.href = '/';
            // You can also use other methods to append it in a specific location
        }
    }
</script>
<script>
    $('.client_imgs_reviews').slick({
        dots: false,
        slidesToShow: 1,
        infinite: true,
        speed: 500,
        fade: true,
        cssEase: 'linear',
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        arrows: false,
    });

    $('.reviews_slider').slick({
        dots: false,
        slidesToShow: 5,
        infinite: true,
        speed: 2000, // Set the speed to 2000 for a linear autoplay effect
        cssEase: 'linear',
        slidesToScroll: 3,
        autoplay: true,
        autoplaySpeed: 1000,
        arrows: true,
        prevArrow: "<button type='button' class='btn pull-left'><i class='fa-solid fa-arrow-left'></i></button>",
        nextArrow: "<button type='button' class='btn pull-right'><i class='fa-solid fa-arrow-right'></i></button>",
        responsive: [{
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,

                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
            // You can unslick at a given breakpoint now by adding:
            // settings: "unslick"
            // instead of a settings object
        ]
    });
</script>

<script>
    $(document).ready(function() {
        $('.box_bar_reviews .details .para .more').click(function() {
            let mesage = $(this).data('mesage');
            let name = $(this).data('name');
            let mail=$(this).data('email');
            let desc=$(this).data('desc');
            $('#clienttextshow').toggleClass('active');

            $('#clienttextshow .textclient').text(mesage);
            $('#clienttextshow .email').text(mail);
            $('#clienttextshow .name').text(name);
            $('#clienttextshow .desc').text(desc);
         

        });

        $('#clienttextshow .top_close').click(function() {
         
            $('#clienttextshow').removeClass("active");

        });
    });
</script>

</html>
