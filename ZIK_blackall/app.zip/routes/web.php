<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ProductReviewsController;
use App\Http\Controllers\ContactUsController;
use App\Http\Controllers\WebController;
use App\Http\Controllers\ClientReviewController;
use App\Http\Controllers\CashOnDeliveryController;
use App\Http\Controllers\TrackOrderController;
use Illuminate\Support\Facades\Route as BaseRoute;
use App\Http\Controllers\ReturRefundController;


// Route::get('/', function () {
//     return view('welcome');
// });
Route::get('/clear', function () {
    Artisan::call('cache:clear');
    Artisan::call('route:clear');
    Artisan::call('config:clear');
    Artisan::call('view:clear');
    Cache::flush();

    return "Cache cleared successfully";
});

BaseRoute::fallback(function () {
    // You can log the error or handle it in any other way you prefer
    // For simplicity, we'll just return the error view
    return view('error', [
        'exception' => new \Exception('Page not found.')
    ]);
});
Route::get('/testingmail', [CashOnDeliveryController::class, 'testingmail']);
//  ProductController
// to store ip address
Route::post('/store-ip', [ProductController::class, 'visit']);

// Route::get('/blogs', [WebController::class, 'blogs'])->name('blogs');
Route::get('/returnparoduct', [WebController::class, 'ReturnPage'])->name('returnparoduct');
Route::get('/aboutus', [WebController::class, 'AboutUs'])->name('aboutus');
Route::get('/terms_condition', [WebController::class, 'TermsCondition']);
Route::get('/contactus', [WebController::class, 'ContactUs']);
// Route::get('/shop', [WebController::class, 'ShopProduct']);
Route::get('/cart_details', [WebController::class, 'Cart_details']);
Route::get('/trackorder', [WebController::class, 'TrackOrder']);


// route for ClientReviewController

Route::post('/storeclientreviews', [ClientReviewController::class, 'storeclientreviews'])->name('storeclientreviews');
Route::get('/blogs', [ClientReviewController::class, 'showblogs']);
Route::get('/blog_details/{id}', [ClientReviewController::class, 'blog_details'])->name('blog_details');

// this is order on cash 

Route::get('/success', [CashOnDeliveryController::class, 'success'])->name('success');
Route::get('/cashondelivery/{id}', [CashOnDeliveryController::class, 'showcashorder'])->name('cashondelivery');
Route::post('/orderondelivery', [CashOnDeliveryController::class, 'CashOrder'])->name('orderondelivery');
Route::post('/checkoutallproducts', [CashOnDeliveryController::class, 'multipleorders'])->name('multipleorders');

// // footer routing 
// Route::get('footer', [FooterController::class, 'showfooter'])->name('footer');

Route::get('/', [ProductController::class, 'GetData']);
Route::get('/search', [ProductController::class, 'search']);
Route::get('/checkout', [CashOnDeliveryController::class, 'ShippingOrder']);


// Route::match(['get', 'post'], '/', [ProductController::class, 'GetData']);

Route::get('/products', [ProductController::class, 'Getproduct']);
Route::get('/cart', [ProductController::class, 'ViewCart']);

Route::get('/paginate', [ProductController::class, 'Products'])->name('paginate');
Route::get('/cart_details/{id}', [ProductController::class, 'Cart_details'])->name('cart_details');
// submit the reviews products
Route::post('/storeproduct', [ProductReviewsController::class, 'storeproduct'])->name('storeproduct');
// submit the storecontactus 


Route::post('/storecontactus', [ContactUsController::class, 'storecontactus'])->name('storecontactus');
// get data by categoryProducts


//   this is for track ordr
Route::post('/TrackOrder', [TrackOrderController::class, 'Trackorders'])->name('TrackOrder');
Route::get('/trackorder', [TrackOrderController::class, 'Trackordersprod'])->name('trackorder');
Route::get('/productfilter', [TrackOrderController::class, 'productfilter'])->name('productfilter');
//   this is for track ordr

// this is return and refund ReturRefundController
Route::post('/Returnrefund', [ReturRefundController::class, 'Returnrefund'])->name('Returnrefund');
// this is return and refund ReturRefundController

// get data by categoryProducts
Route::get('/CategoryProducts', [ProductController::class, 'CategoryProducts'])->name('CategoryProducts');
// get data by categoryProducts


// get data by whislist
Route::post('/WishList', [ProductController::class, 'WishList'])->name('WishList');
Route::get('/wishlists', [ProductController::class, 'wishlists'])->name('wishlists');
// get data by whislist

Route::get('/writeblog', [ProductController::class, 'writeblog'])->name('writeblog');
// get data by shop
Route::get('/shop/{name}', [ProductController::class, 'ShopCategory'])->name('shop');

// get data by footers
Route::get('/logo', [ProductController::class, 'brandlogos'])->name('logo');
// footerlinks
Route::get('/footerlinks', [ProductController::class, 'footerlinks'])->name('footerlinks');
// footerdata
Route::get('/footerdata', [ProductController::class, 'footerdata'])->name('footerdata');
Auth::routes();

// Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
