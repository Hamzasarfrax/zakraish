<?php
namespace App\Http\Controllers;
use App\Models\CashOnDelivery;
use App\Models\ReturRefund;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use App\Mail\Returns;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
class ReturRefundController extends Controller
{
public function Returnrefund(Request $request){
// dd($request->all());
if(Auth::check()){
$orderId = $request->input('order_id');
$contactNo = $request->input('contact_no');
$email = Auth::user()->email;
$matchingRecord = CashOnDelivery::where('order_id', $orderId)
->where('user_contact', $contactNo)
->first();
$data = [
'name' => $request->name,
];
//   dd($matchingRecord);         
if ($matchingRecord) {
$returnfund = new ReturRefund;
$returnfund->order_id = $request->order_id;
$returnfund->contact_no = $request->contact_no;
$returnfund->save();
Mail::to($email)->send(new Returns($data));
Mail::to('saraanahmed935@gmail.com')->send(new Returns($data));
Session::flash('success','Your request has been delivered to us our team will contact you soon ');
return redirect()->back()->with('success','Your request has been delivered to us our team will contact you soon ');
} else {
// No matching record found, you can handle this case accordingly
return redirect()->back()->with('error', 'No products found for this category.');
}
}
else {
return redirect('/login');
}
}
}