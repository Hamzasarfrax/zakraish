<?php
namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ProductCategory;
use App\Models\MainSlide;
use App\Models\Productreviews;
use App\Models\ClientReview;
use App\Models\Wishlist;
use App\Models\Visit;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;
use App\Models\Apidata;

class ProductController extends Controller
{
public function ContactUs()
{
return view('ContactUs');
}
public function blogs()
{
return view('Blog');
}
public function ViewCart()
{
return view('Checkout');
}
// public function ShopProduct()
// {
//     return view('Shop');
// }
public function TermsCondition()
{
return view('Terms&Condition');
}

public function AboutUs()
{
return view('About');
}
public function ReturnPage()
{
return view('Return');
}


public function GetData(Request $request)
{
    $perPage = 12;
    $clientimgs= ClientReview::where('blog_type', 'reviews')
    ->get();
    $MainSlide = MainSlide::all();
    $cat_prod = Apidata::paginate(6);
    $bestSellers = Apidata::where('type', 'sales')->paginate(2);

    foreach ($bestSellers as $product) {
        $product->encryptedId = encrypt($product->id);
    }

    // Calculate the percentage difference for each product in cat_prod
    foreach ($cat_prod as $product) {
        $product->encryptedId = encrypt($product->id);
    
        // Check if both old_price and price are set
        if ($product->old_price && $product->price) {
            $percentageDifference = (($product->old_price - $product->price) / $product->old_price) * 100;
    
            // Round the percentageDifference to two decimal places
            $roundedPercentageDifference = number_format($percentageDifference, 0);
    
            $product->percentageDifference = $roundedPercentageDifference;
        } else {
            // If either old_price or price is not set, set the percentageDifference to null or any default value you prefer.
            $product->percentageDifference = null;
        }
    }

    foreach ($bestSellers as $product) {
        $product->encryptedId = encrypt($product->id);
    
        // Check if both old_price and price are set
        if ($product->old_price && $product->price) {
            $percentageDifference = (($product->old_price - $product->price) / $product->old_price) * 100;
    
            // Round the percentageDifference to two decimal places
            $roundedPercentageDifference = number_format($percentageDifference, 0);
    
            $product->percentageDifference = $roundedPercentageDifference;
        } else {
            // If either old_price or price is not set, set the percentageDifference to null or any default value you prefer.
            $product->percentageDifference = null;
        }
    }
    

    $cat = ProductCategory::all();
// dd($cat_prod);
    return view("welcome", compact("cat_prod", "cat", "MainSlide", "bestSellers",'clientimgs'));
}



public function search(Request $request)
{

    $query = $request->input('query');
    $cat_prod = Apidata::where('name', 'like', '%' . $query . '%')->get();
    foreach ($cat_prod as $product) {
        $product->encryptedId = encrypt($product->id);
    }
    return  $cat_prod;

}

public function Getproduct(Request $request)
{

    $query = $request->input('query'); // Get the user's search query
   
    if($query){
        $results = Apidata::where('name', 'like', '%' . $query . '%')->get();
        foreach ($results as $product) {
            $product->encryptedId = encrypt($product->id);
        }
        $response = response()->json($results);
        $response->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $response->header('Pragma', 'no-cache');
        $response->header('Expires', 'Sat, 01 Jan 2000 00:00:00 GMT');
    
        return $response;
     
    }
    else{
        $BestSellers = Apidata::all();
        foreach ($BestSellers as $product) {
            $product->encryptedId = encrypt($product->id);
        }
        $response = response()->json($BestSellers);
        $response->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $response->header('Pragma', 'no-cache');
        $response->header('Expires', 'Sat, 01 Jan 2000 00:00:00 GMT');
    
        return $response;

    }


}


public function Products()
{
$cat_prod = Apidata::paginate(12);
foreach ($prod as $product) {
$product->encryptedId = encrypt($product->id);
}
return 1;
}

public function Cart_details($id)
{
    try {
        $decryptedId = Crypt::decrypt($id);
        
        $Productreviews = DB::select('SELECT * FROM product_reviews WHERE product_id = ?', [$decryptedId]);
        $prod = Apidata::find($decryptedId);
   
        if ($prod) {
            // Encrypt the product ID
            $encryptedProductId = encrypt($prod->id);
            $prod->encryptedId = $encryptedProductId;
            
            Session::flash('success', 'Your Product Details Here....');
            return view("Cart_details", compact("prod", "Productreviews"));
        } else {
            Session::flash('error', 'No products found for this category');
            return redirect('/');
        }
    } catch (\Exception $e) {
        Session::flash('error', 'Invalid product ID');
        return redirect('/');
    }
}




public function ShopCategory(Request $request){

    $categoryName = urldecode($request->name);
    // dd($categoryName);
    // $prod = DB::select('SELECT * FROM products WHERE category = ?', [$categoryName]);
    $prod = DB::table('products')
    ->where('category', $categoryName)
    ->get();
$toprated = DB::select('
SELECT * FROM products  ORDER BY id DESC LIMIT 10
');
// dd($categoryName);
$allprod = DB::select('SELECT * FROM products ORDER BY id DESC LIMIT 20');
foreach ($prod as $product) {
    $product->encryptedId = encrypt($product->id);  
    }
foreach ($toprated as $product) {
     $product->encryptedId = encrypt($product->id);
     }
     foreach ($allprod as $product) {
        $product->encryptedId = encrypt($product->id);
        }
return view('Shop' ,compact('prod','toprated','allprod'));
}




public function writeblog()
{
return view('WriteBlog');
}

// for ajax api

public function CategoryProducts(Request $request)
{
// dd($request->all());

$prod = DB::select('select * from products where category=?', [$request->keyword]);

if (empty($prod)) {
    // No data for the specified category
    Session::flash('error','No products found for this category');
    return redirect()->back()->with('error', 'No products found for this category.');
}

foreach ($prod as $product) {
    $product->encryptedId = encrypt($product->id);
}

// dd($prod);
return response()->json($prod);
}


public function WishList(Request $request){
// dd($request->all());
if(Auth::check()){
  // Attempt to find a wishlist record with the given product_id and email
  $wishlist = Wishlist::where('product_id', $request->product_id)
  ->where('email', $request->email)
  ->firstOrNew();

// Check if the wishlist is not already stored in the database
if (!$wishlist->exists) {
// If it's a new wishlist, set the product_id and email and save it
$wishlist->product_id = $request->product_id;
$wishlist->email = $request->email;
$wishlist->save();
Session::flash('success','Your Favourite Product Is Saved In Wish List');
 return redirect()->back();
// You can add a success message or any additional actions here
} else {
// 
// You can return a message to inform the user about the existing wishlist
Session::flash('error','Wishlist already exists for the given product_id and email');
}
Session::flash('success','Your Favourite Product Is Saved In Wish List');
 return redirect()->back();
}
else {
    Session::flash('error','Login For Wish List');
   return redirect('/login');
}
}

public function wishlists(Request $request){
    if (Auth::check()) {
        $email = Auth::user()->email;
        $wishlist = DB::table('products')
            ->join('whish_list', 'products.id', '=', 'whish_list.product_id')
            ->where('whish_list.email', '=', $email)
            ->get();
            $toprated = DB::select('
SELECT * FROM products  ORDER BY id DESC LIMIT 10
');
//    DD($wishlist);
foreach ($wishlist as $product) {
    $product->encryptedId = encrypt($product->id);
}
foreach ($toprated as $product) {
    $product->encryptedId = encrypt($product->id);
}

        Session::flash('success', 'Your Wish List Is Here......');
        return view('Wishlist', compact('wishlist','toprated'));
    } else {
        return redirect('/login');
    }
}


public function footerdata()
{
    $footer = DB::select("select * from footers");
 return response()->json($footer);
}

public function footerlinks()
{
    $socials = DB::select("select * from footer_links");
 return response()->json($socials);
}

public function brandlogos()
{
    $logos = DB::select("select * from brand_logos");
 return response()->json($logos);
}






// public function visit(Request $request)
// {
   
//     $ipAddress = $request->input('ip_address');
  
//     // Store the IP address in the database using Eloquent
//     // dd($ipAddress);
//     $ipget = new Visit;
//     $ipget->ip_address =$ipAddress;
//     $ipget->save();
//     // dd($ipget);
//     return response()->json(['message' => 'IP address stored successfully']);
// }


public function visit(Request $request)
{
    $ipAddress = $request->input('ip_address');
    // dd($ipAddress);
    // Check if the IP address already exists in the database
    $existingIP = Visit::where('ip_address', $ipAddress)->first();
    
    if (!$existingIP) {
        // If IP address doesn't exist, store it in the database
        $newIP = new Visit;
        $newIP->ip_address = $ipAddress;
        $newIP->save();
        
        return response()->json(['message' => 'IP address stored successfully']);
    } else {
        return response()->json(['message' => 'IP address already exists']);
    }
}

}