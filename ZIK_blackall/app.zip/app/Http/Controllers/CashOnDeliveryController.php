<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CashOnDelivery;
use App\Models\Multipleorder;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Str;
use App\Mail\Zakriaish;
use App\Mail\Multipleorders;
use App\Mail\test;
use Ramsey\Uuid\Uuid;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Auth;
class CashOnDeliveryController extends Controller
{


    public function ShippingOrder(Request $request)
    {
      
        return view('PlaceOrder');
    }

    public function CashOrder(Request $request)
    {
//    dd($request->all());

        $request->validate([
            'user_name' => 'required',
            'user_email' => 'required|email',
            'user_address' => 'required',
            'street_address' => 'required',
            'order_country' => 'required',
            'user_contact' => 'required',
            'order_state' => 'required',
            'order_city' => 'required',
        ], [
            'user_name.required' => 'Please enter your name.',
            'user_email.required' => 'Please enter your email address.',
            'user_address.required' => 'Please enter a valid address.',
            'street_address.required' => 'Please enter your Street Address information.',
            'user_contact.required' => 'Please enter your contact information',
            'order_state.required' => 'Please enter your State information.',
            'order_city.required' => 'Please enter your City.',
            'order_country.required' => 'Please enter your Country.',
        ]);

        $cashorder = new CashOnDelivery;

        $cashorder->product_id = $request->product_id;
        $cashorder->product_name = $request->product_name;
        $cashorder->product_price = $request->product_price;
        $cashorder->product_quantity = $request->product_quantity;
        $cashorder->user_name = $request->user_name;
        $cashorder->user_email = $request->user_email;
        $cashorder->user_address = $request->user_address;
        $cashorder->user_contact = $request->user_contact;
        $cashorder->street_address = $request->street_address;
        $cashorder->order_country = $request->order_country;
        $cashorder->order_city = $request->order_city;
        $cashorder->order_state = $request->order_state;

        $cashorder->status = 'Active';

        $cashorder->order_id = Str::random(18);
        $cashorder->save();

        $data = [
            'user_name' => $request->user_name,
            'user_email' => $request->user_email,
            'product_name' => $request->product_name,
            'product_price' => $request->product_price,
            'imgs' => $request->imgs,
            'order_id' => $cashorder->order_id,
        ];

        $saved = $cashorder->save();
        // dd($cashorder);
        if ($saved) {
            Mail::to($request->user_email)->send(new Zakriaish($data));
            Mail::to('saraanahmed935@gmail.com')->send(new Zakriaish($data));
            Session::flash('success', 'Your Order Details have been sent to your email.');
            return redirect('/success');
        }

        Session::flash('error', 'Your Order is Not Ready To Be Delivered.');
        return redirect()->back();
    
    }
    
    public function testingmail(Request $request){

   
        $data = [
            'username' => "John Doe", // Replace with the actual username
            'email' => "johndoe@example.com", // Replace with the actual email address
            'totalprice' => 2800.00, // Replace with the actual total price
            'contactno' => "1234567890", // Replace with the actual contact number
        ];

      
    
        Mail::to('saraanahmed935@gmail.com')->send(new test($data));
        dd('testing done');
    }
    public function multipleorders(Request $request){

            $request->validate([
                'username' => 'required',
                'email' => 'required|email',
                'address' => 'required',
                'contactno' => 'required',
                'city' => 'required',
         
                
            ], [
                'username.required' => 'Please enter your name.',
                'email.required' => 'Please enter your email address.',
                'address.required' => 'Please enter a valid address.',
                'contactno.required' => 'Please enter your contact information.',
                'city.required' => 'Please enter your City.',
            
            ]);
    
            $cashorder = new Multipleorder();
            $productsJson = $request->input('products');
            $products = json_decode($productsJson);
            $cashorder->username = $request->username;
            $cashorder->total_price = $request->total_price;
            $cashorder->email = $request->email;
            $cashorder->address = $request->address;
            $cashorder->city = $request->city;
            $cashorder->contactno = $request->contactno;
            $cashorder->products = serialize($products);
            $cashorder->order_id = Str::random(10);
            $cashorder->save();
    
            $data = [
                'username' => $request->username,
                'email' => $request->email,
                'totalprice' => $request->total_price,
                'contactno' => $request->contactno,
                'products' => serialize($products),
            ];

            $saved = $cashorder->save();
            if ($saved) {
                Mail::to($request->email)->send(new Multipleorders($data));
                Mail::to('saraanahmed935@gmail.com')->send(new Multipleorders($data));
                Session::flash('success', 'Your Order Details have been sent to your email.');
                return redirect('/success');
            }

            Session::flash('error', 'Your Order is Not Ready To Be Delivered.');
            return redirect()->back();
        
    }
    

    public function showcashorder(Request $request)
    {
       
        $decryptedId = Crypt::decrypt($request->id);
        $getProd = DB::table('products')->where('id', $decryptedId)->first();
    
        // Retrieve the initial quantity from the query parameters, default to 1 if not provided
        $initialQuantity = $request->query('quantity', 1);
    
        // Retrieve the updated quantity and price from the query parameters, default to initial values if not provided
        $quantity = $request->query('quantity', $initialQuantity);
        $price = $request->query('price', 0);
    
        // Update the price based on the new quantity
        $totalPrice = $price * $quantity;
        // dd($totalPrice);
        // Pass the initial quantity, updated quantity, and price to the view
        return view("CashPay", compact('getProd', 'initialQuantity', 'quantity', 'totalPrice'));
    }
    

  

    public function  updatecashorder(Request $request){
        $cashorder=CashOnDelivery::find($request->id);
        $cashorder->product_id=$request->product_id;
        $cashorder->product_name=$request->product_name;
        $cashorder->product_price=$request->product_price;
        $cashorder->user_name=$request->user_name;
        $cashorder->user_email=$request->user_email;
        $cashorder->user_address=$request->user_address;
        $cashorder->user_contact=$request->user_contact;
        $cashorder->street_address=$request->street_address;
        $cashorder->order_country=$request->order_country;
        $cashorder->order_city=$request->order_city;
        $cashorder->order_state=$request->order_state;
        $cashorder->status=$request->status;
        // dd($cashorder);
        $cashorder->save();
        Session::flash('Sucess',"Your Order  is Ready To Deliverd  ");
        return redirect('showcashorder');
    }


public function success(){
    return view('Success');
}

}
