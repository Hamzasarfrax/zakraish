<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ClientReview;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Crypt;
class ClientReviewController extends Controller
{

    public function storeclientreviews(Request $request){
        $request->validate([
            'client_image' => 'required|file|mimes:jpeg,png,jpg,gif,svg,mp3,mp4',
        ]);
        

        $imageName = time().'.'.$request->client_image->extension();
        $request->client_image->move(public_path('client_reviews'), $imageName);
        $clientreview=new ClientReview;
        $clientreview->client_image=$imageName;
        $clientreview->client_name=$request->client_name;
        $clientreview->client_email=$request->client_email;
        $clientreview->client_message=$request->client_message;
        $clientreview->client_reviews=$request->client_reviews;
        $clientreview->client_description=$request->client_description;
        $clientreview->blog_type='blogs';
        $clientreview->status='inactive';
        Session::flash('Sucess',"Your Review is Under Review After Review It Will Show Thank You");
        // dd($clientreview);
        $clientreview->save();
        return redirect('blogs');
    }


    public function showblogs(Request $request)
{

    $perPage = 8;

    $clientReviewLatest = DB::table('client_reviews')
        ->orderBy('created_at', 'desc')
        ->where('status','active')
        ->where('blog_type','blogs')
        ->paginate($perPage); 

    foreach ($clientReviewLatest as $latest) {
        $latest->encrypt_id = Crypt::encrypt($latest->id);
    }
    return view("Blogs", compact('clientReviewLatest'));
}
    

    public function blog_details(Request $request)
    { 
        $decryptid = Crypt::decrypt($request->id);
        $blogdetails = DB::table('client_reviews')
            ->where('id', $decryptid)
            ->first();
    
        $recentlyCreatedBlogs = DB::table('client_reviews')
            ->where('created_at', '>', $blogdetails->created_at)
            ->orderBy('created_at', 'desc')
            ->get();
            foreach ($recentlyCreatedBlogs as $recnt) {
                $recnt->encrypt_id = Crypt::encrypt($recnt->id);
            }
        return view('Blog_details', compact('blogdetails', 'recentlyCreatedBlogs'));
    }


    

    
}
