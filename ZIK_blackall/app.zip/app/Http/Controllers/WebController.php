<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Apidata;
use App\Models\ProductCategory;
use App\Models\MainSlide;
use App\Models\Productreviews;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;



class WebController extends Controller
{


     public function ContactUs()
     {
          return view('ContactUs');
     }

     public function blogs()
     {
          return view('Blogs');
     }

     public function ShopProduct()
     {
          return view('Shop');
     }

     public function TermsCondition()
     {
          return view('Terms&Condition');
     }

     public function TrackOrder()
     {
          return view('TrackOrder');
     }
     public function AboutUs()
     {
          return view('About');
     }

     public function ReturnPage()
     {
          return view('Return');
     }
   
}
