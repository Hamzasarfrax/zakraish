<?php

namespace App\Http\Controllers;

use App\Models\TrackOrder;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
class TrackOrderController extends Controller
{
 
    public function TrackOrder()
{
return view('TrackOrder');
}
public function __construct() {
    $this->middleware('auth');
 }

public function Trackorders(Request $request)

{



      if (Auth::check()) {
     
    if ($request->order_id) {

        $toprated = DB::select('SELECT * FROM products WHERE type = ? ORDER BY id DESC ', ['BestSellers']);
        foreach ($toprated as $product) {
            $product->encryptedId = encrypt($product->id);
        }

        $Track = DB::select('SELECT * FROM cash_on_deliveries WHERE order_id = ?', [$request->order_id]);
        if (!$Track) {
            // Handle case when order ID does not exist
            Session::flash('error','Your Order Id Is Not Correct');
            return redirect('/');
        }

        $Trackorder = DB::table('products')
            ->join('cash_on_deliveries', 'products.id', '=', 'cash_on_deliveries.product_id')
            ->where('cash_on_deliveries.order_id', $Track[0]->order_id)
            ->first();

        if (!$Trackorder) {
            // Handle case when order is not found
            Session::flash('error','Your Order Id Is Not Correct');
            return redirect('/');
        } else {
            Session::flash('success','Your Order is Here');
            return view('TrackOrder', compact('Trackorder','toprated'));
        }
    }
    } else {
        // User is not logged in. Redirect to login page or perform other actions as needed.
        return redirect()->route('login'); // Example redirection to the login page using named route 'login'.
    }

}

  
public function productfilter(Request $request)
{
    $keyword = $request->input('keyword');

    $products = DB::table('products')
        ->select('products.*')
        ->where('name', 'LIKE', '%'.$keyword.'%')
        ->get();

    foreach ($products as $product) {
        $product->encryptedId = encrypt($product->id);
    }

    return response()->json($products);
}

public function Trackordersprod(){
    $toprated = DB::select('SELECT * FROM products WHERE type = ? ORDER BY id DESC LIMIT 8 ', ['BestSellers']);
    foreach ($toprated as $product) {
        $product->encryptedId = encrypt($product->id);
    }
    return view('TrackOrder', compact('toprated'));
}

}
