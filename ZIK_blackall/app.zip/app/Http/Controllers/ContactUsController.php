<?php

namespace App\Http\Controllers;

use App\Models\ContactUs;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Mail;
use App\Mail\ContactMail;
class ContactUsController extends Controller
{
  
    public function storecontactus(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required|email',
            'contact' => 'required',
            'message' => 'required',
        ], [
            'name.required' => 'Please enter your name.',
            'email.required' => 'Please enter your email address.',
            'email.email' => 'Please enter a valid email address.',
            'contact.required' => 'Please enter your contact information.',
            'message.required' => 'Please enter a message.',
        ]);
    
        // $existingContactUs = ContactUs::where('email', $request->email)->first();
        // if ($existingContactUs) {
        //     return redirect()->back()->withErrors(['email' => 'Email already exists']);
        // }
    
        $ContactUs = new ContactUs;
        $ContactUs->name = $request->name;
        $ContactUs->email = $request->email;
        $ContactUs->contact = $request->contact;
        $ContactUs->message = $request->message;
        $ContactUs->save();
        $saved = $ContactUs->save();
        $data = [
            'name' => $request->name,
            'email' => $request->email,
            'contact' => $request->contact,
            'message' => $request->message,
         
        ];
        // dd($request->email);
        if ($saved) {
            Mail::to($request->email)->send(new ContactMail($data));
            Mail::to('saraanahmed935@gmail.com')->send(new ContactMail($data));


            Session::flash('success', 'Your Contact Details have been sent to your email.');
         

        }

        // dd("Email is sent successfully.");
        return redirect()->back()->with('success', 'Your form is submitted successfully');
    }
    
    
}
