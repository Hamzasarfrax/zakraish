<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Models\Productreviews;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Crypt;
class ProductReviewsController extends Controller
{
    public function storeproduct(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'product_id' => 'required',
            'client_name' => 'required',
            'client_email' => 'required|email',
            'client_message' => 'required',
            'client_rating' => 'required|integer|min:1|max:5',
        ]);
    
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }
    
        $existingReview = Productreviews::where('client_email', $request->client_email)
            ->where('product_id', $request->product_id)
            ->first();
    
        if ($existingReview) {
            return redirect()->back()->with('error', 'You have already submitted a review for this product with this email address.');
        }
    
        $prodreview = new Productreviews;
        $prodreview->product_id = $request->product_id;
        $prodreview->client_name = $request->client_name;
        $prodreview->client_email = $request->client_email;
        $prodreview->client_message = $request->client_message;
        $prodreview->client_rating = $request->client_rating;
    
        $prodreview->save();
    
        return redirect()->back()->with('success', 'Your review has been submitted successfully.');
    }
    
}
