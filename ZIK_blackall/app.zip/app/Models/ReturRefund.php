<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ReturRefund extends Model
{
    public $timestamps = false;
    use HasFactory;
    protected $table ='return_refund';
    protected $fillable =[
        'order_id','contact_no',
    ];
}
