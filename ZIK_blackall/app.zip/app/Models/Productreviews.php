<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Productreviews extends Model
{
    use HasFactory;
    protected $table='product_reviews';
    protected $fillable=[
        'product_id','client_name','client_email','client_message','client_rating'
    ];
}
