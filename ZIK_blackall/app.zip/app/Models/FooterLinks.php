<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FooterLinks extends Model
{
    use HasFactory;
    protected $table='footer_links';
    protected $fillable=[
        'social_name','social_link'
    ];
}
