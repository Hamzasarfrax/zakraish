<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CashOnDelivery extends Model
{
    use HasFactory;
    protected $fillable=[
        'product_id','product_name',"product_price","user_name","user_email","user_address","user_contact",'status'
    ];
protected $table='cash_on_deliveries';

}
