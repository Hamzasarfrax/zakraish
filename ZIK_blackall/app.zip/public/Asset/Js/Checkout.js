

//    document.addEventListener('DOMContentLoaded', function() {
//         let cart = [];
//         let cartAlertTimeout;

//         document.querySelectorAll('.sweet_alerts_messages .toast-close').forEach(function(element) {
//             element.addEventListener('click', function() {
//                 let cartAlert = document.querySelector('.cart_alert');
//                 if (cartAlert) {
//                     cartAlert.remove();
//                 }
//             });
//         });

//         function hideCartAlert() {
//             let cartAlert = document.querySelector('.cart_alert');
//             if (cartAlert) {
//                 cartAlert.remove();
//             }
//         }

//         setTimeout(function() {
//             hideCartAlert();
//         }, 4000);

//         document.querySelectorAll('.checkout_box .head i').forEach(function(element) {
//             element.addEventListener('click', function() {
//                 let checkoutBox = document.querySelector('.checkout_box');
//                 if (checkoutBox) {
//                     checkoutBox.classList.toggle('active');
//                 }
//             });
//         });

//         document.getElementById('cart_check').addEventListener('click', function() {
//             let checkoutBox = document.querySelector('.checkout_box');
//             if (checkoutBox) {
//                 checkoutBox.classList.toggle('active');
//             }
//         });

//         let itemlenght = JSON.parse(localStorage.getItem('cart')) || [];
//         let lenghtcart = itemlenght.length;
//         document.getElementById('counter').textContent = lenghtcart;
//         document.getElementById('lenght').textContent = lenghtcart;

//         displayCartItems();

//         document.querySelectorAll('button.btn.btn_cart.add-to-cart-btn.text-capitalize').forEach(function(element) {
//             element.addEventListener('click', function() {
//                 alert('We are working, please wait for updates');
//                 let id = this.getAttribute('data-id');
//                 let name = this.getAttribute('data-name');
//                 let price = this.getAttribute('data-price');
//                 let encid = this.getAttribute('data-encid');
//                 let img = this.getAttribute('data-img');

//                 let cartItem = {
//                     id,
//                     name,
//                     price,
//                     encid,
//                     img,
//                     quantity: 1
//                 };

//                 let messagesDiv = document.getElementById('messages');
//                 if (messagesDiv) {
//                     messagesDiv.innerHTML = `
//                         <div class="sweet_alerts_messages cart_alert">
//                             <div class="mesg_box success box">
//                                 <div class="mesg">
//                                     Product Added ${cartItem.name} Successfully
//                                 </div>
//                                 <div class="close">
//                                     <i class="fa-solid fa-xmark toast-close"></i>
//                                 </div>
//                                 <div class="progress"></div>
//                             </div>
//                         </div>`;
//                 }

//                 let existingCart = JSON.parse(localStorage.getItem('cart')) || [];

//                 let existingItemIndex = existingCart.findIndex(item => item.id === id);

//                 if (existingItemIndex !== -1) {
//                     alert("Already Exist Item");
//                     existingCart[existingItemIndex].quantity += 1;
//                 } else {
//                     existingCart.push(cartItem);
//                 }

//                 localStorage.setItem('cart', JSON.stringify(existingCart));

//                 displayCartItems(existingCart);

//                 let totalItems = existingCart.length;
//                 document.getElementById('counter').textContent = totalItems;
//                 document.getElementById('lenght').textContent = totalItems;

//                 clearTimeout(cartAlertTimeout);
//                 cartAlertTimeout = setTimeout(function() {
//                     hideCartAlert();
//                 }, 4000);

//                 console.log(existingCart);
//             });
//         });

//         function displayCartItems(cart) {
//             let cartItems = document.getElementById('cart_items');
//             cartItems.innerHTML = '';

//             let productcart = JSON.parse(localStorage.getItem('cart')) || [];

//                 productcart.forEach(item => {
//                     let cartItemHTML = `
//                         <li>
//                             <a href=''>
//                                 <div class="cart_details" data-id='${item.id}'>
//                                     <div class="cart_img">
//                                         <img src="https://adminlaravell.foodbaskit.com//public/images/${item.img}" class="img-fluid" alt="">
//                                     </div>
//                                     <div class="cart_title">
//                                         <a href="cart_details/${item.encid}" class="name">
//                                             ${item.name}
//                                         </a>
//                                         <div class="price">
//                                             Pkr <span class="amount">${item.price}</span>
//                                         </div>
//                                     </div>
//                                     <div class="cart_remove" onclick="removecart(${item.id})" data-id='${item.id}'>
//                                         <i class="fa-solid fa-trash"></i>
//                                     </div>
//                                 </div>
//                             </a>
//                         </li>
//                     `;
//                     cartItems.insertAdjacentHTML('beforeend', cartItemHTML);
//                 });

//             // else {
//             //     // Fetch cart items from the API if local storage is empty
//             //     fetch('https://zakriaish.com/products')
//             //         .then(function(response) {
//             //             return response.json();
//             //         })
//             //         .then(function(result) {
//             //             console.log(result);
//             //             result.forEach(item => {
//             //                 let cartItemHTML = `
//             //                     <li>
//             //                         <a href=''>
//             //                             <div class="cart_details" data-id='${item.id}'>
//             //                                 <div class="cart_img">
//             //                                     <img src="https://adminlaravell.foodbaskit.com//public/images/${item.img}" class="img-fluid" alt="">
//             //                                 </div>
//             //                                 <div class="cart_title">
//             //                                     <a href="cart_details/${item.encid}" class="name">
//             //                                         ${item.name}
//             //                                     </a>
//             //                                     <div class="price">
//             //                                         Pkr <span class="amount">${item.price}</span>
//             //                                     </div>
//             //                                 </div>
//             //                                 <div class="cart_remove" onclick="removecart(${item.id})" data-id='${item.id}'>
//             //                                     <i class="fa-solid fa-trash"></i>
//             //                                 </div>
//             //                             </div>
//             //                         </a>
//             //                     </li>
//             //                 `;
//             //                 cartItems.insertAdjacentHTML('beforeend', cartItemHTML);
//             //             });
//             //         });
//             // }
//         }

//         window.removecart = function(dataid) {
//             let existingCart = JSON.parse(localStorage.getItem('cart')) || [];

//             let itemsToRemove = existingCart.filter(function(item) {
//                 return item.id == dataid;
//             });

//             console.log("Items to remove:", itemsToRemove);

//             if (itemsToRemove.length > 0) {
//                 existingCart = existingCart.filter(function(item) {
//                     return item.id !== dataid;
//                 });

//                 localStorage.setItem("cart", JSON.stringify(existingCart));
//                 displayCartItems();

//                 let messagesDiv = document.getElementById('messages');
//                 if (messagesDiv) {
//                     messagesDiv.innerHTML = `
//                         <div class="sweet_alerts_messages cart_alert">
//                             <div class="mesg_box error box">
//                                 <div class="mesg">
//                                     Product Deleted With ID ${dataid} Successfully
//                                 </div>
//                                 <div class="close">
//                                     <i class="fa-solid fa-xmark toast-close"></i>
//                                 </div>
//                                 <div class="progress"></div>
//                             </div>
//                         </div>`;
//                 }

//                 let lenghtcart = existingCart.length;
//                 document.getElementById('counter').textContent = lenghtcart;
//                 document.getElementById('lenght').textContent = lenghtcart;

//                 clearTimeout(cartAlertTimeout);
//                 cartAlertTimeout = setTimeout(function() {
//                     hideCartAlert();
//                 }, 4000);

//                 console.log("Updated cart:", existingCart);
//             }
//         };
//     });
