// my all javascript code





var cururl = window.location.pathname;
var curpage = cururl.substr(cururl.lastIndexOf('/') + 1);
var hash = window.location.hash.substr(1);
if((curpage === "" || curpage === "/" || curpage === "admin") && hash === "")
  {
  } else {
    $(".header-navigation li").each(function()
  {
    $(this).removeClass("active");
  });
  if(hash != "")
    $(".header-navigation li a[href='"+hash+"']").parents("li").addClass("active");
  else
  $(".header-navigation li a[href='"+curpage+"']").parents("li").addClass("active");
}
function scrollToTop() {
  var $scrollUp = $('#scroll-to-top'),
    $lastScrollTop = 0,
    $window = $(window);

  $window.on('scroll', function () {
    var st = $(this).scrollTop();
    if (st > $lastScrollTop) {
      $scrollUp.removeClass('show');
      $('.sticky-header').removeClass('sticky-show');
    } else {
      if ($window.scrollTop() > 250) {
        $scrollUp.addClass('show');
        $('.sticky-header').addClass('sticky-show');
      } else {
        $scrollUp.removeClass('show');
        $('.sticky-header').removeClass('sticky-show');
      }
    }
    $lastScrollTop = st;
  });

  $scrollUp.on('click', function (evt) {
    $('html, body').animate({ scrollTop: 0 }, 500); // Changed the scroll time to 500ms for smoother scrolling
    evt.preventDefault();
  });
}

scrollToTop();

var $window = $(window); // Declare $window variable

$window.on('scroll', function () {
  if ($('.sticky-header').length) {
    var windowpos = $window.scrollTop(); // Use the previously declared $window
    if (windowpos >= 250) {
      $('.sticky-header').addClass('sticky');
    } else {
      $('.sticky-header').removeClass('sticky');
    }
  }
});


$(document).ready(function () {
  // Get the user's IP address using the ipify API
  $.getJSON("https://api.ipify.org?format=json", function (data) {
    var ipAddress = data.ip;

    // alert(ipAddress)
    // Send the IP address to the Laravel route using AJAX
    $.ajax({
      type: "POST",
      url: "/store-ip", // Correct URL path
      data: {
        ip_address: ipAddress,
      },
      headers: {
        "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
      },
      success: function (response) {
        // console.log("IP address sent and stored successfully!");
        console.log(response);
      },
      error: function (error) {
        console.error("Error sending IP address:", error);
      },
    });

  });
});

document.addEventListener("DOMContentLoaded", function () {
  // Add a class to the body element to indicate that the content is loaded
  setTimeout(() => {
    let loader = $(".load");
    loader.fadeOut(3000);
  }, 2000);
});

$(document).ready(function () {
  var starValue = 0;

  $(".revies_stars i").hover(function () {
    var index = $(this).index();
    starValue = index + 1;
    $("#reviews_products").val(starValue);
    highlightStars(starValue);
  });

  $(".revies_stars i").click(function () {
    $("#reviews_products").val(starValue);
  });

  function highlightStars(count) {
    $(".revies_stars i").removeClass("fas").addClass("far");
    for (var i = 0; i < count; i++) {
      $(".revies_stars i").eq(i).removeClass("far").addClass("fas");
    }
    $("#reviews_products").val(count);
  }

  // Set the initial star value in #reviews_products
  var initialStarValue = 1; // Replace with your desired initial star value
  starValue = initialStarValue;
  $("#reviews_products").val(starValue);
  highlightStars(starValue);
});

$(".revies_stars i").click(function () {
  let getval = $(this).attr("data-val");

  $("#reviews_products").val(getval);
});

$(document).ready(function () {
  $('[data-bs-toggle="tooltip"]').tooltip();
});

$(".side_bar_menu___mobile .item").click(function () {
  $(this).toggleClass("active");
  var $menuDrops = $(this).find(".menu_drops");

  if ($menuDrops.hasClass("active")) {
    // Remove class if it is already active
    $menuDrops.removeClass("active");
    $(this).removeClass("active");
  } else {
    // Remove class from other elements
    $(".side_bar_menu___mobile .item .menu_drops").removeClass("active");
    $(".side_bar_menu___mobile .item").removeClass("active");
    // Add class to clicked element
    $menuDrops.addClass("active");
    $(this).addClass("active");
  }
});

$(".toglle_icon ").click(function () {
  $("body").toggleClass("active");
if( $("body").hasClass('active')){
  $(".side_bar_menu___mobile").addClass("active");
  $(".overlay").addClass("active");
}
else{
  $(".side_bar_menu___mobile").removeClass("active");
  $(".overlay").removeClass("active");
  $("body").removeClass("active");
}

});

$(".overlay").click(function () {
  $(this).removeClass("active");
  $("body").removeClass("active");
  $(".side_bar_menu___mobile").toggleClass("active");
  document.querySelector(
    ".toglle_icon"
  ).innerHTML = `<i class="fa-solid fa-bars"></i>`;
});

$(".custom_filter_cat .input_tag").click(function () {
  $(".custom_filter_cat .menu").toggleClass("active");
  $(this).toggleClass("active");
});

$(document).ready(function () {
  let window_locate = window.location.pathname;

  let nav_links = $(".nav_bar a");

  $(nav_links).each(function () {
    let hrefatr = $(this).attr("href");
    if (window_locate == hrefatr) {
      $(this).addClass("active");
      $(this).find("a").addClass("active");
    } else {
      $(this).removeClass("active");
    }
  });
});

$(window).scroll(function () {
  var scrollBody = $(this).scrollTop();
  if (scrollBody >= 300) {
    $("#navbar").addClass("sticky-show");
  } else if (scrollBody <= 200) {
    $("#navbar").removeClass("sticky-show");
  } else {
    $("#navbar").removeClass("sticky-show");
  }
});

$("#toast_container .toast-close").click(function () {
  $("#toast_container").addClass("active");
});

$(document).ready(function () {
  $("#toast_container .progress").addClass("active");
  setTimeout(() => {
    $("#toast_container").addClass("active");
  }, 5000);
});

$(document).ready(function () {
  setTimeout(callalerts, 8000);
});

function callalerts() {
  $(".sweet_alerts_messages .mesg_box").addClass("active");
  $(".sweet_alerts_messages").remove();
}

// Click event handler for the close button
$(".sweet_alerts_messages .close").click(function () {
  $(".sweet_alerts_messages .mesg_box").addClass("active");
  callalerts();
  // Remove the HTML of mesg_box after adding the "active" class
  $(".sweet_alerts_messages").remove();
});




$(".sweet_alerts_messages  #close").click(function () {
  $("html body .sweet_alerts_messages.cart_alert").remove();
});
setTimeout(() => {
  $("html body .sweet_alerts_messages .cart_alert").remove();
  $(".sweet_alerts_messages.cart_alert").remove();
}, 4000);
$(".checkout_box .head i").click(function () {
  $(".checkout_box").toggleClass("active");
});

$("header #cart_check").click(function () {
  $(".checkout_box").toggleClass("active");
});




window.toastclose = function () {
  $(".sweet_alerts_messages").remove();
};

window.onload = function () {
  setTimeout(() => {
    $("html body .sweet_alerts_messages.cart_alert");
  }, 4000);
};













document.addEventListener("load", function () {
  const inputElement = document.getElementById("files");
  const uploadedImagesContainer = document.getElementById(
    "uploadedImagesContainer"
  );

  // Event listener to handle file selection
  inputElement.addEventListener("change", handleFileSelect, false);

  function handleFileSelect(event) {
    const files = event.target.files;
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const reader = new FileReader();

      // Closure to capture the file information
      reader.onload = (function (theFile) {
        return function (e) {
          // Create a new image element
          const imgElement = document.createElement("img");
          imgElement.className = "uploaded-image";
          imgElement.src = e.target.result;
          inputElement.style.display = "none";

          // Append the image to the container
          uploadedImagesContainer.appendChild(imgElement);
        };
      })(file);

      // Read the image file as a data URL
      reader.readAsDataURL(file);
    }
  }
});




