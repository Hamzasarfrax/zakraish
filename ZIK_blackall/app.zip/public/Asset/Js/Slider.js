$('.main_slides').slick({
     infinite: true,
     slidesToShow: 1,
     slidesToScroll: 1,
     autoplay: true, // Enables automatic sliding
     autoplaySpeed: 2000, // Sets the duration between slides (in milliseconds)
     dots: true, // Shows the navigation dots
     arrows: true, // Shows the navigation arrows
   });
   
   
   $('.slider_trending__products').slick({
     slidesToShow: 1,
     slidesToScroll: 1,
     arrows: true, // Shows the navigation arrows
   });
   
   $('.client_slider').slick({
     slidesToShow: 8,
     slidesToScroll: 1,
     arrows: true, // Shows the navigation arrows
     responsive: [
       {
         breakpoint: 1024,
         settings: {
           slidesToShow: 5,
           slidesToScroll: 1,
           infinite: true,
           dots: true
         }
       },
       {
         breakpoint: 600,
         settings: {
           slidesToShow: 2,
           slidesToScroll: 1
         }
       },
       {
         breakpoint: 480,
         settings: {
           slidesToShow: 2,
           slidesToScroll: 1
         }
       }
       // You can unslick at a given breakpoint now by adding:
       // settings: "unslick"
       // instead of a settings object
     ]
   });
   
   $('.product_all___images .bottom_top___slider').slick({
     slidesToShow: 3,
     slidesToScroll: 1,
     arrows: true, // Shows the navigation arrows
     responsive: [
   
       {
         breakpoint: 700,
         settings: {
           slidesToShow: 2,
           slidesToScroll: 1
         }
       },
       {
         breakpoint: 480,
         settings: {
           slidesToShow: 2,
           slidesToScroll: 1
         }
       }
       // You can unslick at a given breakpoint now by adding:
       // settings: "unslick"
       // instead of a settings object
     ]
   });
   // this is discover
   
   $('.discover_products').slick({
     slidesToShow: 4,
     slidesToScroll: 1,
     arrows: true, // Shows the navigation arrows
     responsive: [
   
       {
         breakpoint: 700,
         settings: {
           slidesToShow: 2,
           slidesToScroll: 1
         }
       },
       {
         breakpoint: 480,
         settings: {
           slidesToShow: 1,
           slidesToScroll: 1
         }
       }
       // You can unslick at a given breakpoint now by adding:
       // settings: "unslick"
       // instead of a settings object
     ]
   });


  //  swiper_slides
  // fav slide swiper
  var swiper = new Swiper(".mySwiper", {
    spaceBetween: 10,
    slidesPerView: 4,
    freeMode: true,
    watchSlidesProgress: true,
  });
  var swiper2 = new Swiper(".mySwiper2", {
    spaceBetween: 10,
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
    thumbs: {
      swiper: swiper,
    },
  });
  /////////
  var swiper = new Swiper(".wraper_swiper", {
    effect: "cards",
    grabCursor: true,
  });

  // desired swiper
  var swiper = new Swiper(".desired_swiper", {
    effect: "coverflow",
    grabCursor: true,
    centeredSlides: true,
    slidesPerView: "auto",
    coverflowEffect: {
      rotate: 50,
      stretch: 0,
      depth: 100,
      modifier: 1,
      slideShadows: true,
    },
    pagination: {
      el: ".swiper-pagination",
    },
  });

  // trending slides
  var swiper = new Swiper(".trending_main", {
    spaceBetween: 10,
    slidesPerView: 4,
    freeMode: true,
    watchSlidesProgress: true,
  });
  var swiper2 = new Swiper(".trend_bottom", {
    spaceBetween: 10,
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
    thumbs: {
      swiper: swiper,
    },
  });
   
   $('.imgs_for_details img').click(function () {
   
     var activeSlide = $(this).attr('src');
     var mainSlide = $('#main_product_img');
   
     mainSlide.fadeOut(400, function () {
   
       mainSlide.attr('src', activeSlide).fadeIn(400);
     });
   });
   $('.product_all___images .slick-arrow').click(function () {
     var activeSlide = $('.slick-slide.slick-active .imgs_for_details img');
     var mainSlide = $('.main_top___slide img');
   
     mainSlide.fadeOut(400, function () {
       mainSlide.attr('src', activeSlide.attr('src')).fadeIn(400);
     });
   });


   $('.slider_trending__products .slick-arrow').click(function() {
    let trend_img = $('.slider_trending__products .slick-active .trending_imgs').attr('src');
    $('.trending_project_img img').fadeOut(400, function() {
      $(this).attr('src', trend_img).fadeIn(400);
    });
  });
  


