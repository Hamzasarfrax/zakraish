<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table)
    {
        $table->id();
        $table->string('name');
        $table->string('product_type');
        $table->string('price');
        $table->string('old_price');
        $table->string('description');
        $table->string('type');
        $table->string('category');
        $table->string('ingredients');
        $table->string('ratings');
        $table->string('images');
        $table->string('images2')->nullable();
        $table->string('images3')->nullable();
        $table->string('images4')->nullable();
        $table->string('status')->default('active');
        $table->timestamps();

    });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        //
    }
};
