<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('order', function (Blueprint $table)
    {
        $table->id();
        $table->string('email');
        $table->string('client_name');
        $table->string('contact');
        $table->string('address');
        $table->string('name');
        $table->string('price');
        $table->unsignedBigInteger('product_id');
        $table->foreign('product_id')->references('id')->on('products');
        $table->string('description')->nullable();
        $table->string('type')->nullable();
        $table->string('category')->nullable();
        $table->string('images')->nullable();
        $table->string('status')->default('active');
        $table->timestamps();

    });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        //
    }
};
