$(function () {

  $('.open_sweet_alert').click(function () {
    $('.box_alert_for_delete').toggleClass('active');
  })
  $('.btn_del.remove').click(function () {
    $('.box_alert_for_delete').removeClass('active')
  })
  $(".navbar_toggler[type='button']").click(function () {
    $(".sidebar").toggleClass("active");
    $(this).toggleClass("active");
    $("body").toggleClass("active");

  });
  $(document).ready(function () {
    let locations = window.location.pathname;
    let hrefval = $(".menu a");

    hrefval.each(function () {
      let item = $(this).attr("href");
      if (item === locations) {
        $(this).addClass("active");
        $(this).parents(".dropdown_menu_item").addClass("active");
        console.log('done');
      } else if (item === "/" && locations.includes("/home")) {
        $(this).addClass("active");

      } else {
        $(this).removeClass("active");
        $(this).parents(".dropdown_menu_item").removeClass("active");

      }
    });
  });




  var swiper = new Swiper(".mySwiper", {
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
  });

  var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
  var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl);
  });

  //   charts
  var options = {
    series: [{
      name: 'Net Profit',
      data: [44, 55, 57, 56, 61, 58, 63, 60, 66]
    }, {
      name: 'Revenue',
      data: [76, 85, 101, 98, 87, 105, 91, 114, 94]
    }, {
      name: 'Free Cash Flow',
      data: [35, 41, 36, 26, 45, 48, 52, 53, 41]
    }],
    chart: {
      type: 'bar',
      height: 350,
      background: '#ffffff',

      borderRadius: '50%',
    },
    colors: ['#0E2954', '#d10024e6', '#1e1f29', '#f24c3d', '#5C8984'],
    plotOptions: {
      bar: {
        horizontal: false,
        columnWidth: '55%',
        endingShape: 'rounded'
      },
    },
    dataLabels: {
      enabled: false
    },
    stroke: {
      show: true,
      width: 2,
      colors: ['transparent']
    },
    xaxis: {
      categories: ['Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct'],
    },
    yaxis: {
      title: {
        text: '$ (thousands)'
      }
    },
    fill: {
      opacity: 1
    },
    tooltip: {
      y: {
        formatter: function (val) {
          return "$ " + val + " thousands"
        }
      }
    }
  };

  var chart = new ApexCharts(document.querySelector("#chart"), options);
  chart.render();





  // Define the chart options
  var options = {
    series: [44, 55, 41],
    chart: {
      type: 'donut',
      background: '#ffffff',

      borderRadius: '50%',
    },
    colors: ['#0E2954', '#d10024e6', '#1e1f29', '#f24c3d', '#5C8984'],
    legend: {
      position: 'bottom'
    },
    responsive: [{
      breakpoint: 480,
      options: {
        chart: {
          width: 200
        },
        legend: {
          position: 'bottom'
        },
        colors: ['#2E93fA', '#66DA26', '#546E7A', '#E91E63', '#FF9800']
      }
    }]
  };


  var chart = new ApexCharts(document.querySelector("#pie"), options);
  chart.render();

  // Render the chart
  pie.render();

  // Define the data
  var dates = [
    [new Date("2022-01-01").getTime(), 5000000],
    [new Date("2022-01-02").getTime(), 4000000],
    [new Date("2022-01-03").getTime(), 6000000],
    [new Date("2022-01-04").getTime(), 7000000],
    [new Date("2022-01-05").getTime(), 6500000],
    [new Date("2022-01-06").getTime(), 8000000],
    [new Date("2022-01-07").getTime(), 5500000],
  ];

  // Define the chart options
  var options = {
    series: [{
      name: 'PRODUCT A',
      data: [44, 55, 41, 67, 22, 43]
    }, {
      name: 'PRODUCT B',
      data: [13, 23, 20, 8, 13, 27]
    }, {
      name: 'PRODUCT C',
      data: [11, 17, 15, 15, 21, 14]
    }, {
      name: 'PRODUCT D',
      data: [21, 7, 25, 13, 22, 8]
    }],
    chart: {
      type: 'bar',
      height: 350,
      stacked: true,
      toolbar: {
        show: true
      },
      zoom: {
        enabled: true
      }
    },
    responsive: [{
      breakpoint: 480,
      options: {
        legend: {
          position: 'bottom',
          offsetX: -10,
          offsetY: 0
        }
      }
    }],
    plotOptions: {
      bar: {
        horizontal: false,
        borderRadius: 10,
        dataLabels: {
          total: {
            enabled: true,
            style: {
              fontSize: '13px',
              fontWeight: 900
            }
          }
        }
      },
    },
    xaxis: {
      type: 'datetime',
      categories: ['01/01/2011 GMT', '01/02/2011 GMT', '01/03/2011 GMT', '01/04/2011 GMT',
        '01/05/2011 GMT', '01/06/2011 GMT'
      ],
    },
    legend: {
      position: 'right',
      offsetY: 40
    },
    fill: {
      opacity: 1
    }
  };
  // Create a new instance of the chart with the options
  var line = new ApexCharts(document.querySelector("#"), options);

  // Render the chart
  line.render();

});




// line bar charts

var options = {
  series: [{
    name: 'PRODUCT A',
    data: [44, 55, 41, 67, 22, 43]
  }, {
    name: 'PRODUCT B',
    data: [13, 23, 20, 8, 13, 27]
  }, {
    name: 'PRODUCT C',
    data: [11, 17, 15, 15, 21, 14]
  }, {
    name: 'PRODUCT D',
    data: [21, 7, 25, 13, 22, 8]
  }],
  chart: {
    type: 'bar',
    height: 350,
    stacked: true,
    toolbar: {
      show: true
    },
    zoom: {
      enabled: true
    }
  },
  colors: ['#0E2954', '#d10024e6', '#1e1f29', '#f24c3d', '#5C8984'],
  responsive: [{
    breakpoint: 480,
    options: {
      legend: {
        position: 'bottom',
        offsetX: -10,
        offsetY: 0
      }
    }
  }],
  plotOptions: {
    bar: {
      horizontal: false,
      borderRadius: 10,
      dataLabels: {
        total: {
          enabled: true,
          style: {
            fontSize: '13px',
            fontWeight: 900
          }
        }
      }
    },
  },
  xaxis: {
    type: 'datetime',
    categories: ['01/01/2011 GMT', '01/02/2011 GMT', '01/03/2011 GMT', '01/04/2011 GMT',
      '01/05/2011 GMT', '01/06/2011 GMT'
    ],
  },
  legend: {
    position: 'right',
    offsetY: 40
  },
  fill: {
    opacity: 1
  }
};

var chart = new ApexCharts(document.querySelector("#line_bar"), options);
chart.render();



// Add click event listener to dropdown items
var dropdownItems = document.querySelectorAll('.dropdown_menu_item');

dropdownItems.forEach(function (dropdownItem) {
  dropdownItem.addEventListener('click', function () {
    // Remove 'active' class from other dropdown items
    dropdownItems.forEach(function (item) {
      if (item !== dropdownItem) {
        item.classList.remove('active');
      }
    });

    dropdownItem.classList.toggle('active');
  });
});

// Close dropdowns when clicking outside
window.addEventListener('click', function (event) {
  dropdownItems.forEach(function (dropdownItem) {
    if (!dropdownItem.contains(event.target)) {
      dropdownItem.classList.remove('active');
    }
  });
});

