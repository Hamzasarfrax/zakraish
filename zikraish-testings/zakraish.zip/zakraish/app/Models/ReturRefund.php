<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ReturRefund extends Model
{
    use HasFactory;
    protected $table ='retur_refunds';
    protected $fillable =[
        'name','email','contact'
    ];
}
