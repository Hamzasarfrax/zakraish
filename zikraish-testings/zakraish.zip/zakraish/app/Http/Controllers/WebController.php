<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ContactUs;
use App\Models\Apidata;
class WebController extends Controller
{
    public function __construct()
{
    $this->middleware('auth');
}

    public function order(){
        return view("Order");
    }
    public function index(){
        $totalusers=ContactUs::count();
        $totalproducts=ContactUs::count();
        // dd($totalusers);
        return view("welcome",compact('totalusers','totalproducts'));
    }
    public function welcome(){
        $totalusers=ContactUs::count();
        $totalproducts=ContactUs::count();
        // dd($totalusers);
        return view("welcome",compact('totalusers','totalproducts'));
    }
}
