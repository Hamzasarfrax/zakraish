<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CashOnDelivery;
use Illuminate\Support\Facades\Session;
class CashOnDeliveryController extends Controller
{
    public function  showcashorder(){
        $cashorder=CashOnDelivery::paginate(10);
        return view('CashOndelivery.mangeorder',compact('cashorder'));
    }

    public function  showupdatecashorder(Request $request){
        $cashorder=CashOnDelivery::find($request->id);
        return view('CashOndelivery.updateorder',compact('cashorder'));
    }

    public function  updatecashorder(Request $request){
        $cashorder=CashOnDelivery::find($request->id);
        $cashorder->product_id=$request->id;
        $cashorder->product_name=$request->product_name;
        $cashorder->product_price=$request->product_price;
        $cashorder->user_name=$request->user_name;
        $cashorder->user_email=$request->user_email;
        $cashorder->user_address=$request->user_address;
        $cashorder->user_contact=$request->user_contact;
        $cashorder->status=$request->status;
        // dd($cashorder);
        $cashorder->save();
        Session::flash('Sucess',"Your Order  is Ready To Deliverd  ");
        return redirect('showcashorder');
    }

    public function  deletecashorder(Request $request){
        $cashorder=CashOnDelivery::find($request->id);
        $cashorder->delete();
        Session::flash('Sucess',"Your Order  is Deleted  ");
        return redirect()->back();
    }
}
