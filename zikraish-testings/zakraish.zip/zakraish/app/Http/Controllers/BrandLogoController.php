<?php

namespace App\Http\Controllers;

use App\Models\BrandLogo;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
class BrandLogoController extends Controller
{
    public function showlogos(){
        $logo=BrandLogo::all();

        return view('Brandlogo.managelogo',compact('logo'));
    }
    public function storelogos(Request $request)
    {
        $request->validate([
            'img1' => 'required|image|mimes:jpeg,png,jpg,gif,svg',
            'img2' => 'required|image|mimes:jpeg,png,jpg,gif,svg',
        ]);

        $imageName1 = time().'.'.$request->img1->extension();
        $request->img1->move(public_path('brandlogos'), $imageName1);

        $imageName2 = time().'.'.$request->img2->extension();
        $request->img2->move(public_path('brandlogos'), $imageName2);

        $logo = new BrandLogo;
        $logo->img1 = $imageName1;
        $logo->img2 = $imageName2;
        // dd($logo);
        $logo->save();
    Session::flash('success','Your Brand Logo Is Added');
        return redirect()->back();
    }

    public function showupdatelogos(Request $request){
        $logo=BrandLogo::find($request->id);

        return view('Brandlogo.updatelogo',compact('logo'));
    }
    public function updatelogos(Request $request){
        $logo=BrandLogo::find($request->id);
        $request->validate([
            'img1' => 'required|image|mimes:jpeg,png,jpg,gif,svg',
            'img2' => 'required|image|mimes:jpeg,png,jpg,gif,svg',
        ]);

        $imageName1 = time().'.'.$request->img1->extension();
        $request->img1->move(public_path('brandlogos'), $imageName1);

        $imageName2 = time().'.'.$request->img2->extension();
        $request->img2->move(public_path('brandlogos'), $imageName2);


        $logo->img1 = $imageName1;
        $logo->img2 = $imageName2;
        $logo->save();
        Session::flash('success','Your Brand Logo Is Updated');
        return redirect('showlogos');
    }
    public function deletelogos(Request $request){
        $logo=BrandLogo::find($request->id);
        $logo->delete();
        Session::flash('success','Your Brand Logo Is Deleted');
        return redirect()->back();
    }
}
