<?php

namespace App\Http\Controllers;
use Session;
use Stripe\Stripe;
use Stripe\PaymentIntent;
use Stripe\Charge;
use App\Models\Apidata;
use App\Models\Order;

use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
  

  

  
    public function GetData()
    {
        $prod = Order::paginate(10); // Change the "10" to the desired number of items per page
        return view("Order", compact("prod"));
    }
public function CreateData(Request $req)
{


      $prod = new Order;
      $prod->email = $req->input('email');
      $prod->client_name = $req->input('client_name');
      $prod->contact = $req->input('contact');
      $prod->address = $req->input('address');
      $prod->name = $req->input('name');
      $prod->price = $req->input('price');
      $prod->description = $req->input('description');
      $prod->type = $req->input('type');
      $prod->category = $req->input('category');
      $prod->status = "active";


      if ($req->hasFile('images')) {
          $imageName = time().'.'.$req->images->extension();
          $req->images->move(public_path('images'), $imageName);
          $prod->images = $imageName; // assign the file name to the "images" field of the model
      }

    if ($req->hasFile('images2')) {
        $image2 = $req->file('images2');
        $image2_name = time() . '_2.' . $image2->getClientOriginalExtension();
        $image2->move(public_path('images'), $image2_name);
        $prod->images2 = $image2_name;
    }

    if ($req->hasFile('images3')) {
        $image3 = $req->file('images3');
        $image3_name = time() . '_3.' . $image3->getClientOriginalExtension();
        $image3->move(public_path('images'), $image3_name);
        $prod->images3 = $image3_name;
    }

    if ($req->hasFile('images4')) {
        $image4 = $req->file('images4');
        $image4_name = time() . '_4.' . $image4->getClientOriginalExtension();
        $image4->move(public_path('images'), $image4_name);
        $prod->images4 = $image4_name;
    }

    $prod->save();
    if ($prod->save()) {
        Session::flash('success', 'Product Created successfully.');
    } else {
        Session::flash('error', 'There was an error in saving the Product data.');
    }

  return  redirect()->back();

}

public function ShowUpdateProduct($id)
{
    $prod = Order::findOrFail($id);
    return view('UpdateOrder', compact("prod"));
}

public function UpdateProduct(Request $req, $id)
{
    $prod = Order::find($id);
    $prod->email = $req->input('email');
    $prod->client_name = $req->input('client_name');
    $prod->contact = $req->input('contact');
    $prod->address = $req->input('address');
    $prod->name = $req->input('name');
    $prod->price = $req->input('price');
    $prod->description = $req->input('description');
    $prod->type = $req->input('type');
    $prod->category = $req->input('category');
    $prod->status = $req->input('status');

    if ($req->hasFile('images')) {
        $imageName = time().'.'.$req->images->extension();
        $req->images->move(public_path('images'), $imageName);
        $prod->images = $imageName;
    }

    if ($req->hasFile('images2')) {
        $image2 = $req->file('images2');
        $image2_name = time() . '_2.' . $image2->getClientOriginalExtension();
        $image2->move(public_path('images'), $image2_name);
        $prod->images2 = $image2_name;
    }

    if ($req->hasFile('images3')) {
        $image3 = $req->file('images3');
        $image3_name = time() . '_3.' . $image3->getClientOriginalExtension();
        $image3->move(public_path('images'), $image3_name);
        $prod->images3 = $image3_name;
    }

    if ($req->hasFile('images4')) {
        $image4 = $req->file('images4');
        $image4_name = time() . '_4.' . $image4->getClientOriginalExtension();
        $image4->move(public_path('images'), $image4_name);
        $prod->images4 = $image4_name;
    }

    $prod->save();

    return redirect("order");
}

public function DeleteProduct($id){
     $prod = Order::find($id);
     if ($prod != null) {
         $prod->delete();
     }
     if ($prod->delete()) {
          Session::flash('success', 'Product deleted successfully.');
      } else {
          Session::flash('error', 'There was an error to Delete Product .');
      }

    return  redirect()->back();
 }



}