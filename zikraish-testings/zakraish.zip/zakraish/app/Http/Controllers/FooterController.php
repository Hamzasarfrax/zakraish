<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Footer;
use Illuminate\Support\Facades\Session;
class FooterController extends Controller
{
    //
    public function showfooter(Request $request){
        $prod = Footer::paginate(10);
        return view('Footer.managefooter', compact('prod'));
    }

    public function storefooter(Request $request){

        $prod=new Footer;
        $prod->email=$request->email;
        $prod->address=$request->address;
        $prod->contactno=$request->contactno;
        // dd($prod);
        $prod->save();
        Session::flash('Sucess',"Your Footer Details is Stored ");
        return redirect('showfooter');
    }

    public function showupdatefooter(Request $request){

        $prod=Footer::find($request->id);
        return view('Footer.updatefooter',compact('prod'));
    }
    public function updatefooter(Request $request){

        $prod=Footer::find($request->id);
        $prod->email=$request->email;
        $prod->address=$request->address;
        $prod->contactno=$request->contactno;
        // dd($prod);
        $prod->save();
        Session::flash('Sucess',"Your Footer Details is Stored ");
        return redirect('showfooter');
    }

    public function deletefooter(Request $request){

        $prod = Footer::find($request->id);
        $prod->delete();
        Session::flash('success', "Your Footer Details have been deleted.");
        return redirect('showfooter');
    }
}
