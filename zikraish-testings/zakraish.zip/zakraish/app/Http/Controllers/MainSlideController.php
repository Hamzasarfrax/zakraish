<?php

namespace App\Http\Controllers;

use App\Models\MainSlide;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
class MainSlideController extends Controller
{
    public function showslide(){
        $slide=MainSlide::paginate(10);

        return view('MainSlider.mangeslide',compact('slide'));
    }
    public function storeslide(Request $request)
    {
        $request->validate([
            'slide' => 'required|image|mimes:jpeg,png,jpg,gif,svg',
       
        ]);

        $imageName = time().'.'.$request->slide->extension();
        $request->slide->move(public_path('slides'), $imageName);

        $slide = new MainSlide;
        $slide->slide =$imageName;
        $slide->small_heading = $request->small_heading;
        $slide->large_heading = $request->large_heading;
        $slide->paragraph = $request->paragraph;
        // dd($slide);
        $slide->save();
    Session::flash('success','Your Slider Is Added');
        return redirect('showslide');
    }

    public function showupdateslide(Request $request){
        $slide=MainSlide::find($request->id);

        return view('MainSlider.updateslide',compact('slide'));
    }
    public function updateslide(Request $request){
        $slide=MainSlide::find($request->id);
        $request->validate([
            'slide' => 'required|image|mimes:jpeg,png,jpg,gif,svg',
       
        ]);

        $imageName = time().'.'.$request->slide->extension();
        $request->slide->move(public_path('slides'), $imageName);
        $slide->slide =$imageName;
        $slide->small_heading = $request->small_heading;
        $slide->large_heading = $request->large_heading;
        $slide->paragraph = $request->paragraph;
        // dd($slide);
        $slide->save();
    Session::flash('success','Your Slider Is Added');
        return redirect('showslide');
    }
    public function deletelslide(Request $request){
        $slide=MainSlide::find($request->id);
        $slide->delete();
        Session::flash('success','Your Brand Logo Is Deleted');
        return redirect()->back();
    }
}
