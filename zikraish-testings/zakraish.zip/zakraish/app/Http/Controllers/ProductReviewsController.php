<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Productreviews;
use Illuminate\Support\Facades\Session;
class ProductReviewsController extends Controller
{
    public function showprodreview(){
        $prodreview=Productreviews::paginate(10);
        return view("ProductReviews.managereview",compact('prodreview'));
    }

    public function showupdateprodreview(Request $request){
        $prodreview=Productreviews::find($request->id);

        return view('ProductReviews.updatereview',compact('prodreview'));
    }
    public function updateprodreview(Request $request){
        
        $prodreview=Productreviews::find($request->id);       
        $prodreview->client_name=$request->client_name;
        $prodreview->client_email=$request->client_email;
        $prodreview->client_message=$request->client_message;
        $prodreview->client_rating=$request->client_rating;
    // dd($prodreview);
    Session::flash('Sucess'," Review  is Updated   ");
        $prodreview->save();
        return redirect('showprodreview');
    }
    public function deleteprodreview(Request $request){
        $prodreview=Productreviews::find($request->id);
        $prodreview->delete();
        Session::flash('Sucess'," Review  is Deleted   ");
        return redirect()->back();
    }
}
