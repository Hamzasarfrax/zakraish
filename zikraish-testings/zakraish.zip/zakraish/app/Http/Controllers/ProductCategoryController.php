<?php

namespace App\Http\Controllers;


use App\Models\ProductCategory;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class ProductCategoryController extends Controller
{
    public function storecategory(Request $request)
    {
        $existingCategory = ProductCategory::where('category_name', $request->category_name)->first();

        if ($existingCategory) {
            Session::flash('error', 'Category already exists.');
        } else {
            $cat = new ProductCategory;
            $cat->category_name = $request->category_name;
            $cat->save();
            Session::flash('success', 'Your Category Is Added');
        }

        return redirect()->back();
    }


    public function showcategory()
    {
        $cat =ProductCategory::paginate(10);
        return view('ProductCategory.managecategory', ['cat' => $cat]);
    }

    public function showupdatecategory(Request $request)
    {
        $cats = DB::select('SELECT * FROM product_categories WHERE id = ?', [$request->id]);

        if (!empty($cats)) {
            $cat = $cats[0]; // Retrieve the first object from the array
            return view('ProductCategory.updatecategory', compact('cat'));
        } else {
            // Handle the case when no category is found with the given id
            return redirect()->back()->with('error', 'Category not found.');
        }
    }


    public function updatecategory(Request $request)
    {
        $cat =ProductCategory::find($request->id);
        $cat->category_name = $request->category_name;
        $cat->save();
        Session::flash('success', 'Your Categgory Is Updated');
        return redirect('managecategory');
    }

    public function deletecategory(Request $request)
    {
        $cat =ProductCategory::find($request->id);

        $cat->delete();
        Session::flash('success', 'Your Categgory Is Deleted');
        return redirect('showcategory');
    }
}
