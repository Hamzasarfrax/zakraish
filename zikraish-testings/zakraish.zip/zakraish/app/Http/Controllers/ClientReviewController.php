<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ClientReview;
use Illuminate\Support\Facades\Session;
class ClientReviewController extends Controller
{
    public function showclientreview(){
        $clientreview=ClientReview::paginate(10);
        return view("ClientReviews.managereview",compact('clientreview'));
    }

    public function showupdateclientreview(Request $request){
        $clientreview=ClientReview::find($request->id);

        return view('ClientReviews.updatereview',compact('clientreview'));
    }
    public function updateclientreview(Request $request){
        $request->validate([
            'client_image' => 'required|image|mimes:jpeg,png,jpg,gif,svg',

        ]);

        $imageName = time().'.'.$request->client_image->extension();
        $request->client_image->move(public_path('client_reviews'), $imageName);
        $clientreview=ClientReview::find($request->id);
        $clientreview->client_image=$imageName;
        $clientreview->client_name=$request->client_name;
        $clientreview->client_email=$request->client_email;
        $clientreview->client_message=$request->client_message;
        $clientreview->client_reviews=$request->client_reviews;
        $clientreview->client_description=$request->client_description;
        Session::flash('Sucess',"Your Review  is Save   ");
        $clientreview->save();
        return redirect('showclientreview');
    }
    public function deleteclientreview(Request $request){
        $clientreview=ClientReview::find($request->id);
        Session::flash('Sucess',"Your Review  is Deleted   ");
        $clientreview->delete();
        return redirect()->back();
    }
}
