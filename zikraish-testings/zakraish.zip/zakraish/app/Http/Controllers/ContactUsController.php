<?php

namespace App\Http\Controllers;

use App\Models\ContactUs;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
class ContactUsController extends Controller
{
  
    public function showcontact(){
        $ContactUs=ContactUs::paginate(10);
      
        return view('Contactus.managecontact',compact('ContactUs'));
            }
public function deleteContacts(Request $request){
$ContactUs=ContactUs::find($request->id);
$ContactUs->delete();
Session::flash('Sucess',"Your Data is Deleted  ");
return redirect()->back();
    }
}
