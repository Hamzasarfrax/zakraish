<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Apidata;
use App\Models\ProductCategory;
use Illuminate\Support\Facades\Session;

class ProductController extends Controller
{

    // public function __construct()
    // {
    //     $this->middleware('auth');
    // }
    public function GetData()
    {
        $prod = Apidata::paginate(10);
        $cat=ProductCategory::all();
        // Change the "10" to the desired number of items per page
        return view("Product.Product", compact("prod",'cat'));
    }
public function CreateData(Request $req)
{


      $prod = new Apidata;
      $prod->name = $req->input('name');
      $prod->product_type = $req->input('product_type');
      $prod->old_price = $req->input('old_price');
      $prod->ingredients = $req->input('ingredients');
      $prod->ratings = $req->input('rating');
      $prod->price = $req->input('price');
      $prod->description = $req->input('description');
      $prod->type = $req->input('type');
      $prod->category = $req->input('category');
      $prod->status = "active";


      if ($req->hasFile('images')) {
          $imageName = time().'.'.$req->images->extension();
          $req->images->move(public_path('images'), $imageName);
          $prod->images = $imageName; // assign the file name to the "images" field of the model
      }

    if ($req->hasFile('images2')) {
        $image2 = $req->file('images2');
        $image2_name = time() . '_2.' . $image2->getClientOriginalExtension();
        $image2->move(public_path('images'), $image2_name);
        $prod->images2 = $image2_name;
    }

    if ($req->hasFile('images3')) {
        $image3 = $req->file('images3');
        $image3_name = time() . '_3.' . $image3->getClientOriginalExtension();
        $image3->move(public_path('images'), $image3_name);
        $prod->images3 = $image3_name;
    }

    if ($req->hasFile('images4')) {
        $image4 = $req->file('images4');
        $image4_name = time() . '_4.' . $image4->getClientOriginalExtension();
        $image4->move(public_path('images'), $image4_name);
        $prod->images4 = $image4_name;
    }

    $prod->save();
    if ($prod->save()) {
        Session::flash('success', 'Product Created successfully.');
    } else {
        Session::flash('error', 'There was an error in saving the Product data.');
    }

  return  redirect("product");

}

public function ShowUpdateProduct($id)
{
    $prod = Apidata::findOrFail($id);
    $cat=ProductCategory::all();
    return view('Product.Updateproduct', compact("prod",'cat'));
}

public function UpdateProduct(Request $req, $id)
{
    $prod = Apidata::find($id);
    $prod->name = $req->input('name');
    $prod->name = $req->input('product_type');
    $prod->name = $req->input('old_price');
    $prod->name = $req->input('ingredients');
    $prod->name = $req->input('stock');
    $prod->name = $req->input('rating');
    $prod->price = $req->input('price');
    $prod->description = $req->input('description');
    $prod->type = $req->input('type');
    $prod->category = $req->input('category');
    $prod->status = $req->input('status');

    if ($req->hasFile('images')) {
        $imageName = time().'.'.$req->images->extension();
        $req->images->move(public_path('images'), $imageName);
        $prod->images = $imageName;
    }

    if ($req->hasFile('images2')) {
        $image2 = $req->file('images2');
        $image2_name = time() . '_2.' . $image2->getClientOriginalExtension();
        $image2->move(public_path('images'), $image2_name);
        $prod->images2 = $image2_name;
    }

    if ($req->hasFile('images3')) {
        $image3 = $req->file('images3');
        $image3_name = time() . '_3.' . $image3->getClientOriginalExtension();
        $image3->move(public_path('images'), $image3_name);
        $prod->images3 = $image3_name;
    }

    if ($req->hasFile('images4')) {
        $image4 = $req->file('images4');
        $image4_name = time() . '_4.' . $image4->getClientOriginalExtension();
        $image4->move(public_path('images'), $image4_name);
        $prod->images4 = $image4_name;
    }

    $prod->save();

    return redirect("product")->with('success', 'Product Updated successfully!');
}

public function DeleteProduct($id){
     $prod = Apidata::find($id);
     if ($prod != null) {
         $prod->delete();
     }
     if ($prod->delete()) {
          Session::flash('success', 'Product deleted successfully.');
      } else {
          Session::flash('error', 'There was an error in saving the Product data.');
      }

    return  redirect()->back();
 }




}
