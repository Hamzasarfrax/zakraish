<?php

namespace App\Http\Controllers;

use App\Models\FooterLinks;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
class FooterLinksController extends Controller
{
public function showsocials(){
    $footersocial=FooterLinks::paginate(10);
    return view('FooterSocials.managesocials',compact('footersocial'));
}
public function storesocials(Request $request)
{
    $footerSocialCount = FooterLinks::count();

    if ($footerSocialCount >= 4) {
        // If the count of existing records is already 5 or more, you can handle it accordingly.
        // For example, you can display an error message or redirect back with a flash message.
        return redirect()->back()->with('error', 'Maximum limit reached for storing social links.');
    }

    $footerSocial = new FooterLinks;
    $footerSocial->social_name = $request->social_name;
    $footerSocial->social_link = $request->social_link;
    $footerSocial->save();
    Session::flash('success', 'Social Links Added successfully.');
    return redirect()->back();
}

public function showupdatesocials(Request $request){
    $footersocial=FooterLinks::find($request->id);
    return view('FooterSocials.updatesocials',compact('footersocial'));
}
public function updatesocials(Request $request){
    $footersocial =FooterLinks::find($request->id);
    $footersocial->social_name = $request->social_name;
    $footersocial->social_link = $request->social_link;
    $footersocial->save();
    Session::flash('success', 'Social Links Updated successfully.');
    return redirect('showsocials');
}
public function deletesocials(Request $request){
    $footersocial=FooterLinks::find($request->id);
    $footersocial->delete();
    Session::flash('success', 'Social Links Deleted successfully.');
    return redirect()->back();
}
}
