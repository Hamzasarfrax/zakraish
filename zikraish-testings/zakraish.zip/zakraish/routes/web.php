<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ProductCategoryController;
use App\Http\Controllers\WebController;
use App\Http\Controllers\StripeController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\FooterController;
use App\Http\Controllers\FooterLinksController;
use App\Http\Controllers\BrandLogoController;
use App\Http\Controllers\MainSlideController;
use App\Http\Controllers\ContactUsController;
use App\Http\Controllers\CashOnDeliveryController;
use App\Http\Controllers\ClientReviewController;
use App\Http\Controllers\ProductReviewsController;









Route::fallback(function () {
    // Your 404 page logic or view here
    return view('errors.404');
});



Route::get('/',[WebController::class,"welcome"]);
Route::get('/order',[WebController::class,"order"]);
Route::get('/product',[WebController::class,"index"]);
// product
Route::get('/product',[ProductController::class,"GetData"]);
Route::put('/Updateproduct/{id}', [ProductController::class, 'UpdateProduct']);

Route::get('/Updateproduct/{id}',[ProductController::class,"ShowUpdateProduct"]);

Route::post('users',[ProductController::class,"CreateData"])->name("users.store");

Route::delete('users/{id}',[ProductController::class,"DeleteProduct"])->name("users.delete");
Route::get('stripe', [StripeController::class, 'stripe']);
Route::post('/stripe', [StripeController::class, 'stripePost'])->name('stripe.post');

// order
Route::get('order',[OrderController::class,"GetData"]);
Route::post('CreateData',[OrderController::class,"CreateData"]);
Route::get('UpdateOrder/{id}',[OrderController::class,"ShowUpdateProduct"]);
Route::put('UpdateOrder/{id}',[OrderController::class,"UpdateProduct"]);
Route::delete('order/{id}',[OrderController::class,"DeleteProduct"])->name("order.delete");

Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
Route::post('/login', [LoginController::class, 'login'])->name('login.post');
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');

Route::get('/register', [UserController::class, 'showRegistrationForm'])->name('register');
Route::post('/register', [UserController::class, 'register'])->name('register.post');



Route::get('/clear-cache', function () {
    Artisan::call('cache:clear');
    Artisan::call('view:clear');
    Artisan::call('cache:clear');
    Artisan::call('route:clear');
    Artisan::call('optimize');
    return 'Application cache cleared';
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

// this is crud route for MainSlideController
Route::get('/contactus', [ContactUsController::class, 'showcontact'])->name('contactus');
Route::delete('/deleteContacts/{id}', [ContactUsController::class, 'deleteContacts'])->name('deleteContacts');

// this is crud route for MainSlideController
Route::get('/showslide', [MainSlideController::class, 'showslide'])->name('showslide');
Route::post('/storeslide', [MainSlideController::class, 'storeslide'])->name('storeslide');
Route::get('/showupdateslide/{id}', [MainSlideController::class, 'showupdateslide'])->name('showupdateslide');
Route::put('/updateslide/{id}', [MainSlideController::class, 'updateslide'])->name('updateslide');
Route::delete('/deletelslide/{id}', [MainSlideController::class, 'deletelslide'])->name('deletelslide');

// this is crud route for ProductCategoryController
Route::get('/showlogos', [BrandLogoController::class, 'showlogos'])->name('showlogos');
Route::post('/storelogos', [BrandLogoController::class, 'storelogos'])->name('storelogos');
Route::get('/showupdatelogos/{id}', [BrandLogoController::class, 'showupdatelogos'])->name('showupdatelogos');
Route::put('/updatelogos/{id}', [BrandLogoController::class, 'updatelogos'])->name('updatelogos');
Route::delete('/deletelogos/{id}', [BrandLogoController::class, 'deletelogos'])->name('deletelogos');

// this is crud route for FooterLinksController
Route::get('/showsocials', [FooterLinksController::class, 'showsocials'])->name('showsocials');
Route::post('/storesocials', [FooterLinksController::class, 'storesocials'])->name('storesocials');
Route::get('/showupdatesocials/{id}', [FooterLinksController::class, 'showupdatesocials'])->name('showupdatesocials');
Route::put('/updatesocials/{id}', [FooterLinksController::class, 'updatesocials'])->name('updatesocials');
Route::delete('/deletesocials/{id}', [FooterLinksController::class, 'deletesocials'])->name('deletesocials');

// this is crud route for ProductCategoryController
Route::get('/showcategory', [ProductCategoryController::class, 'showcategory'])->name('showcategory');
Route::post('/storecategory', [ProductCategoryController::class, 'storecategory'])->name('storecategory');
Route::get('/showupdatecategory/{id}', [ProductCategoryController::class, 'showupdatecategory'])->name('showupdatecategory');
Route::put('/updatecategory/{id}', [ProductCategoryController::class, 'updatecategory'])->name('updatecategory');
Route::delete('/deletecategory/{id}', [ProductCategoryController::class, 'deletecategory'])->name('deletecategory');

// this is crud route for footer

Route::get('/showfooter', [FooterController::class, 'showfooter'])->name('showfooter');
Route::post('/storefooter', [FooterController::class, 'storefooter'])->name('storefooter');
Route::get('/updatefooter/{id}', [FooterController::class, 'showupdatefooter'])->name('updatefooter');
Route::put('/updatefooters/{id}', [FooterController::class, 'updatefooter'])->name('updatefooters');
Route::delete('/deletefooter/{id}', [FooterController::class, 'deletefooter'])->name('deletefooter');


// this is order routes 

// this is crud route for CashOnDeliveryController
Route::get('/showcashorder', [CashOnDeliveryController::class, 'showcashorder'])->name('showcashorder');
Route::get('/showupdatecashorder/{id}', [CashOnDeliveryController::class, 'showupdatecashorder'])->name('showupdatecashorder');
Route::put('/updatecashorder/{id}', [CashOnDeliveryController::class, 'updatecashorder'])->name('updatecashorder');
Route::delete('/deletecashorder/{id}', [CashOnDeliveryController::class, 'deletecashorder'])->name('deletecashorder');


// this is crud route for ClientReviewController
Route::get('/showclientreview', [ClientReviewController::class, 'showclientreview'])->name('showclientreview');
Route::get('/showupdateclientreview/{id}', [ClientReviewController::class, 'showupdateclientreview'])->name('showupdateclientreview');
Route::put('/updateclientreview/{id}', [ClientReviewController::class, 'updateclientreview'])->name('updateclientreview');
Route::delete('/deleteclientreview/{id}', [ClientReviewController::class, 'deleteclientreview'])->name('deleteclientreview');

// this is crud route for ProductReviewsController
Route::get('/showprodreview', [ProductReviewsController::class, 'showprodreview'])->name('showprodreview');
Route::get('/showupdateprodreview/{id}', [ProductReviewsController::class, 'showupdateprodreview'])->name('showupdateprodreview');
Route::put('/updateprodreview/{id}', [ProductReviewsController::class, 'updateprodreview'])->name('updateprodreview');
Route::delete('/deleteprodreview/{id}', [ProductReviewsController::class, 'deleteprodreview'])->name('deleteprodreview');