@extends("Layout.App")
@section("content")

<main>
    <div class="wrapper">
      <div class="wrapper_content">
        <div class="container-fluid">

          <div class="top_card_details">
            <div class="row">
              <div class="col-md-4">
<div class="card___wrap one">
  <div class="card_body">
  <div class="details">
    <div class="top_content">
      <div class="card_icon">
        <i class="fa-solid fa-user"></i>
      </div>
      <div class="card_title">
total user's
      </div>
    </div>
    <div class="bottom_content">
      <h1>
          {{ $totalusers }}
      </h1>
    </div>
  </div>
  </div>
</div>
              </div>
              <div class="col-md-4">
                <div class="card___wrap two">
                  <div class="card_body">
                  <div class="details">
                    <div class="top_content">
                      <div class="card_icon">
                        <i class="fa-solid fa-box"></i>
                      </div>
                      <div class="card_title">
                total product's
                      </div>
                    </div>
                    <div class="bottom_content">
                      <h1>
                          {{ $totalproducts }}
                      </h1>
                    </div>
                  </div>
                  </div>
                </div>
              </div>

              <div class="col-md-4">
                <div class="card___wrap three">
                  <div class="card_body">
                  <div class="details">
                    <div class="top_content">
                      <div class="card_icon">
                        <i class="fa-solid fa-chart-simple"></i>
                      </div>
                      <div class="card_title">
                total order's
                      </div>
                    </div>
                    <div class="bottom_content">
                      <h1>
                          100234
                      </h1>
                    </div>
                  </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
       <div class="row">


        <div class="col-md-6">
        <div class="card-100">
          <div class="card_wrap">
            <div class="card_body">
              <div>
                <div id="chart">
                </div>
              </div>
            </div>
          </div>
        </div>
        </div>

        <div class="col-md-6">
        <div class="card-100">
          <div class="card_wrap">
            <div class="card_body">
              <div>
                <div id="pie">
                </div>
              </div>
            </div>
          </div>
        </div>
        </div>

      <div class="col-md-12">
        <div class="card-100 mt-5 mb-5">
          <div class="card_wrap">
            <div class="card_body">
              <div class="" id="line_bar"></div>
            </div>
          </div>
        </div>
      </div>
       </div>
        </div>
      </div>
    </div>
    </main>
@endsection
