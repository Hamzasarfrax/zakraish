@extends('Layout.App')
@section('content')
    <main>
        <div class="wrapper">
            <div class="wrapper_content">
                <div class="container-fluid">
                    <div class="heading_main">
                        <h1>
                            Update Zakriaish Footer
                        </h1>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="card_wrap">
                                <div class="card_body">
                                    <form action="{{ url('/updatelogos/' . $logo->id) }}" method="POST" enctype="multipart/form-data">


                                        @method('PUT')
                                        @csrf
                                        <input type="hidden" name="id" value="{{ $logo->id }}">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-check">
                                                    <label class="form-check-label">
                                                        brand image (1)
                                                    </label>
                                                    <input type="file" name="img1" class="form-control w-100 "
                                                        value="">
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-check">
                                                    <label class="form-check-label">
                                                        brand image (2)
                                                    </label>
                                                    <input type="file" name="img2" class="form-control w-100 "
                                                        value="">
                                                </div>
                                            </div>

                                            <div class="form-check mt-5 mb-5">
                                                <button type="submit" class="btn btn_main_big btn_bg">
                                                    Submit
                                                </button>
                                            </div>
                                        </div>





                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>


                    {{-- container_end --}}
                </div>
            </div>
        </div>
    </main>
@endsection
