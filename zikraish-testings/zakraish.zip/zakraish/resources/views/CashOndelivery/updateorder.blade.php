@extends('Layout.App')
@section('content')
    <main>
        <div class="wrapper">
            <div class="wrapper_content">
                <div class="container-fluid">
                    <div class="heading_main">
                        <h1>
                            Update Zakriaish Order's
                        </h1>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="card_wrap">
                                <div class="card_body">
                                    <form action="{{ url('/updatecashorder/' . $cashorder->id) }}" method="POST"
                                    >


                                        @method('PUT')
                                        @csrf
                                        <input type="hidden" name="id" value="{{$cashorder->id}}">
                                        <input type="hidden" name="product_id" value="{{$cashorder->id}}">
                                        <div class="row">
                                             <div class="col-md-4">
                                                <div class="form-check">
                                                   <label class="form-check-label">
                                                       product name
                                                   </label>
                                                   <input type="text" name="product_name" class="form-control w-100 "
                                                      value="{{ $cashorder->product_name }}">
                                                </div>
                                             </div>
                                             <div class="col-md-4">
                                                  <div class="form-check">
                                                     <label class="form-check-label">
                                                         product price
                                                     </label>
                                                     <input type="text" name="product_price" class="form-control w-100 "
                                                        value="{{ $cashorder->product_price }}">
                                                  </div>
                                               </div>
                                               <div class="col-md-4">
                                                  <div class="form-check">
                                                     <label class="form-check-label">
                                                       user name
                                                     </label>
                                                     <input type="text" name="user_name" class="form-control w-100 "
                                                        value="{{ $cashorder->user_name }}">
                                                  </div>
                                               </div>
                                               <div class="col-md-6">
                                                  <div class="form-check">
                                                     <label class="form-check-label">
                                                       user email
                                                     </label>
                                                     <input type="text" name="user_email" class="form-control w-100 "
                                                        value="{{ $cashorder->user_email }}">
                                                  </div>
                                               </div>
                                               <div class="col-md-6">
                                                  <div class="form-check">
                                                     <label class="form-check-label">
                                                       user address
                                                     </label>
                                                     <input type="text" name="user_address" class="form-control w-100 "
                                                        value="{{ $cashorder->user_address }}">
                                                  </div>
                                               </div>
                                             <div class="col-md-6">
                                                  <div class="form-check">
                                                     <label class="form-check-label">
                                                       user_ ontact
                                                     </label>
                                                     <input type="text" name="user_contact" class="form-control w-100 "
                                                        value="{{$cashorder->user_contact }}">
                                                  </div>
                                               </div>
                 
                                               <div class="col-md-6">
                                                  <div class="form-check">
                                                     <label class="form-check-label">
                                                       status  ({{$cashorder->status }})
                                                     </label>
                                                     <select class="form-select form-control" aria-label="Default select example" name="status">
                                                      
                                                       <option value="delivered" selected>delivered</option>
                                                       <option value="pending">pending</option>
                                               
                                                     </select>
                                                  </div>
                                               </div>
                 
               
                                             <div class="form-check mt-5 mb-5">
                                                <button type="submit" class="btn btn_main_big btn_bg">
                                                Submit
                                                </button>
                                             </div>
                                          </div>





                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>


                    {{-- container_end --}}
                </div>
            </div>
        </div>
    </main>
@endsection
