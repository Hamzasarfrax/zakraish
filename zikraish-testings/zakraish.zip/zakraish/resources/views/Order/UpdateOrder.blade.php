

@extends("Layout.App")
@section("content")
<main>
    <div class="wrapper">
      <div class="wrapper_content">
        <div class="container-fluid">
            <div class="heading_main">
                <h1>
                  Update Zakriaish product Order
                </h1>
            </div>
       <div class="row">
       <div class="col-12">
           <div class="card_wrap">
            <div class="card_body">
                <form action="{{ url('/UpdateOrder/'.$prod->id) }}" method="POST" enctype="multipart/form-data">


                    @method("PUT")
                    @csrf
<div class="row">

     <div class="col-md-6">
          <input type="hidden" name="id" value="1">
  
          <div class="form-check">
              <label class="form-check-label">
  
               Customer Name
              </label>
              <input type="text" name="client_name" class="form-control w-100 " value="{{$prod->client_name}}">
          </div>
      </div>

      <div class="col-md-6">
      
  
          <div class="form-check">
              <label class="form-check-label">
  
                  contact Customer
              </label>
              <input type="text" name="contact" class="form-control w-100 " value="{{$prod->contact}}">
          </div>
      </div>

      <div class="col-md-6">
    
  
          <div class="form-check">
              <label class="form-check-label">
  
                  email Customer
              </label>
              <input type="text" name="email" class="form-control w-100 " value="{{$prod->email}}">
          </div>
      </div>

      <div class="col-md-6">
        
  
          <div class="form-check">
              <label class="form-check-label">
  
                  address Customer
              </label>
              <input type="text" name="address" class="form-control w-100 " value="{{$prod->address}}">
          </div>
      </div>

    <div class="col-md-6">
        <input type="hidden" name="product_id" value="1">

        <div class="form-check">
            <label class="form-check-label">

                Name
            </label>
            <input type="text" name="name" class="form-control w-100 " value="{{$prod->name}}">
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-check">
            <label class="form-check-label">

                Description
            </label>
            <input type="text" name="description" class="form-control w-100 " value="{{$prod->description}}">
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-check">
            <label class="form-check-label">

                Price
            </label>
            <input type="number" name="price" class="form-control w-100 " value="{{$prod->price}}">
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-check">
            <label class="form-check-label">

                Category
            </label>
            <input type="text" name="category" class="form-control w-100 " value="{{$prod->category}}">
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-check">
            <label class="form-check-label">

                Type
            </label>
            <input type="text" name="type" class="form-control w-100 " value="{{$prod->category}}">
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-check">
            <label class="form-check-label">

                status

            </label>
        <select name="status" class="form-control form-selec custom-control" id="" value="{{$prod->category}}">
            <option value="Active" selected>Active</option>
            <option value="InActive">InActive</option>
        </select>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-check">
            <label class="form-check-label">
                media
            </label>
            <input type="file" name="images" class="form-control w-100 ">

        </div>
    </div>
    <div class="col-md-6">
        <div class="form-check">
            <label class="form-check-label">
                media
            </label>
            <input type="file" name="images2" class="form-control w-100 ">

        </div>
    </div>

    <div class="col-md-6">
        <div class="form-check">
            <label class="form-check-label">
                media
            </label>
            <input type="file" name="images3" class="form-control w-100 ">

        </div>
    </div>
    <div class="col-md-6">
        <div class="form-check">
            <label class="form-check-label">
                media
            </label>
            <input type="file" name="images4" class="form-control w-100 ">

        </div>
    </div>
    <div class="form-check mt-5 mb-5">
        <button type="submit" class="btn btn_main_big btn_bg">
            Submit
        </button>
    </div>
</div>





                </form>

            </div>
           </div>
       </div>
       </div>


       {{-- container_end --}}
        </div>
      </div>
    </div>
    </main>
@endsection
