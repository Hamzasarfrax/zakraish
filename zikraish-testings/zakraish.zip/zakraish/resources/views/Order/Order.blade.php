@extends('Layout.App')
@section('content')
    <main>




        <div class="wrapper">

            <div class="wrapper_content">
                <div class="container-fluid">
                    @if (Session::has('success'))
                        <div class="alert alert-success">
                            {{ Session::get('success') }}
                        </div>
                    @endif

                    @if (Session::has('error'))
                        <div class="alert alert-danger">
                            {{ Session::get('error') }}
                        </div>
                    @endif

                    <div class="heading_main">
                        <h1>
                            Zakriaish order's
                        </h1>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="card_wrap">
                                <div class="card_header">
                                    <div class="btn_add">
                                        <button type="button" class="btn btn_add" data-bs-toggle="modal"
                                            data-bs-target="#staticBackdrop">
                                            <i class="fa-solid fa-plus"></i>
                                        </button>

                                    </div>
                                </div>
                                <div class="card_body">
                                    <div class="table-responsive">
                                        <table class="table" id="example">
                                            <thead>
                                                <tr>
                                                    <th scope="col">serial no</th>
                                                    <th scope="col">name</th>
                                                    <th scope="col">price</th>
                                                    <th scope="col">description</th>
                                                    <th scope="col">category</th>
                                                    <th scope="col">status</th>
                                                    <th scope="col">images</th>
                                                    <th scope="col">action</th>
                                                    <th scope="col">type</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach ($prod as $key => $item)
                                                    <tr>
                                                        <th scope="row">{{ $key + 1 }} </th>
                                                        <td>{{ $item->name }}</td>
                                                        <td>{{ $item->price }}</td>
                                                        <td>
                                                            <div class="slice_description">
                                                                <span>
                                                                    {{ $item->description }}
                                                                </span>
                                                            </div>
                                                        </td>

                                                        <td>{{ $item->category }}</td>
                                                        <td>{{ $item->status }}</td>
                                                        <td>
                                                            <img src="{{ asset('images/' . $item->images) }}"
                                                                class="img-fluid">
                                                        </td>
                                                        <td>{{ $item->type }}</td>
                                                        <td>
                                                            <div class="actions">
                                                                <a class="btn btn_edit"
                                                                    href="/UpdateOrder/{{ $item->id }}"><i
                                                                        class="fa-solid fa-pen-to-square"></i></a>


                                                                <button type="text" class="btn btn_del open_sweet_alert "
                                                                    href=""><i class="fa-solid fa-trash"></i>
                                                                </button>


                                                            </div>
                                                            <div class="box_alert_for_delete">

                                                                <div class="box_model">
                                                                    <div class="flexis_btn">
                                                                        <form
                                                                            action="{{ route('order.delete', $item->id) }}"
                                                                            method="post">
                                                                            @csrf
                                                                            @method('delete')
                                                                            <button type="submit" class="btn btn_del ok"
                                                                                href="">Yes Delete It </button>
                                                                        </form>
                                                                        <button type="text" class="btn btn_del remove"
                                                                            href="">Not Delete It </button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        </td>
                                                    </tr>
                                                @endforeach


                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="pagination">
                                    {!! $prod->links() !!}
                                </div>
                            </div>
                        </div>
                    </div>


                    {{-- container_end --}}
                </div>
            </div>
        </div>
    </main>
@endsection
