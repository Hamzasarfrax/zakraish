@extends('Layout.App')
@section('content')
    <main>
        <div class="wrapper">
            <div class="wrapper_content">
                <div class="container-fluid">
                    <div class="heading_main">
                        <h1>
                            Update Zakriaish Footer
                        </h1>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="card_wrap">
                                <div class="card_body">
                                    <form action="{{ url('/updatesocials/' . $footersocial->id) }}" method="POST"
                                    >


                                        @method('PUT')
                                        @csrf
                                        <input type="hidden" name="id" value="{{$footersocial->id}}">
                                        <div class="row">
                                            <div class="col-md-12">


                                                <div class="form-check">
                                                    <label class="form-check-label">

                                                        social name
                                                    </label>
                                                    <input type="text" name="social_name" class="form-control w-100 "
                                                        value="{{$footersocial->social_name}}">
                                                </div>
                                            </div>

                                            <div class="col-md-12">


                                                <div class="form-check">
                                                    <label class="form-check-label">

                                                        social link
                                                    </label>
                                                    <input type="text" name="social_link" class="form-control w-100 "
                                                        value="{{$footersocial->social_link}}">
                                                </div>
                                            </div>


                                            <div class="form-check mt-5 mb-5">
                                                <button type="submit" class="btn btn_main_big btn_bg">
                                                    Submit
                                                </button>
                                            </div>

                                        </div>





                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>


                    {{-- container_end --}}
                </div>
            </div>
        </div>
    </main>
@endsection
