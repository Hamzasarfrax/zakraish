@extends('Layout.App')
@section('content')
    <main>
        <div class="wrapper">
            <div class="wrapper_content">
                <div class="container-fluid">
                    <div class="heading_main">
                        <h1>
                            Update Zakriaish Order's
                        </h1>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="card_wrap">
                                <div class="card_body">
                                    <form action="{{ url('/updateclientreview/' . $clientreview->id) }}" method="POST"
                                         enctype="multipart/form-data" >


                                        @method('PUT')
                                        @csrf
                                        <input type="hidden" name="id" value="{{$clientreview->id}}">
                                        
                                        <div class="row">
                                             <div class="col-md-4">
                                                <div class="form-check">
                                                   <label class="form-check-label">
                                                       client name
                                                   </label>
                                                   <input type="text" name="client_name" class="form-control w-100 "
                                                      value="{{ $clientreview->client_name }}">
                                                </div>
                                             </div>
                                             <div class="col-md-4">
                                                  <div class="form-check">
                                                     <label class="form-check-label">
                                                       client email
                                                     </label>
                                                     <input type="text" name="client_email" class="form-control w-100 "
                                                        value="{{ $clientreview->client_email }}">
                                                  </div>
                                               </div>
                                               <div class="col-md-4">
                                                  <div class="form-check">
                                                     <label class="form-check-label">
                                                       client image
                                                     </label>
                                                     <input type="file" name="client_image" class="form-control w-100 "
                                                        value="{{ $clientreview->client_image }}">
                                                  </div>
                                               </div>
                                               <div class="col-md-6">
                                                  <div class="form-check">
                                                     <label class="form-check-label">
                                                       client message
                                                     </label>
                                                     <input type="text" name="client_message" class="form-control w-100 "
                                                        value="{{ $clientreview->client_message }}">
                                                  </div>
                                               </div>
                                               <div class="col-md-6">
                                                  <div class="form-check">
                                                     <label class="form-check-label">
                                                       client description
                                                     </label>
                                                     <input type="text" name="client_description" class="form-control w-100 "
                                                        value="{{ $clientreview->client_description }}">
                                                  </div>
                                               </div>
                                            
                 
                                               <div class="col-md-6">
                                                  <div class="form-check">
                                                     <label class="form-check-label">
                                                       status  ({{$clientreview->client_reviews }})
                                                     </label>
                                                     <select class="form-select form-control" aria-label="Default select example" name="client_reviews">
                                                      
                                                       <option value="1">one</option>
                                                       <option value="2">two</option>
                                                       <option value="3">three</option>
                                                       <option value="4">four</option>
                                                       <option value="5">five</option>
                                               
                                                     </select>
                                                  </div>
                                               </div>
                 
               
                                             <div class="form-check mt-5 mb-5">
                                                <button type="submit" class="btn btn_main_big btn_bg">
                                                Submit
                                                </button>
                                             </div>
                                          </div>





                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>


                    {{-- container_end --}}
                </div>
            </div>
        </div>
    </main>
@endsection
