@extends("Layout.App")
@section("content")
<main>


    <div class="wrapper">

      <div class="wrapper_content">
        <div class="container-fluid">
            @if (Session::has('success'))

            <div id="toast-container">
                <div class="toast">
                    <div class="toast-icon">
                        <i class="fas fa-check"></i>
                    </div>
                    <div class="toast-message">
                        {{ Session::get('success') }}
                    </div>
                </div>
            </div>

            @endif
            @if (Session::has('error'))

            <div id="toast-container">
                <div class="toast">
                    <div class="toast-icon">
                        <i class="fas fa-check"></i>
                    </div>
                    <div class="toast-message">
                        {{ Session::get('error') }}
                    </div>
                </div>
            </div>
            @endif

            <div class="heading_main">
                <h1>
                    Zakriaish product's
                </h1>
            </div>
       <div class="row">
       <div class="col-12">
            <div class="card_wrap">
                <div class="card_header">
                    <div class="btn_add">
                        <button type="button" class="btn btn_add" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                            <i class="fa-solid fa-plus"></i>
                          </button>

                    </div>
                </div>
                 <div class="card_body">
                    <div class="table-responsive">
                        <table class="table" id="example">
                            <thead>
                              <tr>
                                <th scope="col">serial no</th>
                                <th scope="col">name</th>
                                <th scope="col">price</th>
                                <th scope="col">old price</th>
                                <th scope="col">ingredients</th>
                                <th scope="col">ratings</th>
                                <th scope="col">description</th>
                                <th scope="col">category</th>
                                <th scope="col">status</th>
                                <th scope="col">images</th>
                                <th scope="col">type</th>
                                <th scope="col">created_at</th>
                                <th scope="col">updated_at</th>

                                <th scope="col">action</th>

                              </tr>
                            </thead>
                            <tbody>
                             @foreach ($prod as $key => $item)
                             <tr>
                                 <th scope="row">{{$key+1}} </th>
                                 <td>{{$item->name}}</td>
                                 <td>{{$item->price}}</td>
                                 <td>{{$item->old_price}}</td>
                                 <td>{{$item->ingredients}}</td>
                                 <td>{{$item->ratings}}</td>
                                 <td>{{ Str::limit($item->description, 50) }}
                                </td>
                                 <td>{{$item->category}}</td>
                                 <td>{{$item->status}}</td>
                               <td>


                                 <div type="button" class="show_images" data-bs-toggle="modal" data-bs-target="#staticBackdrop{{ $item->id }}">

                                    <div type="button" class="" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="{{ $item->name }} --  images">
                                        <img src="{{ asset('images/' . $item->images) }}" class="img-fluid">
                                      </div>

                                  </div>

                                  <!-- Modal -->
                                  <div class="modal fade" id="staticBackdrop{{ $item->id }}" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                      <div class="modal-content">
                                        <div class="modal-header">
                                          <h1 class="modal-title fs-5" id="staticBackdropLabel">{{$item->name}} Images</h1>
                                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">


                                            <div class="Product_slid">
                                                <div class="swiper mySwiper">
                                                    <div class="swiper-wrapper">

                                                      <div class="swiper-slide">
                                                        <img src="{{ asset('images/' . $item->images) }}" class="d-block w-100" alt="{{ $item->name }}">
                                                      </div>
                                                      <div class="swiper-slide">
                                                        <img src="{{ asset('images/' . $item->images2) }}" class="d-block w-100" alt="{{ $item->name }}">
                                                      </div>
                                                      <div class="swiper-slide">
                                                        <img src="{{ asset('images/' . $item->images3) }}" class="d-block w-100" alt="{{ $item->name }}">
                                                      </div>
                                                      <div class="swiper-slide">
                                                        <img src="{{ asset('images/' . $item->images4) }}" class="d-block w-100" alt="{{ $item->name }}">
                                                      </div>
                                                    </div>
                                                    <div class="swiper-button-next"></div>
                                                    <div class="swiper-button-prev"></div>
                                                  </div>

                                               </div>
                                                </div>




                                              </div>
                                        </div>

                                      </div>
                                    </div>
                                  </div>
                               </td>
                                 <td>{{$item->type}}</td>
                                 <td>{{ date('M/D/Y', strtotime($item->created_at)) }}
                                </td>
                                 <td>
                                    {{ date('M:D:Y', strtotime($item->updated_at)) }}
                                </td>

                                    <td>
                                  <div class="actions">
                                     <a class="btn btn_edit" href="/Updateproduct/{{$item->id}}"><i class="fa-solid fa-pen-to-square"></i></a>


                                     <button type="text"  class="btn btn_del open_sweet_alert " href=""><i class="fa-solid fa-trash"></i> </button>


                                  </div>
                                  <div class="box_alert_for_delete">

                                    <div class="box_model">
                                        <div class="flexis_btn">
                                            <form action="{{ route('users.delete', $item->id) }}" method="post">
                                                @csrf
                                                @method('delete')
                                                <button type="submit"  class="btn btn_del ok" href="">Yes Delete It </button>
                                            </form>
                                            <button type="text"   class="btn btn_del remove" href="">Not Delete It </button>
                                        </div>
                                    </div>
                                   </div>
                                 </td>


                               </tr>


                             @endforeach


                            </tbody>
                          </table>
                    </div>
                 </div>
<div class="pagination">
    {!! $prod->links() !!}
</div>
             </div>
       </div>
       </div>

       <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h1 class="modal-title fs-5" id="staticBackdropLabel">Add Product</h1>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="{{route("users.store")}}" method="POST" enctype="multipart/form-data">
                    @csrf
<div class="row">

    <div class="col-md-3">
        <input type="hidden" name="product_id" value="1">

        <div class="form-check">
            <label class="form-check-label">

                Name
            </label>
            <input type="text" name="name" class="form-control w-100 " value="">
        </div>
    </div>
    <div class="col-md-3">
        <input type="hidden" name="product_id" value="1">

        <div class="form-check">
            <label class="form-check-label">

                product type
            </label>
            <input type="text" name="product_type" class="form-control w-100 " value="">
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-check">
            <label class="form-check-label">

                Description
            </label>
            <input type="text" name="description" class="form-control w-100 " value="">
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-check">
            <label class="form-check-label">
                ingredients

            </label>
            <input type="text" name="ingredients" class="form-control w-100 " value="">
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-check">
        <label class="form-check-label">
            rating

        </label>
        <select name="rating" class="form-select form-control" aria-label="Default select example">
            <option selected>Open select Ratings</option>
            <option value="1">One</option>
            <option value="2">Two</option>
            <option value="3">Three</option>
            <option value="4">Four</option>
            <option value="5">Five</option>
          </select>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-check">
            <label class="form-check-label">

                Price
            </label>
            <input type="number" name="price" class="form-control w-100 " value="">
        </div>
    </div>
    <div class="col-md-5">
        <div class="form-check">
            <label class="form-check-label">

                old price
            </label>
            <input type="number" name="old_price" class="form-control w-100 " value="">
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-check">
            <label class="form-check-label">

                Category
            </label>
            <select name="category" class="form-select form-control" aria-label="Default select example">
                <option selected>Open select Category</option>
               @foreach ($cat as $cat)
               <option value="{{ $cat->category_name }}">{{ $cat->category_name }}</option>
               @endforeach
               
              </select>
           
        </div>
    </div>

    <div class="col-md-3">
        <div class="form-check">
            <label class="form-check-label">

                Type
            </label>
            <input type="text" name="type" class="form-control w-100 " value="">
        </div>
    </div>
    <div class="col-md-5">
        <div class="form-check">
            <label class="form-check-label">
                media
            </label>
            <input type="file" name="images" class="form-control w-100 ">

        </div>
    </div>
    <div class="col-md-4">
        <div class="form-check">
            <label class="form-check-label">
                media
            </label>
            <input type="file" name="images2" class="form-control w-100 ">

        </div>
    </div>

    <div class="col-md-6">
        <div class="form-check">
            <label class="form-check-label">
                media
            </label>
            <input type="file" name="images3" class="form-control w-100 ">

        </div>
    </div>
    <div class="col-md-6">
        <div class="form-check">
            <label class="form-check-label">
                media
            </label>
            <input type="file" name="images4" class="form-control w-100 ">

        </div>
    </div>
    <div class="form-check mt-5 mb-5">
        <button type="submit" class="btn btn_main_big btn_bg">
            Submit
        </button>
    </div>
</div>





                </form>
            </div>

          </div>
        </div>
      </div>
       {{-- container_end --}}
        </div>
      </div>
    </div>
    </main>
@endsection
