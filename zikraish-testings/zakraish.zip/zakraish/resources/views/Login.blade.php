@extends("Layout.App")
@section("content")
<div class="container">
     <div class="row">

       <div class="col-md-3"></div>
       <div class="col-md-6">
         <div class="login">
           <div class="card_wrap">
             <div class="card_body">
               <div class="admin_login_page">
                 <div class="box_login">
                   <div class="img">
                     <h1>zakriaish</h1>
                   </div>
                   <div class="forms">
                     <form action="">
                       <div class="mb-3">
                         <label
                           for="exampleFormControlInput1"
                           class="form-label"
                           >Email address</label
                         >
                         <input
                           type="email"
                           class="form-control"
                           id="name"
                           name="email"
                           placeholder=""
                         />
                       </div>

                       <div class="mb-3">
                         <label
                           for="exampleFormControlInput1"
                           class="form-label"
                           >password</label
                         >
                         <input
                           type="password"
                           class="form-control"
                           id="password"
                           name="password"
                           placeholder=""
                         />
                       </div>
                       <div class="mb-3">
                         <button class="btn btn_main btn_main_big">
                           submit
                         </button>
                       </div>
                     </form>
                   </div>
                 </div>
               </div>
             </div>
           </div>
         </div>
       </div>

       <div class="col-md-3"></div>
     </div>
   </div>
@endsection
