@extends('Layout.App')
@section('content')
    <main>
        <div class="wrapper">
            <div class="wrapper_content">
                <div class="container-fluid">
                    <div class="heading_main">
                        <h1>
                            Update Zakriaish Slides
                        </h1>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="card_wrap">
                                <div class="card_body">
                                    <form action="{{ url('/updateslide/' . $slide->id) }}" method="POST"
                                     enctype="multipart/form-data">


                                        @method('PUT')
                                        @csrf
                                        <input type="hidden" name="id" value="{{$slide->id}}">
                                        <div class="row">
                                             <div class="col-md-12">
                                                <div class="form-check">
                                                   <label class="form-check-label">
                                             slide image
                                                   </label>
                                                   <input type="file" name="slide" class="form-control w-100 "
                                                      value="">
                                                </div>
                                             </div>
               
                                             <div class="col-md-6">
                                                  <div class="form-check">
                                                     <label class="form-check-label">
                                               Heading (h1)
                                                     </label>
                                                     <input type="text" name="small_heading" class="form-control w-100 "
                                                        value="{{$slide->small_heading }}">
                                                  </div>
                                               </div>
                 
                                               <div class="col-md-6">
                                                  <div class="form-check">
                                                     <label class="form-check-label">
                                                       Heading (h2)
                                                     </label>
                                                     <input type="text" name="large_heading" class="form-control w-100 "
                                                     value="{{$slide->large_heading }}">
                                                  </div>
                                               </div>
               
                                               <div class="col-md-12">
                                                  <div class="form-check">
                                                     <label class="form-check-label">
                                                     paragraph
                                                     </label>
                                                     <input type="text" name="paragraph" class="form-control w-100 "
                                                     value="{{$slide->paragraph }}">
                                                  </div>
                                               </div>
                 
               
                                             <div class="form-check mt-5 mb-5">
                                                <button type="submit" class="btn btn_main_big btn_bg">
                                                Submit
                                                </button>
                                             </div>
                                          </div>





                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>


                    {{-- container_end --}}
                </div>
            </div>
        </div>
    </main>
@endsection
