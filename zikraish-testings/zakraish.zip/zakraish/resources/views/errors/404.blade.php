<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style type="text/css">
    @import url("https://fonts.googleapis.com/css2?family=Poppins&family=Roboto&display=swap");
:root {
  --main-bg-color: #d10024e6;
  --dark-text-color: #333;
  --bg-black-color: #1e1f29;
  --white-text-color: #fff;
  --font-family: "Poppins", sans-serif;
}
* {
  box-sizing: border-box;
  padding: 0;
  margin: 0;
  font-family: "Poppins", sans-serif;
}
body{
    background-color: #f9f9f9 !important;
}
        body{
          margin-top: 150px;
  
        }
        .error-main{
          background-color: #fff;
          box-shadow: rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px;
          border-radius: 20px ;
        }
        .error-main h1{
          font-weight: bold;
          color: #444444;
          font-size: 150px;
          text-shadow: 2px 4px 5px #6E6E6E;
        }
        .error-main h6{
          color: #42494F;
          font-size: 20px;
        }
        .error-main p{
          color: #9897A0;
          font-size: 15px; 
        }
    </style>
</head>
<body>
  
    <div class="container">
      <div class="row text-center">
        <div class="col-lg-6 offset-lg-3 col-sm-6 offset-sm-3 col-12 p-3 error-main">
          <div class="row">
            <div class="col-lg-8 col-12 col-sm-10 offset-lg-2 offset-sm-1">
              <h1 class="m-0">404</h1>
              <h6>Page not found - Zakriaish</h6>
              <p> 

               <div class="flex">
                    <a href="/">go back please</a>
               </div>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
      
</body>
</html>