@extends("Layout.App")
@section("content")

<main>
    <div class="wrapper">
      <div class="wrapper_content">
        <div class="container-fluid">
       <div class="row">
        <div class="col-md-6">
        <div class="card-100">
          <div class="card_wrap">
            <div class="card_body">
              <div>
                <div id="chart">
                </div>
              </div>
            </div>
          </div>
        </div>
        </div>

        <div class="col-md-6">
        <div class="card-100">
          <div class="card_wrap">
            <div class="card_body">
              <div>
                <div id="pie">
                </div>
              </div>
            </div>
          </div>
        </div>
        </div>

      <div class="col-md-12">
        <div class="card-100 mt-5 mb-5">
          <div class="card_wrap">
            <div class="card_body">
              <div class="" id="line"></div>
            </div>
          </div>
        </div>
      </div>
       </div>
        </div>
      </div>
    </div>
    </main>
@endsection
