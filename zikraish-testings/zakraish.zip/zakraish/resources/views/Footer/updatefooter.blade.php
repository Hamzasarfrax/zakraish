@extends('Layout.App')
@section('content')
    <main>
        <div class="wrapper">
            <div class="wrapper_content">
                <div class="container-fluid">
                    <div class="heading_main">
                        <h1>
                            Update Zakriaish Footer
                        </h1>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="card_wrap">
                                <div class="card_body">
                                    <form action="{{ url('/updatefooters/' . $prod->id) }}" method="POST"
                                        enctype="multipart/form-data">


                                        @method('PUT')
                                        @csrf
                                        <input type="hidden" name="id" value="{{$prod->id}}">
                                        <div class="row">
                                            <div class="col-md-6">


                                                <div class="form-check">
                                                    <label class="form-check-label">

                                                        email
                                                    </label>
                                                    <input type="email" name="email" class="form-control w-100 "
                                                        value="{{$prod->email}}">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <input type="hidden" name="product_id" value="1">

                                                <div class="form-check">
                                                    <label class="form-check-label">

                                                        contact no
                                                    </label>
                                                    <input type="number" name="contactno" class="form-control w-100 "
                                                    value="{{$prod->contactno}}">
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-check">
                                                    <label class="form-check-label">

                                                        address
                                                    </label>
                                                    <textarea name="address" class="form-control" id="" cols="30" rows="10" value="{{$prod->address}}"></textarea>
                                                </div>
                                            </div>

                                            <div class="form-check mt-5 mb-5">
                                                <button type="submit" class="btn btn_main_big btn_bg">
                                                    Submit
                                                </button>
                                            </div>

                                        </div>





                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>


                    {{-- container_end --}}
                </div>
            </div>
        </div>
    </main>
@endsection
