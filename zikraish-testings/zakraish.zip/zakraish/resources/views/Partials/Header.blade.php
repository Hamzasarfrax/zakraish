<header class="auth_header">
    <nav class="navbar">
        <div class="container-fluid">
            <a class="navbar_brand" href="#">
                <img src="{{asset('Asset/Images/logo r-03.png')}}"
                    class="img-fluid" alt="logo">
            </a>
            <button class="navbar_toggler" type="button">
                <i class="fa-solid fa-bars"></i>
            </button>

            <div class="" id="desktop_version">
                <ul class="navbar-nav ml-auto">

                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <i class="fa-solid fa-gear"></i>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('logout') }}"
                            onclick="event.preventDefault();
                         document.getElementById('logout-form').submit();">

                            <i class="fa-solid fa-power-off"></i>
                        </a>

                        <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                            @csrf
                        </form>

                    </li>


                </ul>

            </div>
        </div>
    </nav>
</header>

<aside id="aside">

    <div class="sidebar">

        <div class="boxs">
            <div class="box_details">
                <div class="flexs">
                    <div class="icon">
                        zakriaish
                    </div>
                    <div class="name text-capitalize">

                        @auth
                            {{ Auth::user()->email }}
                        @endauth
                    </div>

                </div>
            </div>
        </div>
        <ul class="navbar-nav menu">

            <li><a href="/home"  data-locate="">
                <div class="icon">
                    <i class="fa-solid fa-house"></i>
                </div>
            <div class="name">
                dashboard
            </div>

            </a></li>




            <li class="dropdown_menu_item">
                <a  >
                  <div class="icon">
                    <i class="fa-brands fa-product-hunt"></i>
                  </div>

                  <div class="title">
                      <span> Products</span>
                      <div class="arrow">
                          <i class="fa-solid fa-angle-right"></i>
                      </div>
                  </div>

                </a>
                <ul class="dropdown_menu">
                  <li><a href="/product"  data-locate="">All product's</a></li>
                  <li><a href="/showcategory"  data-locate="">Product categories</a></li>
                  <li><a href="/showclientreview"  data-locate="">Client Review's</a></li>
                  <li><a href="/showprodreview"  data-locate="">Product Review's</a></li>

                </ul>
              </li>
            <li class="dropdown_menu_item">
              <a  >
                <div class="icon">
                    <i class="fa-solid fa-truck"></i>
                </div>

                <div class="title">
                    <span>order's</span>
                    <div class="arrow">
                        <i class="fa-solid fa-angle-right"></i>
                    </div>
                </div>

              </a>
              <ul class="dropdown_menu">
                <li><a href="/"  data-locate="">Order History</a></li>
                <li><a href="/showcashorder"  data-locate="">Cash On delivery</a></li>
                <li><a href="#"  data-locate="">Orderd by card</a></li>
              </ul>
            </li>


            <li class="dropdown_menu_item">
                <a  >
                    <div class="icon">
                        <i class="fa-solid fa-gear"></i>
                    </div>
                    <div class="title">
                     <span>  C-M-S</span>
                       <div class="arrow">
                        <i class="fa-solid fa-angle-right"></i>
                    </div>
                    </div>


                  </a>
                <ul class="dropdown_menu">
                  <li><a href="/showslide" data-locate="">main slider</a></li>
                  <li><a href="/showfooter"  data-locate=""> footer</a></li>
                  <li><a href="/showsocials"  data-locate="">footer socials</a></li>
                  <li><a href="/showlogos"  data-locate="">brand logo</a></li>
                  <li><a href="/contactus"  data-locate="">contact Us </a></li>
                </ul>
              </li>
        </ul>

    </div>
</aside>



@guest
    @if (Route::has('login'))
        <li class="nav-item">
            <a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
        </li>
    @endif

    @if (Route::has('register'))
        <li class="nav-item">
            <a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>
        </li>
    @endif
@else
    <li class="nav-item dropdown">
        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
            aria-haspopup="true" aria-expanded="false" v-pre>
            {{ Auth::user()->name }}
        </a>

        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">

        </div>
    </li>
@endguest
