@include("Partials.TopNav")
@include("Partials.Header")
@yield("content")
@include("Partials.Script")
