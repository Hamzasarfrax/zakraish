@extends('Layout.App')
@section('content')
<main>
   <div class="wrapper">
      <div class="wrapper_content">
         <div class="container-fluid">
            @if (Session::has('success'))

            <div id="toast-container">
                <div class="toast">
                    <div class="toast-icon">
                        <i class="fas fa-check"></i>
                    </div>
                    <div class="toast-message">
                        {{ Session::get('success') }}
                    </div>
                </div>
            </div>

            @endif
            @if (Session::has('error'))

            <div id="toast-container">
                <div class="toast">
                    <div class="toast-icon">
                        <i class="fas fa-check"></i>
                    </div>
                    <div class="toast-message">
                        {{ Session::get('error') }}
                    </div>
                </div>
            </div>
            @endif
            <div class="heading_main">
               <h1>
                  Zakriaish product's
               </h1>
            </div>
            <div class="row">
               <div class="col-12">
                  <div class="card_wrap">
                     <div class="card_header">
                        <div class="btn_add">
                           <button type="button" class="btn btn_add" data-bs-toggle="modal"
                              data-bs-target="#staticBackdrop">
                           <i class="fa-solid fa-plus"></i>
                           </button>
                        </div>
                     </div>
                     <div class="card_body">
                        <div class="table-responsive">
                           <table class="table" id="example">
                              <thead>
                                 <tr>
                                    <th scope="col">serial no</th>
                                    <th scope="col">Sider Image</th>
                                    <th scope="col">Haeding (h1)</th>
                                    <th scope="col">Haeding (h2)</th>
                                    <th scope="col">Paragraph</th>
                                    <th scope="col">action</th>
                                 </tr>
                              </thead>
                              <tbody>
                                 @foreach ($slide as $key => $item)
                                 <tr>
                                    <th scope="row">{{ $key + 1 }} </th>
                                    <td><img src="slides/{{ $item->slide }}" alt="slides"></td>
                                    <td>{{ $item->small_heading }}</td>
                                    <td>{{ $item->large_heading }}</td>
                                    <td>{{ $item->paragraph }}</td>


                                    <td>
                                       <div class="actions">
                                          <a class="btn btn_edit"
                                             href="/showupdateslide/{{ $item->id }}"><i
                                             class="fa-solid fa-pen-to-square"></i></a>
                                          <button type="text" class="btn btn_del open_sweet_alert "
                                             href=""><i class="fa-solid fa-trash"></i>
                                          </button>
                                       </div>
                                       <div class="box_alert_for_delete">
                                          <div class="box_model">
                                            <div class="text-center mt-4 mb-4 text-capitalize">
                                                Do You really want to delete this  data
                                            </div>
                                             <div class="flexis_btn">
                                                <form action="/deletelslide/{{ $item->id }}" method="post">
                                                    @csrf
                                                    @method('DELETE')
                                                   <button type="submit" class="btn btn_del ok"
                                                      href="">Yes Delete It </button>
                                                </form>
                                                <button type="text" class="btn btn_del remove"
                                                   href="">Not Delete It </button>
                                             </div>
                                          </div>
                                       </div>
                                    </td>
                                 </tr>
                                 @endforeach
                              </tbody>
                           </table>
                        </div>
                     </div>
                     <div class="pagination">
                        {!! $slide->links() !!}
                     </div>
                  </div>
               </div>
            </div>
            <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false"
               tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
               <div class="modal-dialog">
                  <div class="modal-content">
                     <div class="modal-header">
                        <h1 class="modal-title fs-5" id="staticBackdropLabel">Add Category</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                           aria-label="Close"></button>
                     </div>
                     <div class="modal-body">
                        <form action="/storeslide" method="POST" enctype="multipart/form-data">
                           @csrf
                           <input type="hidden" name="id" value="1">
                           <div class="row">
                              <div class="col-md-12">
                                 <div class="form-check">
                                    <label class="form-check-label">
                              slide image
                                    </label>
                                    <input type="file" name="slide" class="form-control w-100 "
                                       value="">
                                 </div>
                              </div>

                              <div class="col-md-6">
                                   <div class="form-check">
                                      <label class="form-check-label">
                                Heading (h1)
                                      </label>
                                      <input type="text" name="small_heading" class="form-control w-100 "
                                         value="">
                                   </div>
                                </div>
  
                                <div class="col-md-6">
                                   <div class="form-check">
                                      <label class="form-check-label">
                                        Heading (h2)
                                      </label>
                                      <input type="text" name="large_heading" class="form-control w-100 "
                                         value="">
                                   </div>
                                </div>

                                <div class="col-md-12">
                                   <div class="form-check">
                                      <label class="form-check-label">
                                      paragraph
                                      </label>
                                      <input type="text" name="paragraph" class="form-control w-100 "
                                         value="">
                                   </div>
                                </div>
  

                              <div class="form-check mt-5 mb-5">
                                 <button type="submit" class="btn btn_main_big btn_bg">
                                 Submit
                                 </button>
                              </div>
                           </div>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
            {{-- container_end --}}
         </div>
      </div>
   </div>
</main>
@endsection
